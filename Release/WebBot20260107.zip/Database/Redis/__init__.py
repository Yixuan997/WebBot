"""
@Project ：Yapi
@File ：__init__.py
@IDE ：PyCharm
@Author ：杨逸轩
@Date ：2024/6/18 下午9:41
"""
from .client import init_redis, set_value, get_value, delete_key, get_redis
