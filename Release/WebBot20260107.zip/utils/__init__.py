"""
@Project ：Yapi 
@File    ：__init__.py
@IDE     ：PyCharm 
@Author  ：杨逸轩
@Date    ：2025/6/7 10:00 
"""
from .page_utils import generate_pagination, adapt_pagination
