"""
OneBot 协议适配器模块
支持 OneBot V11 标准
"""

from .v11.adapter import OneBotAdapter

__all__ = ['OneBotAdapter']
