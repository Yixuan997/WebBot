"""
工作流执行引擎

负责加载工作流配置、执行节点、管理上下文
"""
import asyncio
import time
from typing import Any

from Core.logging.file_logger import log_info, log_error, log_debug
from Core.logging.utils import format_exception
from .context import WorkflowContext
from .registry import NodeRegistry


class WorkflowEngine:
    """工作流执行引擎"""

    def __init__(self, config: dict[str, Any], name: str = None):
        """
        初始化工作流引擎
        
        Args:
            config: 工作流配置字典
            name: 工作流名称（可选，优先使用此参数）
        """
        self.config = config
        self.name = name or config.get('name', 'Unnamed Workflow')
        self.workflow_steps = config.get('workflow', [])

    async def execute(self, event) -> dict[str, Any]:
        """
        执行工作流
        
        Args:
            event: BaseEvent 事件对象
            
        Returns:
            dict: {
                'handled': bool,  # 是否处理了消息
                'response': BaseMessage,  # 要发送的响应（可选）
                'continue': bool  # 是否继续执行其他插件（默认False）
            }
        """
        start_time = time.time()

        try:
            # 1. 检查是否是消息事件
            if not hasattr(event, 'message'):
                return {'handled': False}

            # 2. 协议检查
            if not self._check_protocol(event):
                return {'handled': False}

            # 3. 创建执行上下文
            context = WorkflowContext(event)

            # 构建节点索引映射（id -> index）
            node_index_map = {step.get('id'): idx for idx, step in enumerate(self.workflow_steps)}

            current_index = 0
            visited_nodes = set()  # 记录已访问的节点,防止循环跳转
            loop_stack = []  # 循环栈，存储 foreach 节点信息

            while current_index < len(self.workflow_steps):
                step_config = self.workflow_steps[current_index]
                node_type = step_config.get('type')
                node_id = step_config.get('id', f"step_{step_config.get('type')}")

                # 检查是否已访问过(防止死循环)
                if node_id in visited_nodes:
                    log_error(0, f"工作流 {self.name} 检测到循环跳转: {node_id}", "WORKFLOW_LOOP_DETECTED")
                    break

                visited_nodes.add(node_id)

                try:
                    # 创建节点实例
                    node_class = NodeRegistry.get_node(node_type)
                    if not node_class:
                        log_error(0, f"未知的节点类型: {node_type}", "WORKFLOW_UNKNOWN_NODE")
                        current_index += 1
                        continue

                    node = node_class(step_config.get('config', {}))

                    # 执行节点（节点内部会自动保存输出到 context）
                    result = await node.execute(context)

                    # 检查是否需要中断
                    if node.should_break(result):
                        # 只记录非过滤节点的中断（keyword_trigger/condition 不匹配是正常行为，不需要记录）
                        if node_type not in ('keyword_trigger', 'condition', 'start', 'end'):
                            log_debug(0, f"[{self.name}] 节点 {node_id}({node_type}) 中断流程", "WORKFLOW_BREAK",
                                      node_id=node_id, node_type=node_type, result=str(result)[:200])
                        break

                    # 检查是否是循环控制
                    if isinstance(result, dict) and result.get('loop'):
                        loop_body = result.get('loop_body')
                        delay = result.get('delay', 0)
                        
                        if loop_body and loop_body in node_index_map:
                            # 将当前 foreach 节点压入栈
                            loop_stack.append({
                                'foreach_index': current_index,
                                'foreach_id': node_id
                            })
                            # 清除循环体节点的访问记录，允许重复执行
                            visited_nodes.discard(loop_body)
                            # 跳转到循环体
                            current_index = node_index_map[loop_body]
                            # 延迟
                            if delay > 0:
                                await asyncio.sleep(delay)
                            continue
                        else:
                            log_error(0, f"foreach 循环体节点不存在: {loop_body}", "FOREACH_BODY_NOT_FOUND")

                    # 检查是否需要跳转
                    if isinstance(result, dict) and 'next_node' in result:
                        next_node_id = result.get('next_node')
                        if next_node_id and next_node_id in node_index_map:
                            current_index = node_index_map[next_node_id]
                            continue
                        elif next_node_id:
                            log_error(0, f"节点 {node_id} 尝试跳转到不存在的节点: {next_node_id}",
                                      "WORKFLOW_JUMP_ERROR")

                    # 检查是否在循环中，并且需要返回 foreach
                    if loop_stack:
                        # 检查下一个节点是否是 foreach 或已经到达循环体结束
                        next_index = current_index + 1
                        loop_info = loop_stack[-1]
                        
                        # 如果下一个节点的索引 >= foreach 节点索引，说明循环体执行完毕
                        # 返回 foreach 继续下一轮
                        if next_index > loop_info['foreach_index'] or next_index >= len(self.workflow_steps):
                            loop_stack.pop()
                            # 清除 foreach 节点的访问记录，允许重新执行
                            visited_nodes.discard(loop_info['foreach_id'])
                            current_index = loop_info['foreach_index']
                            continue

                    # 默认执行下一个节点
                    current_index += 1

                except Exception as e:
                    log_error(0, f"节点 {node_id} 执行失败: {e}", "WORKFLOW_NODE_ERROR",
                              error=str(e), node_type=node_type,
                              traceback=format_exception(e))

                    # 检查是否有错误处理配置
                    if step_config.get('on_fail'):
                        self._handle_error(step_config['on_fail'], context, e)

                    # 默认：继续执行下一个节点
                    current_index += 1

            # 4. 返回结果
            response = context.get_response()
            handled = response is not None

            if handled:
                elapsed = time.time() - start_time
                log_info(0, f"[{self.name}] 处理完成 ({elapsed:.3f}s)", "WORKFLOW_SUCCESS")
                # 获取配置中的执行策略，默认为 True (继续执行后续工作流)
                allow_continue = self.config.get('allow_continue', True)

                return {
                    'handled': True,
                    'response': response,
                    'continue': allow_continue
                }
            else:
                # 即使未标记handled,也返回response(如果有)
                return {
                    'handled': False,
                    'response': response if response else None
                }

        except Exception as e:
            log_error(0, f"工作流 {self.name} 执行异常: {e}", "WORKFLOW_ERROR",
                      error=str(e), traceback=format_exception(e))
            return {'handled': False}

    def _check_protocol(self, event) -> bool:
        """
        检查工作流是否支持当前协议
        
        根据工作流配置中的 protocols 字段检查当前事件的协议是否在允许列表中。
        如果 protocols 为空或未配置，则允许所有协议。
        
        Args:
            event: 事件对象，必须包含 bot.adapter
            
        Returns:
            bool: 是否支持当前协议
        """
        allowed_protocols = self.config.get('protocols')
        if not allowed_protocols:
            return True

        current_protocol = event.bot.adapter.get_protocol_name()
        return current_protocol in allowed_protocols

    def _handle_error(self, error_config: dict[str, Any], context: WorkflowContext, error: Exception):
        """
        处理错误
        
        Args:
            error_config: 错误处理配置
            context: 执行上下文
            error: 异常对象
        """
        action = error_config.get('action')
        if action == 'send_message':
            from Core.message.builder import MessageBuilder
            message = error_config.get('message', '处理失败')
            context.set_response(MessageBuilder.text(message))
