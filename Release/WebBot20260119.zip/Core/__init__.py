"""
Flask核心模块
提供Flask应用的核心功能和配置
"""

__all__ = []
