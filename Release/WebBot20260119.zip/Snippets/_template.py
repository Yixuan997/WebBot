# Name: 代码片段名称
# Description: 代码片段描述
# Author: 作者名
# Version: 1.0.0

"""
代码片段开发模板

此文件为创建新代码片段提供完整的API文档和示例。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【可用对象】

1. context - 工作流上下文对象
   属性:
   - context.event           # BaseEvent 对象，包含完整的消息事件信息
   - context.variables       # dict，存储所有工作流变量
   
   方法:
   - context.get_variable(key, default=None)      # 获取变量
   - context.set_variable(key, value)             # 设置变量
   - context.set_response(message)                # 设置响应消息
   - context.get_response()                       # 获取响应消息
   - context.render_template(template_str)        # Jinja2模板渲染

2. context.event - 事件对象
   方法:
   - context.event.get_plaintext()                # -> str: 获取纯文本消息
   - context.event.get_message()                  # -> BaseMessage: 获取完整消息对象
   - context.event.get_user_id()                  # -> str: 获取发送者ID
   - context.event.get_session_id()               # -> str: 获取会话ID
   - context.event.is_tome()                      # -> bool: 消息是否@机器人
   - context.event.get_type()                     # -> str: 事件类型

3. message_api - 消息发送API（存储在 context.variables['message_api']）
   方法:
   - message_api.send_message(content)            # 发送消息（字符串或BaseMessage）
   - message_api.reply(content)                   # send_message的别名

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【开始节点提取的变量】

可通过 context.get_variable() 获取：

- message              # str: 纯文本消息内容
- message_full         # BaseMessage: 完整消息对象
- message_type         # str: 消息类型（text/image/voice）
- has_image            # bool: 是否包含图片
- has_at               # bool: 是否包含@
- sender.user_id       # str: 发送者用户ID
- sender.nickname      # str: 发送者昵称
- sender               # object: 完整sender对象
- group_id             # str: 群聊ID（仅群聊）
- is_group             # bool: 是否群聊
- protocol             # str: 协议类型（qq/onebot）
- event                # BaseEvent: 完整事件对象

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【必须设置】

- result               # 任意类型: 代码片段的执行结果，必须设置！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【注意事项】

1. 以下划线开头的文件（如 _template.py）不会被加载到代码片段列表
2. 可以 import 任何 Python 模块
3. 异常会被自动捕获并记录到日志
4. 代码片段执行在线程池中，避免长时间阻塞操作
5. 更多示例请查看 Snippets/echo_message.py

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 【示例 1】简单文本回复
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 1. 获取消息和发送者信息
message = context.get_variable('message', '')
sender_name = context.get_variable('sender.nickname', '用户')

# 2. 构造回复内容
reply = f"你好 {sender_name}，你说了：{message}"

# 3. 发送回复
message_api = context.get_variable('message_api')
if message_api:
    message_api.send_message(reply)

# 4. 设置返回值（必须）
result = "执行成功"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 【示例 2】条件判断 - 特定用户回复
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# user_id = context.get_variable('sender.user_id', '')
# message_api = context.get_variable('message_api')
# 
# # 判断是否为VIP用户
# VIP_USERS = ['123456', '789012']  # VIP用户列表
# 
# if user_id in VIP_USERS:
#     message_api.send_message("🎉 你是VIP用户，享受特权服务！")
#     result = f"VIP用户 {user_id} 已回复"
# else:
#     result = f"非VIP用户 {user_id}，跳过处理"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 【示例 3】使用 context.event 直接访问事件
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# # 直接从 context.event 获取信息
# message_text = context.event.get_plaintext()
# user_id = context.event.get_user_id()
# is_at_me = context.event.is_tome()
# 
# message_api = context.variables['message_api']
# 
# if is_at_me:
#     message_api.send_message(f"你@了我，消息内容是：{message_text}")
#     result = "已回复@消息"
# else:
#     result = "未@机器人，跳过"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 【示例 4】使用 MessageBuilder 构造复杂消息
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# from Core.message.builder import MessageBuilder
# 
# message_api = context.variables['message_api']
# sender_name = context.get_variable('sender.nickname', '用户')
# 
# # 构造文本 + 图片组合消息
# reply = MessageBuilder.text(f"你好 {sender_name}！")
# # reply = reply + MessageBuilder.image("path/to/image.jpg")  # 添加图片
# 
# message_api.send_message(reply)
# result = "复杂消息已发送"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 【示例 5】设置变量供后续节点使用
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# message = context.get_variable('message', '')
# 
# # 处理数据
# processed_data = message.upper()  # 转成大写
# word_count = len(message.split())  # 计算单词数
# 
# # 保存到上下文，供后续节点使用
# context.set_variable('processed_message', processed_data)
# context.set_variable('word_count', word_count)
# 
# result = f"处理完成: {word_count} 个单词"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 【示例 6】错误处理
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# try:
#     # 你的代码逻辑
#     message = context.get_variable('message')
#     if not message:
#         raise ValueError("消息为空")
#     
#     # 处理消息
#     message_api = context.variables['message_api']
#     message_api.send_message(f"处理成功：{message}")
#     
#     result = "执行成功"
#     
# except Exception as e:
#     # 错误会自动记录到日志，但你也可以自己处理
#     result = f"执行失败: {str(e)}"
