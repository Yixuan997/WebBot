"""
喜加一插件 - 获取Epic Games和Steam免费游戏信息
支持用户发送"喜加一"命令获取当前免费游戏
"""

from typing import List

from Core.logging.file_logger import log_info, log_error
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin

from .api_client import FreeGamesAPI
from .formatter import MessageFormatter


class Plugin(BasePlugin):
    """喜加一插件"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "FreeGames"
        self.version = "1.0.0"
        self.description = "喜加一插件 - 获取Epic Games和Steam免费游戏信息"
        self.author = "Yixuan"
        self.priority = 8  # 较高优先级

        # 注册命令信息
        self.register_command_info('喜加一', '获取Epic和Steam免费游戏', '喜加一')

        # 命令处理器
        self.command_handlers = {
            '喜加一': self.handle_free_games
        }

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.handle_message_hook],
            'bot_start': [self.on_bot_start_hook],
            'bot_stop': [self.on_bot_stop_hook]
        }

        # 初始化API客户端和消息格式化器
        self.api_client = FreeGamesAPI()
        self.formatter = MessageFormatter()

    def handle_message_hook(self, message_data, user_id=None, bot_id=None):
        """处理消息Hook"""
        try:
            content = message_data.get('content', '').strip()

            # 检查是否是喜加一命令
            if content == '喜加一':
                response = self.handle_free_games([])
                return {
                    'response': response,
                    'handled': True
                }

            return {'handled': False}

        except Exception as e:
            log_error(bot_id or 0, f"FreeGames插件处理消息异常: {e}", "FREE_GAMES_HOOK_ERROR", error=str(e))
            return {'handled': False}

    def handle_free_games(self, args):
        """处理喜加一命令"""
        try:
            # 获取Epic Games免费游戏
            epic_games = self.api_client.get_epic_free_games()

            # 获取Steam免费游戏
            steam_games = self.api_client.get_steam_free_games()

            # 使用格式化器生成消息
            messages = self.formatter.format_multiple_messages(epic_games, steam_games)

            return messages

        except Exception as e:
            log_error(0, f"处理喜加一命令异常: {e}", "FREE_GAMES_COMMAND_ERROR", error=str(e))
            return self.formatter.format_error_message(str(e))



    def on_bot_start_hook(self, bot_id):
        """机器人启动Hook"""
        return {'message': f'FreeGames插件已为机器人 {bot_id} 准备就绪'}

    def on_bot_stop_hook(self, bot_id):
        """机器人停止Hook"""
        return {'message': f'FreeGames插件已为机器人 {bot_id} 清理资源'}

    def on_enable(self):
        """插件启用时调用"""
        super().on_enable()
        log_info(0, "FreeGames插件已启用，支持Epic Games和Steam免费游戏查询", "FREE_GAMES_PLUGIN_ENABLED")

    def on_disable(self):
        """插件禁用时调用"""
        super().on_disable()
        log_info(0, "FreeGames插件已禁用", "FREE_GAMES_PLUGIN_DISABLED")
