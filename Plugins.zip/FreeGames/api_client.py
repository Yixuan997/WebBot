"""
喜加一插件API客户端
处理Epic Games和Steam的API调用
"""

import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union

import requests
from Core.logging.file_logger import log_info, log_error, log_warn
from Database.Redis.client import set_value, get_value

from .config import (
    EPIC_GAMES_API, STEAM_API, STEAMDB_API, CACHE_CONFIG, 
    REQUEST_HEADERS, RETRY_CONFIG, LOG_CONFIG
)


class APIClient:
    """API客户端基类"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(REQUEST_HEADERS)
    
    def _make_request(self, url: str, timeout: int = 10, retries: int = 3) -> Optional[Dict]:
        """发起HTTP请求，带重试机制"""
        for attempt in range(retries):
            try:
                if LOG_CONFIG['log_api_calls']:
                    log_info(0, f"API请求: {url} (尝试 {attempt + 1}/{retries})", "API_REQUEST")
                
                response = self.session.get(url, timeout=timeout)
                response.raise_for_status()
                
                return response.json()
                
            except requests.exceptions.RequestException as e:
                if attempt == retries - 1:  # 最后一次尝试
                    if LOG_CONFIG['log_errors']:
                        log_error(0, f"API请求失败: {url}, 错误: {e}", "API_REQUEST_FAILED", 
                                url=url, error=str(e))
                    return None
                else:
                    # 指数退避
                    delay = RETRY_CONFIG['retry_delay'] * (RETRY_CONFIG['backoff_factor'] ** attempt)
                    time.sleep(delay)
                    
        return None
    
    def _get_cached_data(self, cache_key: str) -> Optional[Union[List, Dict]]:
        """从缓存获取数据"""
        try:
            cached_data = get_value(cache_key)
            if cached_data:
                if LOG_CONFIG['log_cache_hits']:
                    log_info(0, f"缓存命中: {cache_key}", "CACHE_HIT")
                
                # 处理bytes类型的缓存数据
                if isinstance(cached_data, bytes):
                    cached_data = cached_data.decode('utf-8')
                
                return json.loads(cached_data)
        except Exception as e:
            if LOG_CONFIG['log_errors']:
                log_error(0, f"读取缓存失败: {cache_key}, 错误: {e}", "CACHE_READ_ERROR", 
                        cache_key=cache_key, error=str(e))
        
        return None
    
    def _set_cached_data(self, cache_key: str, data: Union[List, Dict], duration: int):
        """设置缓存数据"""
        try:
            json_data = json.dumps(data, ensure_ascii=False)
            set_value(cache_key, json_data, duration)
            
            if LOG_CONFIG['log_cache_hits']:
                log_info(0, f"数据已缓存: {cache_key}, 过期时间: {duration}秒", "CACHE_SET")
                
        except Exception as e:
            if LOG_CONFIG['log_errors']:
                log_error(0, f"设置缓存失败: {cache_key}, 错误: {e}", "CACHE_SET_ERROR", 
                        cache_key=cache_key, error=str(e))


class EpicGamesClient(APIClient):
    """Epic Games API客户端"""
    
    def get_free_games(self) -> Optional[List[Dict]]:
        """获取Epic Games免费游戏"""
        cache_key = CACHE_CONFIG['epic_cache_key']
        
        # 尝试从缓存获取
        cached_data = self._get_cached_data(cache_key)
        if cached_data:
            return cached_data
        
        # 从API获取
        url = f"{EPIC_GAMES_API['base_url']}{EPIC_GAMES_API['free_games_endpoint']}"
        data = self._make_request(
            url, 
            timeout=EPIC_GAMES_API['timeout'], 
            retries=EPIC_GAMES_API['retry_count']
        )
        
        if not data:
            return None
        
        # 解析免费游戏数据
        free_games = self._parse_epic_games(data)
        
        # 缓存结果
        if free_games:
            self._set_cached_data(cache_key, free_games, CACHE_CONFIG['epic_cache_duration'])
        
        return free_games
    
    def _parse_epic_games(self, data: Dict) -> List[Dict]:
        """解析Epic Games API响应数据"""
        free_games = []
        
        try:
            games = data.get('data', {}).get('Catalog', {}).get('searchStore', {}).get('elements', [])
            
            for game in games:
                promotions = game.get('promotions')
                if not promotions:
                    continue
                
                # 解析当前免费游戏
                promotional_offers = promotions.get('promotionalOffers', [])
                for offer_set in promotional_offers:
                    for offer in offer_set.get('promotionalOffers', []):
                        if self._is_free_offer(offer):
                            game_info = self._extract_game_info(game, offer, 'current')
                            if game_info:
                                free_games.append(game_info)
                
                # 解析即将免费的游戏
                upcoming_offers = promotions.get('upcomingPromotionalOffers', [])
                for offer_set in upcoming_offers:
                    for offer in offer_set.get('promotionalOffers', []):
                        if self._is_free_offer(offer):
                            game_info = self._extract_game_info(game, offer, 'upcoming')
                            if game_info:
                                free_games.append(game_info)
                                
        except Exception as e:
            if LOG_CONFIG['log_errors']:
                log_error(0, f"解析Epic Games数据失败: {e}", "EPIC_PARSE_ERROR", error=str(e))
        
        return free_games
    
    def _is_free_offer(self, offer: Dict) -> bool:
        """检查是否为免费优惠"""
        discount_setting = offer.get('discountSetting', {})
        return discount_setting.get('discountPercentage') == 0
    
    def _extract_game_info(self, game: Dict, offer: Dict, status: str) -> Optional[Dict]:
        """提取游戏信息"""
        try:
            return {
                'title': game.get('title', '未知游戏'),
                'description': game.get('description', ''),
                'start_date': offer.get('startDate'),
                'end_date': offer.get('endDate'),
                'status': status,
                'url': f"https://store.epicgames.com/zh-CN/p/{game.get('urlSlug', '')}" if game.get('urlSlug') else None
            }
        except Exception as e:
            if LOG_CONFIG['log_errors']:
                log_error(0, f"提取游戏信息失败: {e}", "EPIC_EXTRACT_ERROR", error=str(e))
            return None


class SteamClient(APIClient):
    """Steam API客户端"""
    
    def get_free_games(self) -> Optional[List[Dict]]:
        """获取Steam免费游戏"""
        cache_key = CACHE_CONFIG['steam_cache_key']
        
        # 尝试从缓存获取
        cached_data = self._get_cached_data(cache_key)
        if cached_data:
            return cached_data
        
        # Steam没有直接的免费游戏API，这里使用一个简化的实现
        # 实际项目中可以接入SteamDB或其他第三方API
        free_games = self._get_steam_free_games_fallback()
        
        # 缓存结果（即使是空的也缓存，避免频繁请求）
        self._set_cached_data(cache_key, free_games, CACHE_CONFIG['steam_cache_duration'])
        
        return free_games
    
    def _get_steam_free_games_fallback(self) -> List[Dict]:
        """Steam免费游戏回退方案"""
        # 这里可以添加一些已知的永久免费游戏
        # 或者接入第三方API获取当前免费游戏
        
        # 示例：一些永久免费的Steam游戏
        permanent_free_games = [
            {
                'title': 'Dota 2',
                'description': 'MOBA游戏',
                'status': 'permanent_free',
                'url': 'https://store.steampowered.com/app/570/Dota_2/'
            },
            {
                'title': 'Counter-Strike 2',
                'description': 'FPS竞技游戏',
                'status': 'permanent_free',
                'url': 'https://store.steampowered.com/app/730/CounterStrike_2/'
            },
            {
                'title': 'Team Fortress 2',
                'description': '团队射击游戏',
                'status': 'permanent_free',
                'url': 'https://store.steampowered.com/app/440/Team_Fortress_2/'
            }
        ]
        
        # 在实际实现中，这里应该调用真实的API
        # 目前返回空列表，表示没有临时免费游戏
        return []


class FreeGamesAPI:
    """免费游戏API统一接口"""
    
    def __init__(self):
        self.epic_client = EpicGamesClient()
        self.steam_client = SteamClient()
    
    def get_epic_free_games(self) -> Optional[List[Dict]]:
        """获取Epic Games免费游戏"""
        return self.epic_client.get_free_games()
    
    def get_steam_free_games(self) -> Optional[List[Dict]]:
        """获取Steam免费游戏"""
        return self.steam_client.get_free_games()
    
    def get_all_free_games(self) -> Dict[str, Optional[List[Dict]]]:
        """获取所有平台的免费游戏"""
        return {
            'epic': self.get_epic_free_games(),
            'steam': self.get_steam_free_games()
        }
