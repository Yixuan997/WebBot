"""
喜加一插件配置文件
"""

# API配置
EPIC_GAMES_API = {
    'base_url': 'https://store-site-backend-static.ak.epicgames.com',
    'free_games_endpoint': '/freeGamesPromotions',
    'timeout': 10,
    'retry_count': 3
}

STEAM_API = {
    'base_url': 'https://api.steampowered.com',
    'app_list_endpoint': '/ISteamApps/GetAppList/v2/',
    'timeout': 10,
    'retry_count': 3
}

# 第三方Steam免费游戏API
STEAMDB_API = {
    'base_url': 'https://steamdb.info',
    'free_games_endpoint': '/api/GetFreegames/',
    'timeout': 15,
    'retry_count': 2
}

# 缓存配置
CACHE_CONFIG = {
    'epic_cache_duration': 3600,  # Epic Games缓存1小时
    'steam_cache_duration': 7200,  # Steam缓存2小时
    'epic_cache_key': 'free_games:epic',
    'steam_cache_key': 'free_games:steam'
}

# 请求头配置
REQUEST_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1'
}

# 消息格式配置
MESSAGE_CONFIG = {
    'max_epic_current_games': 3,  # 最多显示的当前Epic免费游戏数量
    'max_epic_upcoming_games': 2,  # 最多显示的即将免费Epic游戏数量
    'max_steam_games': 5,  # 最多显示的Steam免费游戏数量
    'date_format': '%m月%d日',  # 日期格式
    'datetime_format': '%m月%d日 %H:%M'  # 日期时间格式
}

# 错误重试配置
RETRY_CONFIG = {
    'max_retries': 3,
    'retry_delay': 1,  # 秒
    'backoff_factor': 2  # 指数退避因子
}

# 日志配置
LOG_CONFIG = {
    'log_api_calls': True,  # 是否记录API调用日志
    'log_cache_hits': False,  # 是否记录缓存命中日志
    'log_errors': True  # 是否记录错误日志
}
