# 喜加一插件 (FreeGames Plugin)

一个用于获取Epic Games Store和Steam平台免费游戏信息的QQ机器人插件。

## 功能特性

- 🎮 **Epic Games Store**: 获取当前免费游戏和即将免费的游戏
- 🎮 **Steam**: 获取限时免费游戏信息（Steam免费游戏较少）
- 💾 **智能缓存**: 使用Redis缓存避免频繁API调用
- 📱 **简单易用**: 用户只需发送"喜加一"即可获取信息
- 🔄 **自动重试**: 内置重试机制确保API调用稳定性

## 使用方法

### 用户命令

用户在QQ中发送以下命令：

```
喜加一
```

机器人会返回两条消息：
1. Epic Games Store的免费游戏信息
2. Steam的免费游戏信息

### 示例响应

**Epic Games消息示例：**
```
🎮 Epic Games 免费游戏:

📅 当前免费:
• Totally Reliable Delivery Service Standard Edition (至08月21日)
• Hidden Folks (至08月21日)

🔜 即将免费:
• Strange Horticulture (08月21日开始)
• Kamaeru (08月21日开始)

💡 记得及时领取哦！
```

**Steam消息示例：**
```
🎮 Steam: 暂无限时免费游戏
💡 建议关注周末免费试玩活动
```

## 技术架构

### 文件结构

```
Plugins/FreeGames/
├── __init__.py          # 主插件文件
├── api_client.py        # API客户端模块
├── formatter.py         # 消息格式化模块
├── config.py           # 配置文件
└── README.md           # 说明文档
```

### 核心组件

1. **Plugin类** (`__init__.py`)
   - 继承自BasePlugin
   - 处理"喜加一"命令
   - 管理插件生命周期

2. **FreeGamesAPI类** (`api_client.py`)
   - 统一的API接口
   - Epic Games和Steam API客户端
   - 缓存管理和错误处理

3. **MessageFormatter类** (`formatter.py`)
   - 消息格式化和美化
   - 日期时间处理
   - 多平台消息生成

4. **配置模块** (`config.py`)
   - API端点配置
   - 缓存设置
   - 消息格式配置

### API数据源

- **Epic Games Store**: 官方API `store-site-backend-static.ak.epicgames.com`
- **Steam**: 目前使用简化实现，可扩展接入第三方API

### 缓存策略

- Epic Games: 1小时缓存
- Steam: 2小时缓存
- 使用Redis存储，支持降级到内存缓存

## 配置说明

### 缓存配置

```python
CACHE_CONFIG = {
    'epic_cache_duration': 3600,  # Epic Games缓存1小时
    'steam_cache_duration': 7200,  # Steam缓存2小时
    'epic_cache_key': 'free_games:epic',
    'steam_cache_key': 'free_games:steam'
}
```

### 消息格式配置

```python
MESSAGE_CONFIG = {
    'max_epic_current_games': 3,  # 最多显示的当前Epic免费游戏数量
    'max_epic_upcoming_games': 2,  # 最多显示的即将免费Epic游戏数量
    'max_steam_games': 5,  # 最多显示的Steam免费游戏数量
    'date_format': '%m月%d日',  # 日期格式
}
```

## 安装和部署

1. 将插件文件放置在 `Plugins/FreeGames/` 目录下
2. 确保系统已安装依赖：
   - `requests` - HTTP请求库
   - `redis` - Redis客户端（可选，支持降级）
3. 重启QQ机器人应用
4. 插件会自动加载并注册命令

## 测试

运行测试脚本验证插件功能：

```bash
python test_freegames.py
```

测试内容包括：
- Epic Games API调用
- Steam API调用
- 消息格式化
- 插件集成测试

## 扩展开发

### 添加新平台

1. 在 `api_client.py` 中添加新的客户端类
2. 在 `formatter.py` 中添加对应的格式化方法
3. 在 `config.py` 中添加相关配置
4. 更新主插件文件的处理逻辑

### 自定义消息格式

修改 `formatter.py` 中的格式化方法，可以：
- 调整消息布局
- 添加更多游戏信息
- 自定义表情符号
- 支持富文本格式

## 注意事项

1. **API限制**: Epic Games API有访问频率限制，插件已实现缓存机制
2. **网络依赖**: 需要稳定的网络连接访问外部API
3. **Redis可选**: 如果Redis不可用，会自动降级到内存缓存
4. **Steam限制**: Steam很少有限时免费游戏，主要显示永久免费游戏

## 更新日志

### v1.0.0 (2025-08-20)
- 初始版本发布
- 支持Epic Games Store免费游戏查询
- 支持Steam免费游戏查询
- 实现Redis缓存机制
- 添加消息格式化功能

## 许可证

本插件遵循项目主许可证。
