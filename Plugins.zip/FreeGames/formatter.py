"""
喜加一插件消息格式化模块
负责将游戏数据格式化为用户友好的消息
"""

from datetime import datetime
from typing import Dict, List, Optional

from Core.message.builder import MessageBuilder
from .config import MESSAGE_CONFIG


class MessageFormatter:
    """消息格式化器"""
    
    def __init__(self):
        self.date_format = MESSAGE_CONFIG['date_format']
        self.datetime_format = MESSAGE_CONFIG['datetime_format']
    
    def format_epic_message(self, games: List[Dict]) -> str:
        """格式化Epic Games消息"""
        if not games:
            return MessageBuilder.text("🎮 Epic Games: 暂无免费游戏")
        
        message_parts = ["🎮 Epic Games 免费游戏:"]
        
        # 分类游戏
        current_games = [g for g in games if g.get('status') == 'current']
        upcoming_games = [g for g in games if g.get('status') == 'upcoming']
        
        # 当前免费游戏
        if current_games:
            message_parts.append("\n📅 当前免费:")
            for game in current_games[:MESSAGE_CONFIG['max_epic_current_games']]:
                game_line = self._format_epic_game_line(game)
                if game_line:
                    message_parts.append(f"• {game_line}")
        
        # 即将免费游戏
        if upcoming_games:
            message_parts.append("\n🔜 即将免费:")
            for game in upcoming_games[:MESSAGE_CONFIG['max_epic_upcoming_games']]:
                game_line = self._format_epic_game_line(game, upcoming=True)
                if game_line:
                    message_parts.append(f"• {game_line}")
        
        # 添加提示信息
        if current_games:
            message_parts.append("\n💡 记得及时领取哦！")
        
        return MessageBuilder.text("\n".join(message_parts))
    
    def format_steam_message(self, games: List[Dict]) -> str:
        """格式化Steam消息"""
        if not games:
            return MessageBuilder.text(
                "🎮 Steam: 暂无限时免费游戏\n"
                "💡 Steam免费游戏较少，建议关注:\n"
                "• 周末免费试玩活动\n"
                "• 永久免费游戏 (如Dota 2, CS2等)"
            )
        
        message_parts = ["🎮 Steam 免费游戏:"]
        
        # 分类游戏
        temporary_free = [g for g in games if g.get('status') != 'permanent_free']
        permanent_free = [g for g in games if g.get('status') == 'permanent_free']
        
        # 限时免费游戏
        if temporary_free:
            message_parts.append("\n⏰ 限时免费:")
            for game in temporary_free[:MESSAGE_CONFIG['max_steam_games']]:
                game_line = self._format_steam_game_line(game)
                if game_line:
                    message_parts.append(f"• {game_line}")
        
        # 永久免费游戏（只在没有限时免费时显示）
        if not temporary_free and permanent_free:
            message_parts.append("\n🆓 永久免费推荐:")
            for game in permanent_free[:3]:  # 最多显示3个永久免费游戏
                title = game.get('title', '未知游戏')
                message_parts.append(f"• {title}")
        
        return MessageBuilder.text("\n".join(message_parts))
    
    def _format_epic_game_line(self, game: Dict, upcoming: bool = False) -> Optional[str]:
        """格式化单个Epic游戏行"""
        try:
            title = game.get('title', '未知游戏')
            
            if upcoming:
                # 即将免费的游戏显示开始时间
                start_date = game.get('start_date')
                if start_date:
                    start_str = self._format_date(start_date)
                    if start_str:
                        return f"{title} ({start_str}开始)"
                return title
            else:
                # 当前免费的游戏显示结束时间
                end_date = game.get('end_date')
                if end_date:
                    end_str = self._format_date(end_date)
                    if end_str:
                        return f"{title} (至{end_str})"
                return title
                
        except Exception:
            return game.get('title', '未知游戏')
    
    def _format_steam_game_line(self, game: Dict) -> Optional[str]:
        """格式化单个Steam游戏行"""
        try:
            title = game.get('title', '未知游戏')
            
            # 如果有结束时间，显示结束时间
            end_date = game.get('end_date')
            if end_date:
                end_str = self._format_date(end_date)
                if end_str:
                    return f"{title} (至{end_str})"
            
            return title
            
        except Exception:
            return game.get('title', '未知游戏')
    
    def _format_date(self, date_str: str) -> Optional[str]:
        """格式化日期字符串"""
        if not date_str:
            return None
        
        try:
            # 处理ISO格式的日期
            if 'T' in date_str:
                # 移除时区信息并解析
                clean_date = date_str.replace('Z', '+00:00')
                dt = datetime.fromisoformat(clean_date)
                
                # 转换为本地时间（简化处理，实际应该考虑时区）
                return dt.strftime(self.date_format)
            else:
                # 尝试其他日期格式
                dt = datetime.strptime(date_str, '%Y-%m-%d')
                return dt.strftime(self.date_format)
                
        except Exception:
            return None
    
    def format_error_message(self, error_msg: str) -> str:
        """格式化错误消息"""
        return MessageBuilder.text(f"❌ 获取免费游戏信息失败: {error_msg}")
    
    def format_no_games_message(self) -> List[str]:
        """格式化无游戏时的消息"""
        return [
            MessageBuilder.text("🎮 Epic Games: 暂无免费游戏"),
            MessageBuilder.text(
                "🎮 Steam: 暂无限时免费游戏\n"
                "💡 建议关注周末免费试玩活动"
            )
        ]
    
    def format_multiple_messages(self, epic_games: Optional[List[Dict]], 
                                steam_games: Optional[List[Dict]]) -> List[str]:
        """格式化多条消息"""
        messages = []
        
        # Epic Games消息
        if epic_games:
            epic_msg = self.format_epic_message(epic_games)
            messages.append(epic_msg)
        else:
            messages.append(MessageBuilder.text("🎮 Epic Games: 暂无免费游戏信息"))
        
        # Steam消息
        if steam_games:
            steam_msg = self.format_steam_message(steam_games)
            messages.append(steam_msg)
        else:
            messages.append(MessageBuilder.text(
                "🎮 Steam: 暂无限时免费游戏\n"
                "💡 建议关注周末免费试玩活动"
            ))
        
        return messages


class EmojiHelper:
    """表情符号助手"""
    
    PLATFORM_EMOJIS = {
        'epic': '🎮',
        'steam': '🎮',
        'gog': '🎯',
        'ubisoft': '🎪'
    }
    
    STATUS_EMOJIS = {
        'current': '📅',
        'upcoming': '🔜',
        'permanent_free': '🆓',
        'weekend_free': '⏰'
    }
    
    @classmethod
    def get_platform_emoji(cls, platform: str) -> str:
        """获取平台表情符号"""
        return cls.PLATFORM_EMOJIS.get(platform.lower(), '🎮')
    
    @classmethod
    def get_status_emoji(cls, status: str) -> str:
        """获取状态表情符号"""
        return cls.STATUS_EMOJIS.get(status.lower(), '📅')
