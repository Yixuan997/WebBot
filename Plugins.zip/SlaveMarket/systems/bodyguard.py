"""
保镖防御系统
"""

import logging
import random
from datetime import datetime, timedelta
from typing import Dict, Any, List

from ..core.database import DatabaseManager, Bodyguard, Transaction


class BodyguardSystem:
    """保镖防御系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

        # 保镖配置
        self.bodyguard_types = {
            "basic": {
                "name": "普通保镖",
                "cost": 50,
                "defense_rate": 0.3,
                "duration_hours": 6,
                "description": "提供基础防护，30%几率阻止抢劫"
            },
            "advanced": {
                "name": "高级保镖",
                "cost": 150,
                "defense_rate": 0.6,
                "duration_hours": 12,
                "description": "提供强力防护，60%几率阻止抢劫"
            },
            "elite": {
                "name": "精英保镖",
                "cost": 300,
                "defense_rate": 0.8,
                "duration_hours": 24,
                "description": "提供顶级防护，80%几率阻止抢劫"
            }
        }

        # 保镖反击配置
        self.counter_attack_rate = 0.2  # 反击概率
        self.counter_damage_rate = 0.1  # 反击伤害比例
        self.max_counter_damage = 100  # 最大反击伤害

        # 保镖表已在数据库模型中定义，无需单独创建

    def format_currency(self, amount: float) -> str:
        """格式化金币显示"""
        return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

    def format_time(self, seconds: int) -> str:
        """格式化时间显示"""
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            return f"{seconds // 60}分{seconds % 60}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分钟"

    async def hire_bodyguard(self, user_id: str, group_id: str, bodyguard_type: str) -> Dict[str, Any]:
        """雇佣保镖"""
        try:
            # 检查保镖类型
            if bodyguard_type not in self.bodyguard_types:
                return {"success": False, "message": "无效的保镖类型"}

            bodyguard_info = self.bodyguard_types[bodyguard_type]

            # 获取用户数据
            user = self.db_manager.get_user(user_id, group_id)
            if not user:
                return {"success": False, "message": "用户数据不存在"}

            # 检查金币是否足够
            cost = bodyguard_info["cost"]
            if user.currency < cost:
                return {
                    "success": False,
                    "message": f"金币不足，需要 {self.format_currency(cost)} 金币，您只有 {self.format_currency(user.currency)} 金币"
                }

            # 检查是否已有保镖
            existing_bodyguard = self.get_active_bodyguard(user_id, group_id)
            if existing_bodyguard:
                return {
                    "success": False,
                    "message": f"您已雇佣了{existing_bodyguard['bodyguard_name']}，请等待到期后再雇佣新保镖"
                }

            # 扣除金币
            user.currency -= cost
            user.total_spent += cost
            self.db_manager.update_user(user)

            # 创建保镖记录
            hire_time = datetime.utcnow()
            expire_time = hire_time + timedelta(hours=bodyguard_info["duration_hours"])

            session = self.db_manager.get_session()
            try:
                # 删除现有保镖记录
                existing = session.query(Bodyguard).filter_by(
                    union_openid=user_id, group_openid=group_id
                ).first()
                if existing:
                    session.delete(existing)

                # 创建新保镖记录
                bodyguard = Bodyguard(
                    union_openid=user_id,
                    group_openid=group_id,
                    bodyguard_type=bodyguard_type,
                    hire_time=hire_time,
                    expire_time=expire_time
                )
                session.add(bodyguard)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

            # 记录交易
            self.record_bodyguard_transaction(group_id, user_id, "hire", cost,
                                              f"雇佣{bodyguard_info['name']}")

            return {
                "success": True,
                "bodyguard_name": bodyguard_info["name"],
                "cost": cost,
                "duration_hours": bodyguard_info["duration_hours"],
                "defense_rate": bodyguard_info["defense_rate"],
                "new_currency": user.currency,
                "expire_time": expire_time
            }

        except Exception as e:
            self.logger.error(f"雇佣保镖失败: {e}")
            return {"success": False, "message": "雇佣保镖失败"}

    def get_active_bodyguard(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """获取活跃的保镖"""
        try:
            session = self.db_manager.get_session()
            try:
                bodyguard = session.query(Bodyguard).filter(
                    Bodyguard.union_openid == user_id,
                    Bodyguard.group_openid == group_id,
                    Bodyguard.expire_time > datetime.utcnow()
                ).first()

                if bodyguard:
                    bodyguard_info = self.bodyguard_types.get(bodyguard.bodyguard_type)
                    return {
                        "bodyguard_type": bodyguard.bodyguard_type,
                        "bodyguard_name": bodyguard_info["name"] if bodyguard_info else "未知保镖",
                        "hire_time": bodyguard.hire_time,
                        "expire_time": bodyguard.expire_time,
                        "defense_count": bodyguard.defense_count,
                        "counter_count": bodyguard.counter_count,
                        "defense_rate": bodyguard_info["defense_rate"] if bodyguard_info else 0
                    }

                return None

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取活跃保镖失败: {e}")
            return None

    async def check_defense(self, defender_id: str, attacker_id: str, group_id: str) -> Dict[str, Any]:
        """检查保镖防御"""
        try:
            bodyguard = self.get_active_bodyguard(defender_id, group_id)
            if not bodyguard:
                return {"defended": False, "counter_attack": False}

            # 判断是否防御成功
            defense_success = random.random() < bodyguard["defense_rate"]

            if defense_success:
                # 更新防御次数
                self.update_bodyguard_stats(defender_id, group_id, defense_count=1)

                # 判断是否反击
                counter_attack = random.random() < self.counter_attack_rate
                counter_damage = 0

                if counter_attack:
                    # 计算反击伤害
                    attacker = self.db_manager.get_user(attacker_id, group_id)
                    if attacker:
                        counter_damage = min(
                            self.max_counter_damage,
                            attacker.currency * self.counter_damage_rate
                        )
                        counter_damage = round(counter_damage, 1)

                        # 扣除攻击者金币
                        attacker.currency = max(0, attacker.currency - counter_damage)
                        attacker.total_spent += counter_damage
                        self.db_manager.update_user(attacker)

                        # 更新反击次数
                        self.update_bodyguard_stats(defender_id, group_id, counter_count=1)

                return {
                    "defended": True,
                    "counter_attack": counter_attack,
                    "counter_damage": counter_damage,
                    "bodyguard_name": bodyguard["bodyguard_name"]
                }

            return {"defended": False, "counter_attack": False}

        except Exception as e:
            self.logger.error(f"检查保镖防御失败: {e}")
            return {"defended": False, "counter_attack": False}

    def update_bodyguard_stats(self, user_id: str, group_id: str,
                               defense_count: int = 0, counter_count: int = 0):
        """更新保镖统计"""
        try:
            session = self.db_manager.get_session()
            try:
                bodyguard = session.query(Bodyguard).filter(
                    Bodyguard.union_openid == user_id,
                    Bodyguard.group_openid == group_id,
                    Bodyguard.expire_time > datetime.utcnow()
                ).first()

                if bodyguard:
                    bodyguard.defense_count += defense_count
                    bodyguard.counter_count += counter_count
                    session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"更新保镖统计失败: {e}")

    def record_bodyguard_transaction(self, group_id: str, user_id: str,
                                     trans_type: str, amount: float, description: str):
        """记录保镖相关交易"""
        try:
            session = self.db_manager.get_session()
            try:
                transaction = Transaction(
                    group_openid=group_id,
                    from_union_openid=user_id,
                    to_union_openid="",
                    transaction_type=trans_type,
                    amount=amount,
                    description=description
                )
                session.add(transaction)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"记录保镖交易失败: {e}")

    async def dismiss_bodyguard(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """解雇保镖"""
        try:
            bodyguard_info = self.get_active_bodyguard(user_id, group_id)
            if not bodyguard_info:
                return {"success": False, "message": "您没有雇佣保镖"}

            # 删除保镖记录
            session = self.db_manager.get_session()
            try:
                bodyguard = session.query(Bodyguard).filter_by(
                    union_openid=user_id, group_openid=group_id
                ).first()
                if bodyguard:
                    session.delete(bodyguard)
                    session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

            return {
                "success": True,
                "bodyguard_name": bodyguard_info["bodyguard_name"]
            }

        except Exception as e:
            self.logger.error(f"解雇保镖失败: {e}")
            return {"success": False, "message": "解雇保镖失败"}

    def cleanup_expired_bodyguards(self):
        """清理过期的保镖"""
        try:
            session = self.db_manager.get_session()
            try:
                expired_bodyguards = session.query(Bodyguard).filter(
                    Bodyguard.expire_time < datetime.utcnow()
                ).all()

                for bodyguard in expired_bodyguards:
                    session.delete(bodyguard)

                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"清理过期保镖失败: {e}")

    def get_bodyguard_list(self) -> List[Dict[str, Any]]:
        """获取保镖列表"""
        bodyguard_list = []
        for bg_type, info in self.bodyguard_types.items():
            bodyguard_list.append({
                "type": bg_type,
                "name": info["name"],
                "cost": info["cost"],
                "defense_rate": info["defense_rate"],
                "duration_hours": info["duration_hours"],
                "description": info["description"]
            })
        return bodyguard_list

    def get_bodyguard_stats(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """获取用户保镖统计"""
        try:
            session = self.db_manager.get_session()
            try:
                # 获取历史保镖记录
                bodyguards = session.query(Bodyguard).filter_by(
                    union_openid=user_id, group_openid=group_id
                ).all()

                stats = {
                    "total_hired": len(bodyguards),
                    "total_defense": sum(bg.defense_count for bg in bodyguards),
                    "total_counter": sum(bg.counter_count for bg in bodyguards),
                    "by_type": {}
                }

                # 按类型统计
                type_stats = {}
                for bodyguard in bodyguards:
                    bg_type = bodyguard.bodyguard_type
                    if bg_type not in type_stats:
                        type_stats[bg_type] = {
                            "hire_count": 0,
                            "defense_count": 0,
                            "counter_count": 0
                        }

                    type_stats[bg_type]["hire_count"] += 1
                    type_stats[bg_type]["defense_count"] += bodyguard.defense_count
                    type_stats[bg_type]["counter_count"] += bodyguard.counter_count

                stats["by_type"] = type_stats
                return stats

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取保镖统计失败: {e}")
            return {
                "total_hired": 0,
                "total_defense": 0,
                "total_counter": 0,
                "by_type": {}
            }
