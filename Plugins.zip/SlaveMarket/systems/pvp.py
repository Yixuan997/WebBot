"""
PvP系统
"""

import logging
import random
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple

from ..core.database import DatabaseManager, User, RobRecord, Transaction


class PvPSystem:
    """PvP系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

        # 抢劫配置
        self.min_rob_success_rate = 0.2  # 最小抢劫成功率
        self.max_rob_success_rate = 0.8  # 最大抢劫成功率
        self.min_rob_amount_rate = 0.1  # 最小抢劫金额比例
        self.max_rob_amount_rate = 0.3  # 最大抢劫金额比例
        self.rob_failure_penalty_rate = 0.05  # 抢劫失败惩罚比例
        self.max_rob_failure_penalty = 50  # 最大抢劫失败惩罚
        self.rob_cooldown_minutes = 1  # 抢劫冷却时间（分钟）
        self.min_target_currency = 10  # 最小目标金币要求

    def check_rob_cooldown(self, user: User) -> Tuple[bool, int]:
        """检查抢劫冷却时间"""
        if not user.last_rob_time:
            return True, 0

        cooldown_delta = timedelta(minutes=self.rob_cooldown_minutes)
        time_passed = datetime.utcnow() - user.last_rob_time

        if time_passed < cooldown_delta:
            remaining_seconds = int((cooldown_delta - time_passed).total_seconds())
            return False, remaining_seconds

        return True, 0

    def format_time(self, seconds: int) -> str:
        """格式化时间显示"""
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            return f"{seconds // 60}分{seconds % 60}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分钟"

    def format_currency(self, amount: float) -> str:
        """格式化金币显示"""
        return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

    def calculate_rob_success_rate(self, robber_value: float, target_value: float) -> float:
        """计算抢劫成功率"""
        value_ratio = robber_value / target_value
        success_rate = self.min_rob_success_rate + (self.max_rob_success_rate - self.min_rob_success_rate) * min(1,
                                                                                                                 value_ratio)
        return max(self.min_rob_success_rate, min(self.max_rob_success_rate, success_rate))

    def calculate_rob_amount(self, target_currency: float) -> float:
        """计算抢劫金额"""
        rob_rate = random.uniform(self.min_rob_amount_rate, self.max_rob_amount_rate)
        rob_amount = target_currency * rob_rate
        return round(rob_amount, 1)

    def calculate_failure_penalty(self, robber_currency: float) -> float:
        """计算抢劫失败惩罚"""
        penalty = robber_currency * self.rob_failure_penalty_rate
        return min(self.max_rob_failure_penalty, round(penalty, 1))

    async def rob_player(self, robber_id: str, target_id: str, group_id: str, bodyguard_system=None) -> Dict[str, Any]:
        """抢劫逻辑"""
        try:
            # 获取抢劫者和目标数据
            robber = self.db_manager.get_user(robber_id, group_id)
            target = self.db_manager.get_user(target_id, group_id)

            if not robber or not target:
                return {"success": False, "message": "用户数据不存在"}

            # 检查抢劫冷却
            can_rob, remaining = self.check_rob_cooldown(robber)
            if not can_rob:
                return {
                    "success": False,
                    "message": f"抢劫冷却中，还需等待 {self.format_time(remaining)}"
                }

            # 检查抢劫条件
            if robber_id == target_id:
                return {"success": False, "message": "不能抢劫自己"}

            if target.currency < self.min_target_currency:
                return {"success": False, "message": f"目标金币不足{self.min_target_currency}，无法抢劫"}

            # 检查是否是主奴关系
            if target.master_openid == robber_id:
                return {"success": False, "message": "不能抢劫自己的奴隶"}

            if robber.master_openid == target_id:
                return {"success": False, "message": "不能抢劫自己的主人"}

            # 计算成功率（在检查保镖防御之前计算，确保总是有这个值）
            success_rate = self.calculate_rob_success_rate(robber.value, target.value)

            # 检查保镖防御
            if bodyguard_system:
                defense_result = await bodyguard_system.check_defense(target_id, robber_id, group_id)
                if defense_result["defended"]:
                    # 保镖成功防御
                    result = {
                        "success": True,
                        "rob_success": False,
                        "defended": True,
                        "bodyguard_name": defense_result["bodyguard_name"],
                        "counter_attack": defense_result["counter_attack"],
                        "counter_damage": defense_result.get("counter_damage", 0),
                        "success_rate": success_rate  # 添加成功率
                    }

                    # 获取当前金币（可能因为反击而改变）
                    if defense_result["counter_attack"]:
                        robber = self.db_manager.get_user(robber_id, group_id)  # 重新获取更新后的数据

                    result["robber_new_currency"] = robber.currency  # 总是设置当前金币

                    # 更新抢劫时间
                    robber.last_rob_time = datetime.utcnow()
                    self.db_manager.update_user(robber)

                    return result

            # 判断是否成功
            is_success = random.random() < success_rate

            # 更新抢劫时间
            robber.last_rob_time = datetime.utcnow()

            if is_success:
                # 抢劫成功
                rob_amount = self.calculate_rob_amount(target.currency)

                # 转移金币
                target.currency -= rob_amount
                robber.currency += rob_amount
                robber.total_earned += rob_amount
                target.total_spent += rob_amount

                self.db_manager.update_user(robber)
                self.db_manager.update_user(target)

                # 记录抢劫记录
                self.record_rob(robber_id, target_id, group_id, True, rob_amount, success_rate)

                # 记录交易
                self.record_transaction(group_id, target_id, robber_id, "rob", rob_amount, "被抢劫")

                return {
                    "success": True,
                    "rob_success": True,
                    "rob_amount": rob_amount,
                    "success_rate": success_rate,
                    "robber_new_currency": robber.currency,
                    "target_new_currency": target.currency
                }
            else:
                # 抢劫失败
                penalty = self.calculate_failure_penalty(robber.currency)

                robber.currency = max(0, robber.currency - penalty)
                robber.total_spent += penalty

                self.db_manager.update_user(robber)

                # 记录抢劫记录
                self.record_rob(robber_id, target_id, group_id, False, penalty, success_rate)

                return {
                    "success": True,
                    "rob_success": False,
                    "penalty": penalty,
                    "success_rate": success_rate,
                    "robber_new_currency": robber.currency
                }

        except Exception as e:
            self.logger.error(f"抢劫逻辑处理失败: {e}")
            return {"success": False, "message": "抢劫处理失败"}

    def record_rob(self, robber_id: str, target_id: str, group_id: str,
                   success: bool, amount: float, success_rate: float):
        """记录抢劫记录"""
        try:
            session = self.db_manager.get_session()
            try:
                rob_record = RobRecord(
                    robber_openid=robber_id,
                    target_openid=target_id,
                    group_openid=group_id,
                    success=success,
                    amount=amount,
                    success_rate=success_rate
                )
                session.add(rob_record)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"记录抢劫记录失败: {e}")

    def record_transaction(self, group_id: str, from_user: str, to_user: str,
                           trans_type: str, amount: float, description: str):
        """记录交易"""
        try:
            session = self.db_manager.get_session()
            try:
                transaction = Transaction(
                    group_openid=group_id,
                    from_union_openid=from_user,
                    to_union_openid=to_user,
                    transaction_type=trans_type,
                    amount=amount,
                    description=description
                )
                session.add(transaction)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"记录交易失败: {e}")

    def get_rob_stats(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """获取用户抢劫统计"""
        try:
            session = self.db_manager.get_session()
            try:
                # 作为抢劫者的记录
                robber_records = session.query(RobRecord).filter_by(
                    robber_id=user_id, group_id=group_id
                ).all()

                # 作为目标的记录
                target_records = session.query(RobRecord).filter_by(
                    target_id=user_id, group_id=group_id
                ).all()

                # 统计抢劫者数据
                rob_attempts = len(robber_records)
                rob_successes = len([r for r in robber_records if r.success])
                rob_failures = rob_attempts - rob_successes
                total_robbed = sum(r.amount for r in robber_records if r.success)
                total_penalties = sum(r.amount for r in robber_records if not r.success)

                # 统计被抢劫数据
                robbed_times = len([r for r in target_records if r.success])
                total_lost = sum(r.amount for r in target_records if r.success)

                return {
                    'rob_attempts': rob_attempts,
                    'rob_successes': rob_successes,
                    'rob_failures': rob_failures,
                    'rob_success_rate': rob_successes / rob_attempts if rob_attempts > 0 else 0,
                    'total_robbed': total_robbed,
                    'total_penalties': total_penalties,
                    'robbed_times': robbed_times,
                    'total_lost': total_lost,
                    'net_rob_income': total_robbed - total_penalties - total_lost
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取抢劫统计失败: {e}")
            return {
                'rob_attempts': 0,
                'rob_successes': 0,
                'rob_failures': 0,
                'rob_success_rate': 0,
                'total_robbed': 0,
                'total_penalties': 0,
                'robbed_times': 0,
                'total_lost': 0,
                'net_rob_income': 0
            }

    def get_group_pvp_stats(self, group_id: str) -> Dict[str, Any]:
        """获取群组PvP统计"""
        try:
            session = self.db_manager.get_session()
            try:
                rob_records = session.query(RobRecord).filter_by(group_id=group_id).all()

                total_robs = len(rob_records)
                successful_robs = len([r for r in rob_records if r.success])
                failed_robs = total_robs - successful_robs

                total_robbed_amount = sum(r.amount for r in rob_records if r.success)
                total_penalty_amount = sum(r.amount for r in rob_records if not r.success)

                average_success_rate = sum(r.success_rate for r in rob_records) / total_robs if total_robs > 0 else 0

                return {
                    'total_robs': total_robs,
                    'successful_robs': successful_robs,
                    'failed_robs': failed_robs,
                    'success_rate': successful_robs / total_robs if total_robs > 0 else 0,
                    'total_robbed_amount': total_robbed_amount,
                    'total_penalty_amount': total_penalty_amount,
                    'average_success_rate': average_success_rate
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取群组PvP统计失败: {e}")
            return {
                'total_robs': 0,
                'successful_robs': 0,
                'failed_robs': 0,
                'success_rate': 0,
                'total_robbed_amount': 0,
                'total_penalty_amount': 0,
                'average_success_rate': 0
            }
