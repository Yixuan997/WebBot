"""
成就称号系统
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, List

from ..core.database import DatabaseManager, UserAchievement, UserTitle, SlaveRelation, RobRecord, WorkRecord


class AchievementSystem:
    """成就称号系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

        # 成就定义
        self.achievements = {
            # 工作相关成就
            "first_work": {
                "name": "初入职场",
                "description": "完成第一次工作",
                "icon": "💼",
                "type": "work",
                "condition": lambda stats: stats.get("work_count", 0) >= 1,
                "reward_currency": 10,
                "title": "新手"
            },
            "hard_worker": {
                "name": "勤劳工作者",
                "description": "累计工作100次",
                "icon": "🏭",
                "type": "work",
                "condition": lambda stats: stats.get("work_count", 0) >= 100,
                "reward_currency": 200,
                "title": "劳模"
            },
            "workaholic": {
                "name": "工作狂",
                "description": "累计工作500次",
                "icon": "⚙️",
                "type": "work",
                "condition": lambda stats: stats.get("work_count", 0) >= 500,
                "reward_currency": 1000,
                "title": "工作狂"
            },

            # 财富相关成就
            "first_hundred": {
                "name": "小有积蓄",
                "description": "拥有100金币",
                "icon": "💰",
                "type": "wealth",
                "condition": lambda stats: stats.get("currency", 0) >= 100,
                "reward_currency": 20,
                "title": "小富翁"
            },
            "millionaire": {
                "name": "百万富翁",
                "description": "拥有1000金币",
                "icon": "💎",
                "type": "wealth",
                "condition": lambda stats: stats.get("currency", 0) >= 1000,
                "reward_currency": 500,
                "title": "富豪"
            },
            "tycoon": {
                "name": "商业大亨",
                "description": "拥有10000金币",
                "icon": "👑",
                "type": "wealth",
                "condition": lambda stats: stats.get("currency", 0) >= 10000,
                "reward_currency": 2000,
                "title": "大亨"
            },

            # 交易相关成就
            "first_purchase": {
                "name": "初次交易",
                "description": "购买第一个牛马",
                "icon": "🛒",
                "type": "trade",
                "condition": lambda stats: stats.get("purchase_count", 0) >= 1,
                "reward_currency": 50,
                "title": "商人"
            },
            "slave_master": {
                "name": "牛马主",
                "description": "同时拥有5个牛马",
                "icon": "👑",
                "type": "trade",
                "condition": lambda stats: stats.get("slave_count", 0) >= 5,
                "reward_currency": 300,
                "title": "牛马主"
            },
            "slave_emperor": {
                "name": "牛马皇帝",
                "description": "同时拥有20个牛马",
                "icon": "🏰",
                "type": "trade",
                "condition": lambda stats: stats.get("slave_count", 0) >= 20,
                "reward_currency": 1500,
                "title": "皇帝"
            },

            # PvP相关成就
            "first_rob": {
                "name": "初次抢劫",
                "description": "成功抢劫一次",
                "icon": "⚔️",
                "type": "pvp",
                "condition": lambda stats: stats.get("rob_successes", 0) >= 1,
                "reward_currency": 30,
                "title": "强盗"
            },
            "robber_king": {
                "name": "抢劫之王",
                "description": "成功抢劫50次",
                "icon": "🗡️",
                "type": "pvp",
                "condition": lambda stats: stats.get("rob_successes", 0) >= 50,
                "reward_currency": 500,
                "title": "盗王"
            },
            "untouchable": {
                "name": "不败传说",
                "description": "连续防御成功10次抢劫",
                "icon": "🛡️",
                "type": "pvp",
                "condition": lambda stats: stats.get("defense_streak", 0) >= 10,
                "reward_currency": 800,
                "title": "不败"
            },

            # 特殊成就
            "freedom_fighter": {
                "name": "自由斗士",
                "description": "成功赎身5次",
                "icon": "🆓",
                "type": "special",
                "condition": lambda stats: stats.get("freedom_count", 0) >= 5,
                "reward_currency": 400,
                "title": "自由者"
            },
            "survivor": {
                "name": "生存专家",
                "description": "被抢劫100次仍然存活",
                "icon": "🏃",
                "type": "special",
                "condition": lambda stats: stats.get("robbed_times", 0) >= 100,
                "reward_currency": 600,
                "title": "生存者"
            },
            "lucky_one": {
                "name": "幸运儿",
                "description": "工作时触发50次随机事件",
                "icon": "🍀",
                "type": "special",
                "condition": lambda stats: stats.get("random_events", 0) >= 50,
                "reward_currency": 300,
                "title": "幸运星"
            }
        }

        # 称号等级
        self.title_levels = {
            "新手": 1,
            "商人": 2,
            "小富翁": 2,
            "强盗": 2,
            "劳模": 3,
            "富豪": 4,
            "牛马主": 4,
            "自由者": 4,
            "工作狂": 5,
            "盗王": 5,
            "生存者": 5,
            "幸运星": 5,
            "大亨": 6,
            "皇帝": 7,
            "不败": 8
        }

        # 成就表已在数据库模型中定义，无需单独创建

    def format_currency(self, amount: float) -> str:
        """格式化金币显示"""
        return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

    async def check_achievements(self, user_id: str, group_id: str) -> List[Dict[str, Any]]:
        """检查并解锁成就"""
        try:
            # 获取用户统计数据
            user_stats = await self.get_user_stats(user_id, group_id)

            # 获取已解锁的成就
            unlocked_achievements = self.get_user_achievements(user_id, group_id)
            unlocked_ids = {ach["achievement_id"] for ach in unlocked_achievements}

            new_achievements = []

            # 检查每个成就
            for achievement_id, achievement in self.achievements.items():
                if achievement_id not in unlocked_ids:
                    # 检查是否满足条件
                    if achievement["condition"](user_stats):
                        # 解锁成就
                        success = await self.unlock_achievement(user_id, group_id, achievement_id)
                        if success:
                            new_achievements.append({
                                "id": achievement_id,
                                "name": achievement["name"],
                                "description": achievement["description"],
                                "icon": achievement["icon"],
                                "reward_currency": achievement["reward_currency"],
                                "title": achievement["title"]
                            })

            return new_achievements

        except Exception as e:
            self.logger.error(f"检查成就失败: {e}")
            return []

    async def get_user_stats(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """获取用户统计数据"""
        try:
            # 获取基础用户数据
            user = self.db_manager.get_user(user_id, group_id)
            if not user:
                return {}

            stats = {
                "currency": user.currency,
                "value": user.value,
                "work_count": user.work_count,
                "purchase_count": user.purchase_count,
                "freedom_count": getattr(user, 'freedom_count', 0),
                "total_earned": user.total_earned,
                "total_spent": user.total_spent
            }

            # 获取牛马数量
            session = self.db_manager.get_session()
            try:
                # 牛马数量
                slave_count = session.query(SlaveRelation).filter_by(
                    master_openid=user_id, group_openid=group_id
                ).count()
                stats["slave_count"] = slave_count

                # 抢劫统计
                rob_records = session.query(RobRecord).filter_by(
                    robber_openid=user_id, group_openid=group_id
                ).all()

                stats["rob_successes"] = len([r for r in rob_records if r.success])
                stats["rob_attempts"] = len(rob_records)

                # 被抢劫次数
                robbed_count = session.query(RobRecord).filter(
                    RobRecord.target_openid == user_id,
                    RobRecord.group_openid == group_id,
                    RobRecord.success == True
                ).count()
                stats["robbed_times"] = robbed_count

                # 随机事件次数（从工作记录中统计）
                event_count = session.query(WorkRecord).filter(
                    WorkRecord.union_openid == user_id,
                    WorkRecord.group_openid == group_id,
                    WorkRecord.event_message != ''
                ).count()
                stats["random_events"] = event_count

                # 防御连胜（这里简化处理，实际需要更复杂的逻辑）
                stats["defense_streak"] = 0  # 需要额外的逻辑来计算

            finally:
                self.db_manager.close_session(session)

            return stats

        except Exception as e:
            self.logger.error(f"获取用户统计失败: {e}")
            return {}

    async def unlock_achievement(self, user_id: str, group_id: str, achievement_id: str) -> bool:
        """解锁成就"""
        try:
            achievement = self.achievements.get(achievement_id)
            if not achievement:
                return False

            session = self.db_manager.get_session()
            try:
                # 检查是否已存在
                existing_achievement = session.query(UserAchievement).filter_by(
                    union_openid=user_id, group_openid=group_id, achievement_id=achievement_id
                ).first()

                if not existing_achievement:
                    # 记录成就解锁
                    user_achievement = UserAchievement(
                        union_openid=user_id,
                        group_openid=group_id,
                        achievement_id=achievement_id,
                        unlock_time=datetime.utcnow()
                    )
                    session.add(user_achievement)

                # 解锁称号
                title = achievement["title"]
                existing_title = session.query(UserTitle).filter_by(
                    union_openid=user_id, group_openid=group_id, title=title
                ).first()

                if not existing_title:
                    user_title = UserTitle(
                        union_openid=user_id,
                        group_openid=group_id,
                        title=title,
                        unlock_time=datetime.utcnow()
                    )
                    session.add(user_title)

                session.commit()

                # 发放奖励
                if achievement["reward_currency"] > 0:
                    user = self.db_manager.get_user(user_id, group_id)
                    if user:
                        user.currency += achievement["reward_currency"]
                        user.total_earned += achievement["reward_currency"]
                        self.db_manager.update_user(user)

                self.logger.info(f"用户 {user_id} 解锁成就: {achievement['name']}")
                return True

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"解锁成就失败: {e}")
            return False

    def get_user_achievements(self, user_id: str, group_id: str) -> List[Dict[str, Any]]:
        """获取用户已解锁的成就"""
        try:
            session = self.db_manager.get_session()
            try:
                from sqlalchemy import text
                results = session.execute(text("""
                                               SELECT achievement_id, unlock_time
                                               FROM user_achievements
                                               WHERE union_openid = :user_id
                                                 AND group_openid = :group_id
                                               ORDER BY unlock_time DESC
                                               """), {"user_id": user_id, "group_id": group_id}).fetchall()

                achievements = []
                for result in results:
                    achievement_id = result[0]
                    unlock_time = result[1]

                    # 格式化时间显示
                    formatted_time = "未知"
                    if unlock_time:
                        try:
                            if isinstance(unlock_time, str):
                                # 如果是字符串，尝试解析
                                from datetime import datetime
                                dt = datetime.fromisoformat(unlock_time.replace('Z', '+00:00'))
                                formatted_time = dt.strftime('%Y-%m-%d %H:%M')
                            else:
                                # 如果是datetime对象
                                formatted_time = unlock_time.strftime('%Y-%m-%d %H:%M')
                        except Exception:
                            formatted_time = str(unlock_time)

                    if achievement_id in self.achievements:
                        achievement = self.achievements[achievement_id]
                        achievements.append({
                            "achievement_id": achievement_id,
                            "name": achievement["name"],
                            "description": achievement["description"],
                            "icon": achievement["icon"],
                            "type": achievement["type"],
                            "unlock_time": formatted_time
                        })

                return achievements

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取用户成就失败: {e}")
            return []

    def get_user_titles(self, union_openid: str, group_openid: str) -> List[Dict[str, Any]]:
        """获取用户称号"""
        try:
            session = self.db_manager.get_session()
            try:
                from ..core.database import UserTitle

                # 使用ORM查询
                user_titles = session.query(UserTitle).filter_by(
                    union_openid=union_openid,
                    group_openid=group_openid
                ).order_by(UserTitle.unlock_time.desc()).all()

                titles = []
                for user_title in user_titles:
                    titles.append({
                        "title": user_title.title,
                        "active": bool(user_title.active),
                        "level": self.title_levels.get(user_title.title, 1),
                        "unlock_time": user_title.unlock_time
                    })

                return titles

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取用户称号失败: {e}")
            return []

    async def set_active_title(self, union_openid: str, group_openid: str, title: str) -> bool:
        """设置活跃称号"""
        try:
            session = self.db_manager.get_session()
            try:
                # 检查用户是否拥有该称号
                from ..core.database import UserTitle

                user_title = session.query(UserTitle).filter_by(
                    user_id=union_openid,
                    group_id=group_openid,
                    title=title
                ).first()

                if not user_title:
                    return False

                # 取消所有活跃称号
                session.query(UserTitle).filter_by(
                    user_id=union_openid,
                    group_id=group_openid
                ).update({"active": False})

                # 设置新的活跃称号
                user_title.active = True

                session.commit()
                return True

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"设置活跃称号失败: {e}")
            return False

    def get_active_title(self, union_openid: str, group_openid: str) -> str:
        """获取用户当前活跃称号"""
        try:
            session = self.db_manager.get_session()
            try:
                from ..core.database import UserTitle

                user_title = session.query(UserTitle).filter_by(
                    union_openid=union_openid,
                    group_openid=group_openid,
                    active=True
                ).first()

                return user_title.title if user_title else ""

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取活跃称号失败: {e}")
            return ""

    def get_achievement_progress(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """获取成就进度"""
        try:
            user_stats = asyncio.run(self.get_user_stats(user_id, group_id))
            unlocked_achievements = self.get_user_achievements(user_id, group_id)
            unlocked_ids = {ach["achievement_id"] for ach in unlocked_achievements}

            progress = {
                "total_achievements": len(self.achievements),
                "unlocked_count": len(unlocked_achievements),
                "progress_rate": len(unlocked_achievements) / len(self.achievements),
                "by_type": {},
                "next_achievements": []
            }

            # 按类型统计
            type_stats = {}
            for achievement_id, achievement in self.achievements.items():
                achievement_type = achievement["type"]
                if achievement_type not in type_stats:
                    type_stats[achievement_type] = {"total": 0, "unlocked": 0}

                type_stats[achievement_type]["total"] += 1
                if achievement_id in unlocked_ids:
                    type_stats[achievement_type]["unlocked"] += 1

            progress["by_type"] = type_stats

            # 即将解锁的成就
            for achievement_id, achievement in self.achievements.items():
                if achievement_id not in unlocked_ids:
                    # 这里可以添加进度计算逻辑
                    progress["next_achievements"].append({
                        "id": achievement_id,
                        "name": achievement["name"],
                        "description": achievement["description"],
                        "icon": achievement["icon"]
                    })

            return progress

        except Exception as e:
            self.logger.error(f"获取成就进度失败: {e}")
            return {
                "total_achievements": 0,
                "unlocked_count": 0,
                "progress_rate": 0,
                "by_type": {},
                "next_achievements": []
            }
