"""
QQ认证系统
"""

import asyncio
from datetime import datetime, timedelta
from typing import Optional

import requests

from Core.message.builder import MessageBuilder
from ..core.database import DatabaseManager, QQBinding


class AuthSystem:
    """QQ认证系统"""

    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager

        # QQ绑定相关配置
        self.qq_auth_base_url = "https://q.qq.com/ide/devtoolAuth"
        self.qzone_base_url = "https://h5.qzone.qq.com/qqq/code"
        self.auth_timeout = 300  # 授权超时时间（秒）
        self.check_interval = 10  # 检查间隔（秒）

    async def get_qq_auth_code(self) -> Optional[str]:
        """获取QQ授权码"""
        try:
            url = f"{self.qq_auth_base_url}/GetLoginCode"
            response = requests.get(url, timeout=10)

            if response.status_code == 200:
                data = response.json()
                if data.get("code") == 0:
                    auth_code = data.get("data", {}).get("code")
                    return auth_code

            return None

        except Exception as e:
            return None

    async def check_qq_auth_status(self, code: str) -> Optional[str]:
        """检查QQ授权状态并获取QQ号"""
        try:
            url = f"{self.qq_auth_base_url}/syncScanSateGetTicket"
            params = {"code": code}

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()

                if data.get("code") == 0:
                    # 根据实际返回的数据结构来解析QQ号
                    ticket_data = data.get("data", {})

                    # 可能的QQ号字段名
                    qq_number = (ticket_data.get("qq") or
                                 ticket_data.get("uin") or
                                 ticket_data.get("openid") or
                                 ticket_data.get("qq_number"))

                    if qq_number:
                        # 确保QQ号是纯数字字符串
                        qq_str = str(qq_number).strip()
                        if qq_str.isdigit():
                            return qq_str

            return None

        except Exception as e:
            return None

    async def bind_qq_number(self, union_openid: str, group_openid: str, qq_number: str) -> bool:
        """绑定QQ号"""
        try:
            # 保存绑定信息到数据库
            success = self.db_manager.save_qq_binding(union_openid, group_openid, qq_number)

            return success

        except Exception as e:
            return False

    async def get_bound_qq(self, union_openid: str, group_openid: str) -> Optional[str]:
        """获取已绑定的QQ号"""
        try:
            result = self.db_manager.get_qq_binding(union_openid, group_openid)
            return result
        except Exception as e:
            return None

    async def start_qq_bind_process(self, union_openid: str, group_openid: str,
                                    original_msg_id: str = None, reply_msg_id: str = None,
                                    bot_id: int = None) -> MessageBuilder:
        """开始QQ绑定流程"""
        try:
            # 获取授权码
            auth_code = await self.get_qq_auth_code()

            if not auth_code:
                return MessageBuilder.text("❌ 获取授权码失败，请稍后重试")

            # 保存授权码和用户信息的关联（包含原始消息信息）
            success = self.db_manager.save_auth_code(auth_code, union_openid, group_openid,
                                                     original_msg_id, reply_msg_id, bot_id)
            if not success:
                return MessageBuilder.text("❌ 保存授权信息失败，请稍后重试")

            # 生成授权链接
            auth_url = f"{self.qzone_base_url}/{auth_code}?_proxy=1&from=ide"
            # 将.com换成大写.COM
            auth_url = auth_url.replace('.com', '.COM')

            # 启动后台检查任务（使用线程方式）
            import threading
            thread = threading.Thread(target=self._run_check_in_thread, args=(auth_code,))
            thread.daemon = True
            thread.start()

            # 使用text_card_link
            content = f"🔗 QQ号绑定\n\n"
            content += f"请点击下方链接完成QQ号绑定，绑定后即可开始游戏！\n\n"
            content += f"⏰ 链接5分钟内有效"

            result = MessageBuilder.text_card_link(
                text=content,
                button_text="🔗 点击登录",
                button_url=auth_url,
                description="奴隶帝国",
                prompt="WebBot"
            )
            return result

        except Exception as e:
            return MessageBuilder.text("❌ 绑定流程启动失败，请稍后重试")

    def _run_check_in_thread(self, auth_code: str):
        """在线程中运行检查任务"""
        try:
            import time
            print(f"[DEBUG] 后台检查线程启动，授权码: {auth_code}")

            # 只检查2次，每10秒检查一次
            max_checks = 2
            print(f"[DEBUG] 最大检查次数: {max_checks}, 检查间隔: {self.check_interval}秒")

            for check_count in range(max_checks):
                print(f"[DEBUG] 开始第 {check_count + 1} 次检查")
                time.sleep(self.check_interval)

                # 检查授权码是否还有效
                try:
                    code_info = self.db_manager.get_auth_code_info(auth_code)
                    if not code_info or code_info.get('used'):
                        break
                except Exception as e:
                    continue

                # 检查是否超时
                create_time = code_info['create_time']
                if isinstance(create_time, str):
                    create_time = datetime.fromisoformat(create_time)

                if datetime.utcnow() - create_time > timedelta(seconds=self.auth_timeout):
                    break

                # 检查授权状态（同步方式）
                print(f"[DEBUG] 检查授权状态，授权码: {auth_code}")
                qq_number = self.check_qq_auth_status_sync(auth_code)
                print(f"[DEBUG] 授权检查结果，QQ号: {qq_number}")

                if qq_number:
                    union_openid = code_info["union_openid"]
                    group_openid = code_info["group_openid"]
                    print(f"[DEBUG] 检测到绑定成功，准备保存绑定信息")

                    # 绑定QQ号（同步方式）
                    success = self.bind_qq_number_sync(union_openid, group_openid, qq_number)
                    print(f"[DEBUG] 绑定保存结果: {success}")

                    if success:
                        # 标记授权码已使用
                        self.db_manager.mark_auth_code_used(auth_code)

                        try:
                            # 获取原始消息信息
                            original_msg_id = code_info.get('original_msg_id')
                            reply_msg_id = code_info.get('reply_msg_id')
                            bot_id = code_info.get('bot_id')

                            print(f"[DEBUG] 绑定成功，准备发送第二条消息")
                            print(f"[DEBUG] 消息信息 - original_msg_id: {original_msg_id}, reply_msg_id: {reply_msg_id}, bot_id: {bot_id}")
                            print(f"[DEBUG] 用户信息 - union_openid: {union_openid}, group_openid: {group_openid}, qq_number: {qq_number}")

                            self._send_bind_success_message(union_openid, group_openid, qq_number,
                                                            original_msg_id, reply_msg_id, bot_id)
                        except Exception as msg_e:
                            print(f"[ERROR] 发送绑定成功消息失败: {msg_e}")
                            import traceback
                            traceback.print_exc()

                        break

        except Exception as e:
            pass

    def _send_bind_success_message(self, union_openid: str, group_openid: str, qq_number: str,
                                   original_msg_id: str = None, reply_msg_id: str = None, bot_id: int = None):
        """发送绑定成功消息"""
        try:
            print(f"[DEBUG] 开始发送绑定成功消息")
            print(f"[DEBUG] 参数 - qq_number: {qq_number}, bot_id: {bot_id}")

            # 构建成功消息（使用卡片格式）
            content = f"🆔 绑定QQ号: {qq_number}\n"
            content += f"🎮 现在可以开始游戏了！\n\n"
            content += f"💡 发送 '牛马菜单' 查看游戏命令"

            success_message = MessageBuilder.text_card(
                text=f"🎉 QQ号绑定成功！\n\n{content}",
                description="牛马市场",
                prompt="SlaveMarket"
            )
            print(f"[DEBUG] 成功消息构建完成: {success_message}")

            # 在后台线程中需要创建Flask应用上下文
            print(f"[DEBUG] 准备获取Flask应用上下文")
            from flask import current_app
            try:
                # 尝试获取当前应用上下文
                app = current_app._get_current_object()
                print(f"[DEBUG] 获取到当前应用上下文")
            except RuntimeError:
                # 如果没有应用上下文，导入应用实例
                print(f"[DEBUG] 没有当前应用上下文，导入应用实例")
                from app import app

            # 在应用上下文中执行
            print(f"[DEBUG] 在应用上下文中执行")
            with app.app_context():
                from Adapters import get_adapter_manager
                adapter_manager = get_adapter_manager()
                print(f"[DEBUG] 获取到适配器管理器: {adapter_manager}")

                if adapter_manager:
                    # 构建目标（群聊）
                    target = f"group:{group_openid}"
                    # 使用保存的bot_id，如果没有则使用默认值
                    actual_bot_id = bot_id or 2

                    print(f"[DEBUG] 准备发送消息 - target: {target}, bot_id: {actual_bot_id}")
                    print(f"[DEBUG] 消息参数 - reply_to_msg_id: {reply_msg_id}, original_msg_id: {original_msg_id}")

                    # 检查适配器状态
                    running_adapters = adapter_manager.get_running_adapters()
                    print(f"[DEBUG] 运行中的适配器: {running_adapters}")

                    # 使用原始消息信息进行回复
                    success = adapter_manager.send_message(actual_bot_id, target, success_message,
                                                           reply_to_msg_id=reply_msg_id,
                                                           original_msg_id=original_msg_id)
                    print(f"[DEBUG] 消息发送结果: {success}")
                else:
                    print(f"[ERROR] 适配器管理器为空")
        except Exception as e:
            print(f"[ERROR] 发送绑定成功消息异常: {e}")
            import traceback
            traceback.print_exc()

    def check_qq_auth_status_sync(self, code: str) -> Optional[str]:
        """检查QQ授权状态并获取QQ号（同步版本）"""
        try:
            url = f"{self.qq_auth_base_url}/syncScanSateGetTicket"
            params = {"code": code}

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()

                if data.get("code") == 0:
                    # 根据实际返回的数据结构来解析QQ号
                    ticket_data = data.get("data", {})

                    # 可能的QQ号字段名
                    qq_number = (ticket_data.get("qq") or
                                 ticket_data.get("uin") or
                                 ticket_data.get("openid") or
                                 ticket_data.get("qq_number"))

                    if qq_number:
                        # 确保QQ号是纯数字字符串
                        qq_str = str(qq_number).strip()
                        if qq_str.isdigit():
                            return qq_str

            return None

        except Exception as e:
            return None

    def bind_qq_number_sync(self, union_openid: str, group_openid: str, qq_number: str) -> bool:
        """绑定QQ号（同步版本）"""
        try:

            # 检查是否已经绑定过
            existing_qq = self.db_manager.get_qq_binding(union_openid, group_openid)
            if existing_qq:
                return False

            # 执行绑定
            success = self.db_manager.save_qq_binding(union_openid, group_openid, qq_number)
            return success

        except Exception as e:
            return False

    async def check_auth_result(self, auth_code: str):
        """后台检查授权结果"""
        try:
            # 检查5分钟，每10秒检查一次
            max_checks = self.auth_timeout // self.check_interval

            for check_count in range(max_checks):
                await asyncio.sleep(self.check_interval)

                # 检查授权码是否还有效
                try:
                    code_info = self.db_manager.get_auth_code_info(auth_code)
                    if not code_info or code_info.get('used'):
                        break
                except Exception as e:
                    continue

                # 检查是否超时
                create_time = code_info['create_time']
                if isinstance(create_time, str):
                    create_time = datetime.fromisoformat(create_time)

                if datetime.utcnow() - create_time > timedelta(seconds=self.auth_timeout):
                    break

                # 检查授权状态
                qq_number = await self.check_qq_auth_status(auth_code)

                if qq_number:
                    union_openid = code_info["union_openid"]
                    group_openid = code_info["group_openid"]

                    # 绑定QQ号
                    success = await self.bind_qq_number(union_openid, group_openid, qq_number)

                    if success:
                        # 标记授权码已使用
                        self.db_manager.mark_auth_code_used(auth_code)

                    break

            # 清理过期的授权码
            self.db_manager.cleanup_expired_auth_codes(5)

        except Exception as e:
            pass

    async def handle_bind_qq(self, union_openid: str, group_openid: str) -> MessageBuilder:
        """处理绑定QQ命令"""
        try:
            # 检查是否已经绑定
            bound_qq = await self.get_bound_qq(union_openid, group_openid)
            if bound_qq:
                return MessageBuilder.text(f"✅ 您已绑定QQ号: {bound_qq}\n可以开始游戏了！")

            # 开始绑定流程
            return await self.start_qq_bind_process(union_openid, group_openid)

        except Exception as e:
            return MessageBuilder.text("❌ 绑定处理失败，请稍后重试")

    async def is_user_bound(self, union_openid: str, group_openid: str) -> bool:
        """检查用户是否已绑定QQ号"""
        bound_qq = await self.get_bound_qq(union_openid, group_openid)
        return bound_qq is not None

    async def require_qq_bind(self, union_openid: str, group_openid: str) -> Optional[MessageBuilder]:
        """要求用户绑定QQ号"""
        is_bound = await self.is_user_bound(union_openid, group_openid)
        if not is_bound:
            return MessageBuilder.text(
                "❌ 请先绑定QQ号才能使用此功能\n\n"
                "发送：牛马绑定"
            )
        return None

    async def unbind_qq(self, union_openid: str, group_openid: str) -> bool:
        """解绑QQ号（管理员功能）"""
        try:
            session = self.db_manager.get_session()
            try:
                from ..core.database import QQBinding, User, SlaveRelation

                # 删除绑定记录
                session.query(QQBinding).filter_by(
                    union_openid=union_openid, group_openid=group_openid
                ).delete()

                # 删除用户游戏数据
                session.query(User).filter_by(
                    union_openid=union_openid, group_openid=group_openid
                ).delete()

                # 删除奴隶关系
                session.query(SlaveRelation).filter(
                    ((SlaveRelation.master_openid == union_openid) | (SlaveRelation.slave_openid == union_openid)) &
                    (SlaveRelation.group_openid == group_openid)
                ).delete()

                session.commit()
                return True

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            return False

    def get_bind_statistics(self, group_id: str) -> dict:
        """获取绑定统计信息"""
        try:
            session = self.db_manager.get_session()
            try:
                from ..core.database import QQBinding

                # 总绑定数
                total_binds = session.query(QQBinding).filter_by(group_id=group_id).count()

                # 今日绑定数
                today_start = datetime.utcnow() - timedelta(days=1)
                today_binds = session.query(QQBinding).filter(
                    QQBinding.group_id == group_id,
                    QQBinding.bind_time > today_start
                ).count()

                return {
                    'total_binds': total_binds,
                    'today_binds': today_binds
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            return {'total_binds': 0, 'today_binds': 0}

    def get_all_bound_users(self, group_openid: str) -> list:
        """获取群内所有已绑定QQ的用户openid列表（通过group_openid字段）"""
        try:
            session = self.db_manager.get_session()
            try:
                # 查询该群内所有已绑定的用户
                bindings = session.query(QQBinding).filter_by(
                    group_openid=group_openid
                ).all()

                union_openids = [binding.union_openid for binding in bindings]
                return union_openids

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            return []

    async def get_user_by_qq(self, qq_number: str, group_openid: str) -> Optional[str]:
        """根据QQ号获取用户的union_openid"""
        try:
            session = self.db_manager.get_session()
            try:
                binding = session.query(QQBinding).filter_by(
                    qq_number=qq_number, group_openid=group_openid
                ).first()

                if binding:
                    return binding.union_openid
                return None

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            return None
