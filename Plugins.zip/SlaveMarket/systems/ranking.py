"""
排行榜系统
"""

import logging
from typing import List, Dict, Any

from sqlalchemy import func, desc

from ..core.database import DatabaseManager, User, SlaveRelation


class RankingSystem:
    """排行榜系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

    def format_currency(self, amount: float) -> str:
        """格式化金币显示 - 中文单位"""
        if amount is None:
            return "0"

        amount = float(amount)

        # 小于1万，正常显示
        if amount < 10000:
            return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

        # 1万到9999万，显示万单位
        elif amount < 100000000:  # 小于1亿
            wan_amount = amount / 10000
            if wan_amount % 1 != 0:
                return f"{wan_amount:.1f}万"
            else:
                return f"{int(wan_amount)}万"

        # 1亿以上，显示亿单位
        else:
            yi_amount = amount / 100000000
            if yi_amount % 1 != 0:
                return f"{yi_amount:.1f}亿"
            else:
                return f"{int(yi_amount)}亿"

    def get_value_ranking(self, group_openid: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取身价排行榜"""
        try:
            session = self.db_manager.get_session()
            try:
                # 查询用户并计算奴隶数量
                results = session.query(
                    User,
                    func.count(SlaveRelation.slave_openid).label('slave_count')
                ).outerjoin(
                    SlaveRelation,
                    (User.union_openid == SlaveRelation.master_openid) &
                    (User.group_openid == SlaveRelation.group_openid)
                ).filter(
                    User.group_openid == group_openid
                ).group_by(
                    User.id
                ).order_by(
                    desc(User.value)
                ).limit(limit).all()

                ranking = []
                for user, slave_count in results:
                    # 直接使用User表中的qq_number，如果为空则使用默认值
                    qq_number = user.qq_number if user.qq_number else "未知"

                    ranking.append({
                        'union_openid': user.union_openid,
                        'qq_number': qq_number,
                        'value': self.format_currency(user.value),
                        'currency': self.format_currency(user.currency),
                        'work_count': user.work_count,
                        'slave_count': slave_count or 0,
                        'master_id': user.master_openid
                    })

                return ranking

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取身价排行榜失败: {e}")
            return []

    def get_currency_ranking(self, group_openid: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取金币排行榜"""
        try:
            session = self.db_manager.get_session()
            try:
                # 查询用户并计算奴隶数量
                results = session.query(
                    User,
                    func.count(SlaveRelation.slave_openid).label('slave_count')
                ).outerjoin(
                    SlaveRelation,
                    (User.union_openid == SlaveRelation.master_openid) &
                    (User.group_openid == SlaveRelation.group_openid)
                ).filter(
                    User.group_openid == group_openid
                ).group_by(
                    User.id
                ).order_by(
                    desc(User.currency)
                ).limit(limit).all()

                ranking = []
                for user, slave_count in results:
                    # 直接使用User表中的qq_number，如果为空则使用默认值
                    qq_number = user.qq_number if user.qq_number else "未知"

                    ranking.append({
                        'union_openid': user.union_openid,
                        'qq_number': qq_number,
                        'value': self.format_currency(user.value),
                        'currency': self.format_currency(user.currency),
                        'work_count': user.work_count,
                        'slave_count': slave_count or 0,
                        'master_id': user.master_openid
                    })

                return ranking

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取金币排行榜失败: {e}")
            return []

    def get_slave_ranking(self, group_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取奴隶数量排行榜"""
        try:
            session = self.db_manager.get_session()
            try:
                results = session.query(
                    User,
                    func.count(SlaveRelation.slave_id).label('slave_count')
                ).join(
                    SlaveRelation,
                    (User.user_id == SlaveRelation.master_id) &
                    (User.group_id == SlaveRelation.group_id)
                ).filter(
                    User.group_id == group_id
                ).group_by(
                    User.id
                ).having(
                    func.count(SlaveRelation.slave_id) > 0
                ).order_by(
                    desc(func.count(SlaveRelation.slave_id))
                ).limit(limit).all()

                ranking = []
                for user, slave_count in results:
                    ranking.append({
                        'user_id': user.user_id,
                        'qq_number': user.qq_number,
                        'value': user.value,
                        'currency': user.currency,
                        'work_count': user.work_count,
                        'slave_count': slave_count,
                        'master_id': user.master_id
                    })

                return ranking

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取奴隶数量排行榜失败: {e}")
            return []

    def get_work_ranking(self, group_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取工作次数排行榜"""
        try:
            session = self.db_manager.get_session()
            try:
                results = session.query(
                    User,
                    func.count(SlaveRelation.slave_id).label('slave_count')
                ).outerjoin(
                    SlaveRelation,
                    (User.user_id == SlaveRelation.master_id) &
                    (User.group_id == SlaveRelation.group_id)
                ).filter(
                    User.group_id == group_id
                ).group_by(
                    User.id
                ).order_by(
                    desc(User.work_count)
                ).limit(limit).all()

                ranking = []
                for user, slave_count in results:
                    ranking.append({
                        'user_id': user.user_id,
                        'qq_number': user.qq_number,
                        'value': user.value,
                        'currency': user.currency,
                        'work_count': user.work_count,
                        'slave_count': slave_count or 0,
                        'master_id': user.master_id
                    })

                return ranking

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取工作次数排行榜失败: {e}")
            return []

    def get_earned_ranking(self, group_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取总收入排行榜"""
        try:
            session = self.db_manager.get_session()
            try:
                results = session.query(
                    User,
                    func.count(SlaveRelation.slave_id).label('slave_count')
                ).outerjoin(
                    SlaveRelation,
                    (User.user_id == SlaveRelation.master_id) &
                    (User.group_id == SlaveRelation.group_id)
                ).filter(
                    User.group_id == group_id
                ).group_by(
                    User.id
                ).order_by(
                    desc(User.total_earned)
                ).limit(limit).all()

                ranking = []
                for user, slave_count in results:
                    ranking.append({
                        'user_id': user.user_id,
                        'qq_number': user.qq_number,
                        'value': user.value,
                        'currency': user.currency,
                        'work_count': user.work_count,
                        'slave_count': slave_count or 0,
                        'total_earned': user.total_earned,
                        'master_id': user.master_id
                    })

                return ranking

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取总收入排行榜失败: {e}")
            return []

    def get_comprehensive_ranking(self, group_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取综合排行榜（基于身价、金币、奴隶数量的综合评分）"""
        try:
            session = self.db_manager.get_session()
            try:
                results = session.query(
                    User,
                    func.count(SlaveRelation.slave_id).label('slave_count')
                ).outerjoin(
                    SlaveRelation,
                    (User.user_id == SlaveRelation.master_id) &
                    (User.group_id == SlaveRelation.group_id)
                ).filter(
                    User.group_id == group_id
                ).group_by(
                    User.id
                ).all()

                # 计算综合评分
                ranking = []
                for user, slave_count in results:
                    # 综合评分 = 身价 * 0.4 + 金币 * 0.3 + 奴隶数量 * 50 * 0.3
                    score = (user.value * 0.4 +
                             user.currency * 0.3 +
                             (slave_count or 0) * 50 * 0.3)

                    ranking.append({
                        'user_id': user.user_id,
                        'qq_number': user.qq_number,
                        'value': user.value,
                        'currency': user.currency,
                        'work_count': user.work_count,
                        'slave_count': slave_count or 0,
                        'score': round(score, 1),
                        'master_id': user.master_id
                    })

                # 按评分排序
                ranking.sort(key=lambda x: x['score'], reverse=True)
                return ranking[:limit]

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取综合排行榜失败: {e}")
            return []

    def get_user_rank(self, user_id: str, group_id: str, rank_type: str = "value") -> Dict[str, Any]:
        """获取用户在指定排行榜中的排名"""
        try:
            # 获取对应的排行榜
            if rank_type == "value":
                ranking = self.get_value_ranking(group_id, 100)  # 获取更多数据以找到用户排名
            elif rank_type == "currency":
                ranking = self.get_currency_ranking(group_id, 100)
            elif rank_type == "slave":
                ranking = self.get_slave_ranking(group_id, 100)
            elif rank_type == "work":
                ranking = self.get_work_ranking(group_id, 100)
            elif rank_type == "earned":
                ranking = self.get_earned_ranking(group_id, 100)
            elif rank_type == "comprehensive":
                ranking = self.get_comprehensive_ranking(group_id, 100)
            else:
                return {"rank": 0, "total": 0, "user_data": None}

            # 查找用户排名
            for i, user_data in enumerate(ranking, 1):
                if user_data['user_id'] == user_id:
                    return {
                        "rank": i,
                        "total": len(ranking),
                        "user_data": user_data
                    }

            return {"rank": 0, "total": len(ranking), "user_data": None}

        except Exception as e:
            self.logger.error(f"获取用户排名失败: {e}")
            return {"rank": 0, "total": 0, "user_data": None}

    def get_ranking_summary(self, group_id: str) -> Dict[str, Any]:
        """获取排行榜摘要信息"""
        try:
            session = self.db_manager.get_session()
            try:
                # 获取基础统计
                total_users = session.query(User).filter_by(group_id=group_id).count()

                if total_users == 0:
                    return {
                        'total_users': 0,
                        'richest_user': None,
                        'highest_value_user': None,
                        'most_slaves_user': None,
                        'most_active_user': None
                    }

                # 最富有的用户
                richest = session.query(User).filter_by(group_id=group_id).order_by(desc(User.currency)).first()

                # 身价最高的用户
                highest_value = session.query(User).filter_by(group_id=group_id).order_by(desc(User.value)).first()

                # 奴隶最多的用户
                most_slaves_result = session.query(
                    User, func.count(SlaveRelation.slave_id).label('slave_count')
                ).join(
                    SlaveRelation,
                    (User.user_id == SlaveRelation.master_id) &
                    (User.group_id == SlaveRelation.group_id)
                ).filter(
                    User.group_id == group_id
                ).group_by(User.id).order_by(desc(func.count(SlaveRelation.slave_id))).first()

                # 最活跃的用户（工作次数最多）
                most_active = session.query(User).filter_by(group_id=group_id).order_by(desc(User.work_count)).first()

                return {
                    'total_users': total_users,
                    'richest_user': {
                        'qq_number': richest.qq_number,
                        'currency': richest.currency
                    } if richest else None,
                    'highest_value_user': {
                        'qq_number': highest_value.qq_number,
                        'value': highest_value.value
                    } if highest_value else None,
                    'most_slaves_user': {
                        'qq_number': most_slaves_result[0].qq_number,
                        'slave_count': most_slaves_result[1]
                    } if most_slaves_result else None,
                    'most_active_user': {
                        'qq_number': most_active.qq_number,
                        'work_count': most_active.work_count
                    } if most_active else None
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取排行榜摘要失败: {e}")
            return {
                'total_users': 0,
                'richest_user': None,
                'highest_value_user': None,
                'most_slaves_user': None,
                'most_active_user': None
            }
