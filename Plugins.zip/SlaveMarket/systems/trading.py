"""
交易系统
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, List

from ..core.database import DatabaseManager, User, SlaveRelation, Transaction


class TradingSystem:
    """交易系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

        # 交易配置
        self.value_increase_per_purchase = 20  # 每次被购买身价增加
        self.freedom_cost_multiplier = 2  # 赎身费用倍数
        self.value_decrease_on_freedom = 0.1  # 赎身后身价下降比例
        self.purchase_cooldown_minutes = 0  # 购买冷却时间（分钟）

    def check_purchase_cooldown(self, user: User) -> Tuple[bool, int]:
        """检查购买冷却时间"""
        if not user.last_purchase_time:
            return True, 0

        cooldown_delta = timedelta(minutes=self.purchase_cooldown_minutes)
        time_passed = datetime.utcnow() - user.last_purchase_time

        if time_passed < cooldown_delta:
            remaining_seconds = int((cooldown_delta - time_passed).total_seconds())
            return False, remaining_seconds

        return True, 0

    def format_time(self, seconds: int) -> str:
        """格式化时间显示"""
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            return f"{seconds // 60}分{seconds % 60}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分钟"

    def format_currency(self, amount: float) -> str:
        """格式化金币显示"""
        return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

    async def purchase_slave(self, buyer_openid: str, target_openid: str, group_openid: str) -> Dict[str, Any]:
        """购买牛马逻辑"""
        try:
            # 获取买家和目标数据
            buyer = self.db_manager.get_user(buyer_openid, group_openid)
            target = self.db_manager.get_user(target_openid, group_openid)

            if not buyer or not target:
                return {"success": False, "message": "用户数据不存在"}

            # 检查购买冷却
            can_purchase, remaining = self.check_purchase_cooldown(buyer)
            if not can_purchase:
                return {
                    "success": False,
                    "message": f"购买冷却中，还需等待 {self.format_time(remaining)}"
                }

            # 检查购买条件
            if buyer_openid == target_openid:
                return {"success": False, "message": "不能购买自己"}

            if target.master_openid == buyer_openid:
                return {"success": False, "message": "对方已经是您的牛马"}

            if buyer.master_openid == target_openid:
                return {"success": False, "message": "不能购买自己的主人"}

            # 检查金币是否足够
            target_value = target.value
            buyer_currency = buyer.currency

            if buyer_currency < target_value:
                return {
                    "success": False,
                    "message": f"金币不足，需要 {self.format_currency(target_value)} 金币，您只有 {self.format_currency(buyer_currency)} 金币"
                }

            # 执行购买
            old_master = target.master_openid

            # 扣除买家金币
            buyer.currency = round(buyer.currency - target_value, 1)
            buyer.total_spent = round(buyer.total_spent + target_value, 1)
            buyer.purchase_count += 1
            buyer.last_purchase_time = datetime.utcnow()

            # 如果有原主人，给原主人转账
            old_master_user = None
            if old_master:
                old_master_user = self.db_manager.get_user(old_master, group_openid)
                if old_master_user:
                    # 原主人获得购买金额
                    old_master_user.currency = round(old_master_user.currency + target_value, 1)
                    old_master_user.total_earned = round(old_master_user.total_earned + target_value, 1)
                    self.db_manager.update_user(old_master_user)

            # 更新目标数据
            target.master_openid = buyer_openid
            target.value = round(target.value + self.value_increase_per_purchase, 1)
            target.sold_count += 1

            # 保存数据
            self.db_manager.update_user(buyer)
            self.db_manager.update_user(target)

            # 更新牛马关系
            self.update_slave_relation(buyer_openid, target_openid, group_openid, target_value)

            # 记录交易
            self.record_transaction(group_openid, buyer_openid, target_openid, "purchase", target_value,
                                    f"购买牛马，身价 {self.format_currency(target_value)}")

            # 如果有原主人，记录原主人收到的金币
            if old_master and old_master_user:
                self.record_transaction(group_openid, buyer_openid, old_master, "sale", target_value,
                                        f"出售牛马，获得 {self.format_currency(target_value)} 金币")

            return {
                "success": True,
                "cost": target_value,
                "target_new_value": target.value,
                "buyer_new_currency": buyer.currency,
                "old_master": old_master,
                "old_master_earned": target_value if old_master else 0
            }

        except Exception as e:
            self.logger.error(f"购买奴隶逻辑处理失败: {e}")
            return {"success": False, "message": "购买处理失败"}

    async def release_slave(self, master_openid: str, slave_openid: str, group_openid: str) -> Dict[str, Any]:
        """释放牛马逻辑"""
        try:
            # 获取主人和奴隶数据
            master = self.db_manager.get_user(master_openid, group_openid)
            slave = self.db_manager.get_user(slave_openid, group_openid)

            if not master or not slave:
                return {"success": False, "message": "用户数据不存在"}

            # 检查是否是自己的牛马
            if slave.master_openid != master_openid:
                return {"success": False, "message": "对方不是您的牛马"}

            # 执行释放
            slave.master_openid = ""
            self.db_manager.update_user(slave)

            # 删除牛马关系
            self.remove_slave_relation(master_openid, slave_openid, group_openid)

            # 记录交易
            self.record_transaction(group_openid, master_openid, slave_openid, "release", 0, "释放牛马")

            return {
                "success": True,
                "slave_qq": slave.qq_number
            }

        except Exception as e:
            self.logger.error(f"释放牛马逻辑处理失败: {e}")
            return {"success": False, "message": "释放处理失败"}

    async def buy_back_freedom(self, union_openid: str, group_openid: str) -> Dict[str, Any]:
        """赎身逻辑"""
        try:
            user = self.db_manager.get_user(union_openid, group_openid)
            if not user:
                return {"success": False, "message": "用户数据不存在"}

            master_openid = user.master_openid
            if not master_openid:
                return {"success": False, "message": "您已经是自由身"}

            # 计算赎身费用
            current_value = user.value
            freedom_cost = current_value * self.freedom_cost_multiplier
            user_currency = user.currency

            if user_currency < freedom_cost:
                return {
                    "success": False,
                    "message": f"金币不足，赎身需要 {self.format_currency(freedom_cost)} 金币，您只有 {self.format_currency(user_currency)} 金币"
                }

            # 执行赎身
            user.currency = round(user.currency - freedom_cost, 1)
            user.total_spent = round(user.total_spent + freedom_cost, 1)
            user.master_openid = ""
            user.value = round(max(100, current_value * (1 - self.value_decrease_on_freedom)), 1)
            user.freedom_count += 1

            self.db_manager.update_user(user)

            # 删除奴隶关系
            self.remove_slave_relation(master_openid, union_openid, group_openid)

            # 记录交易
            self.record_transaction(group_openid, union_openid, "", "freedom", freedom_cost, "赎身获得自由")

            return {
                "success": True,
                "cost": freedom_cost,
                "new_value": user.value,
                "new_currency": user.currency,
                "master_id": master_openid
            }

        except Exception as e:
            self.logger.error(f"赎身逻辑处理失败: {e}")
            return {"success": False, "message": "赎身处理失败"}

    def update_slave_relation(self, master_openid: str, slave_openid: str, group_openid: str, price: float):
        """更新奴隶关系"""
        try:
            session = self.db_manager.get_session()
            try:
                # 删除旧的关系
                session.query(SlaveRelation).filter_by(
                    slave_openid=slave_openid, group_openid=group_openid
                ).delete()

                # 插入新的关系
                relation = SlaveRelation(
                    master_openid=master_openid,
                    slave_openid=slave_openid,
                    group_openid=group_openid,
                    purchase_price=price
                )
                session.add(relation)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"更新奴隶关系失败: {e}")

    def remove_slave_relation(self, master_openid: str, slave_openid: str, group_openid: str):
        """删除奴隶关系"""
        try:
            session = self.db_manager.get_session()
            try:
                session.query(SlaveRelation).filter_by(
                    master_openid=master_openid,
                    slave_openid=slave_openid,
                    group_openid=group_openid
                ).delete()
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"删除奴隶关系失败: {e}")

    def record_transaction(self, group_openid: str, from_user: str, to_user: str,
                           trans_type: str, amount: float, description: str):
        """记录交易"""
        try:
            session = self.db_manager.get_session()
            try:
                transaction = Transaction(
                    group_openid=group_openid,
                    from_union_openid=from_user,
                    to_union_openid=to_user,
                    transaction_type=trans_type,
                    amount=amount,
                    description=description
                )
                session.add(transaction)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"记录交易失败: {e}")

    def get_user_slaves(self, union_openid: str, group_openid: str) -> List[Dict[str, Any]]:
        """获取用户的奴隶列表"""
        try:
            session = self.db_manager.get_session()
            try:
                # 使用JOIN查询获取奴隶信息
                results = session.query(User, SlaveRelation).join(
                    SlaveRelation, User.union_openid == SlaveRelation.slave_openid
                ).filter(
                    SlaveRelation.master_openid == union_openid,
                    SlaveRelation.group_openid == group_openid,
                    User.group_openid == group_openid
                ).all()

                slaves = []
                for user, relation in results:
                    slaves.append({
                        'union_openid': user.union_openid,
                        'qq_number': user.qq_number,
                        'value': user.value,
                        'currency': user.currency,
                        'purchase_time': relation.purchase_time,
                        'purchase_price': relation.purchase_price
                    })

                return slaves

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取奴隶列表失败: {e}")
            return []

    def get_trading_stats(self, group_id: str) -> Dict[str, Any]:
        """获取交易统计"""
        try:
            session = self.db_manager.get_session()
            try:
                # 获取交易记录
                transactions = session.query(Transaction).filter_by(group_id=group_id).all()

                purchase_count = len([t for t in transactions if t.transaction_type == 'purchase'])
                release_count = len([t for t in transactions if t.transaction_type == 'release'])
                freedom_count = len([t for t in transactions if t.transaction_type == 'freedom'])

                purchase_volume = sum(t.amount for t in transactions if t.transaction_type == 'purchase')
                freedom_volume = sum(t.amount for t in transactions if t.transaction_type == 'freedom')

                # 获取奴隶关系统计
                slave_relations = session.query(SlaveRelation).filter_by(group_id=group_id).all()
                active_slaves = len(slave_relations)

                return {
                    'purchase_count': purchase_count,
                    'release_count': release_count,
                    'freedom_count': freedom_count,
                    'purchase_volume': purchase_volume,
                    'freedom_volume': freedom_volume,
                    'active_slaves': active_slaves,
                    'total_transactions': len(transactions)
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取交易统计失败: {e}")
            return {
                'purchase_count': 0,
                'release_count': 0,
                'freedom_count': 0,
                'purchase_volume': 0,
                'freedom_volume': 0,
                'active_slaves': 0,
                'total_transactions': 0
            }
