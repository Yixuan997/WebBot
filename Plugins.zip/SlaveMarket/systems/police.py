"""
公安局举报系统
"""

import logging
import random
from datetime import datetime, timedelta
from typing import Dict, Any, List

from sqlalchemy import func

from ..core.database import DatabaseManager, Report, JailRecord


class PoliceSystem:
    """公安局举报系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

        # 举报配置
        self.report_cost = 20  # 举报费用
        self.report_cooldown_hours = 1  # 举报冷却时间（小时）
        self.investigation_duration_hours = 1/6  # 调查时间（10分钟）

        # 处罚配置
        self.penalties = {
            "warning": {
                "name": "警告",
                "probability": 0.4,
                "currency_penalty": 0,
                "jail_hours": 0,
                "description": "口头警告，不予处罚"
            },
            "fine": {
                "name": "罚款",
                "probability": 0.3,
                "currency_penalty": 0.1,  # 罚款比例
                "jail_hours": 0,
                "description": "罚款10%金币"
            },
            "detention": {
                "name": "拘留",
                "probability": 0.2,
                "currency_penalty": 0.05,
                "jail_hours": 6,
                "description": "拘留6小时，期间无法进行任何操作"
            },
            "arrest": {
                "name": "逮捕",
                "probability": 0.1,
                "currency_penalty": 0.2,
                "jail_hours": 24,
                "description": "逮捕24小时，罚款20%金币"
            }
        }

        # 举报类型
        self.report_types = {
            "robbery": {
                "name": "抢劫",
                "description": "举报恶意抢劫行为",
                "evidence_required": True
            },
            "harassment": {
                "name": "骚扰",
                "description": "举报恶意骚扰行为",
                "evidence_required": False
            },
            "fraud": {
                "name": "诈骗",
                "description": "举报诈骗行为",
                "evidence_required": True
            },
            "abuse": {
                "name": "虐待",
                "description": "举报虐待牛马行为",
                "evidence_required": False
            }
        }

        # 公安局表已在数据库模型中定义，无需单独创建

    def format_currency(self, amount: float) -> str:
        """格式化金币显示"""
        return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

    def format_investigation_time(self) -> str:
        """格式化调查时间显示"""
        if self.investigation_duration_hours >= 1:
            hours = int(self.investigation_duration_hours)
            return f"{hours}小时"
        else:
            minutes = int(self.investigation_duration_hours * 60)
            return f"{minutes}分钟"

    def format_time(self, seconds: int) -> str:
        """格式化时间显示"""
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            return f"{seconds // 60}分{seconds % 60}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分钟"

    async def submit_report(self, reporter_id: str, reported_id: str, group_id: str,
                            report_type: str, description: str = "", evidence: str = "") -> Dict[str, Any]:
        """提交举报"""
        try:
            # 检查举报类型
            if report_type not in self.report_types:
                return {"success": False, "message": "无效的举报类型"}

            # 检查是否举报自己
            if reporter_id == reported_id:
                return {"success": False, "message": "不能举报自己"}

            # 获取举报者数据
            reporter = self.db_manager.get_user(reporter_id, group_id)
            if not reporter:
                return {"success": False, "message": "举报者数据不存在"}

            # 检查被举报者是否存在
            reported = self.db_manager.get_user(reported_id, group_id)
            if not reported:
                return {"success": False, "message": "被举报者不存在"}

            # 检查举报冷却
            if not self.check_report_cooldown(reporter_id, group_id):
                return {
                    "success": False,
                    "message": f"举报冷却中，请等待{self.report_cooldown_hours}小时后再举报"
                }

            # 检查金币是否足够
            if reporter.currency < self.report_cost:
                return {
                    "success": False,
                    "message": f"举报费用不足，需要 {self.format_currency(self.report_cost)} 金币"
                }

            # 检查是否需要证据
            report_info = self.report_types[report_type]
            if report_info["evidence_required"] and not evidence:
                return {
                    "success": False,
                    "message": f"举报{report_info['name']}需要提供证据"
                }

            # 扣除举报费用
            reporter.currency -= self.report_cost
            reporter.total_spent += self.report_cost
            self.db_manager.update_user(reporter)

            # 创建举报记录
            session = self.db_manager.get_session()
            try:
                report = Report(
                    reporter_openid=reporter_id,
                    reported_openid=reported_id,
                    group_openid=group_id,
                    report_type=report_type,
                    description=description,
                    evidence=evidence,
                    create_time=datetime.utcnow()
                )
                session.add(report)
                session.commit()

                report_id = report.id

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

            # 启动调查流程
            import asyncio
            asyncio.create_task(self.investigate_report(report_id))

            return {
                "success": True,
                "report_id": report_id,
                "report_type": report_info["name"],
                "cost": self.report_cost,
                "investigation_time": self.format_investigation_time(),
                "new_currency": reporter.currency
            }

        except Exception as e:
            self.logger.error(f"提交举报失败: {e}")
            return {"success": False, "message": "提交举报失败"}

    def check_report_cooldown(self, user_id: str, group_id: str) -> bool:
        """检查举报冷却"""
        try:
            session = self.db_manager.get_session()
            try:
                cooldown_time = datetime.utcnow() - timedelta(hours=self.report_cooldown_hours)

                recent_reports = session.query(Report).filter(
                    Report.reporter_openid == user_id,
                    Report.group_openid == group_id,
                    Report.create_time > cooldown_time
                ).count()

                return recent_reports == 0

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"检查举报冷却失败: {e}")
            return False

    async def investigate_report(self, report_id: int):
        """调查举报"""
        try:
            # 等待调查时间
            await asyncio.sleep(self.investigation_duration_hours * 3600)

            # 获取举报信息
            session = self.db_manager.get_session()
            try:
                report = session.query(Report).filter_by(
                    id=report_id,
                    status='pending'
                ).first()

                if not report:
                    return

                reported_id = report.reported_openid
                group_id = report.group_openid
                report_type = report.report_type

                # 随机决定处罚结果
                penalty_type = self.determine_penalty()
                penalty_info = self.penalties[penalty_type]

                # 执行处罚
                penalty_result = await self.execute_penalty(reported_id, group_id, penalty_type, report_type)

                # 更新举报状态
                report.status = 'processed'
                report.result = penalty_result["description"]
                report.penalty_type = penalty_type
                report.penalty_amount = penalty_result.get("penalty_amount", 0)
                report.process_time = datetime.utcnow()
                session.commit()

                self.logger.info(f"举报 {report_id} 调查完成，处罚类型: {penalty_type}")

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"调查举报失败: {e}")

    def get_user_reports(self, user_id: str, group_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取用户的举报记录"""
        try:
            session = self.db_manager.get_session()
            try:
                # 查询用户提交的举报记录，按时间倒序
                reports = session.query(Report).filter(
                    Report.reporter_openid == user_id,
                    Report.group_openid == group_id
                ).order_by(Report.create_time.desc()).limit(limit).all()

                result = []
                for report in reports:
                    # 获取被举报者的QQ号
                    reported_user = self.db_manager.get_user(report.reported_openid, group_id)
                    reported_qq = reported_user.qq_number if reported_user and reported_user.qq_number else "未知用户"

                    result.append({
                        'id': report.id,
                        'report_type': report.report_type,
                        'reported_openid': report.reported_openid,
                        'reported_qq': reported_qq,
                        'description': report.description,
                        'evidence': report.evidence,
                        'status': report.status,
                        'result': report.result,
                        'penalty_type': report.penalty_type,
                        'penalty_amount': report.penalty_amount,
                        'create_time': report.create_time,
                        'process_time': report.process_time
                    })

                return result

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取用户举报记录失败: {e}")
            return []

    def determine_penalty(self) -> str:
        """决定处罚类型"""
        rand = random.random()
        cumulative_prob = 0

        for penalty_type, info in self.penalties.items():
            cumulative_prob += info["probability"]
            if rand <= cumulative_prob:
                return penalty_type

        return "warning"  # 默认警告

    async def execute_penalty(self, user_id: str, group_id: str, penalty_type: str, reason: str) -> Dict[str, Any]:
        """执行处罚"""
        try:
            penalty_info = self.penalties[penalty_type]
            user = self.db_manager.get_user(user_id, group_id)

            if not user:
                return {"description": "用户不存在，无法执行处罚"}

            penalty_amount = 0

            # 执行金币处罚
            if penalty_info["currency_penalty"] > 0:
                penalty_amount = user.currency * penalty_info["currency_penalty"]
                penalty_amount = round(penalty_amount, 1)

                user.currency = max(0, user.currency - penalty_amount)
                user.total_spent += penalty_amount
                self.db_manager.update_user(user)

            # 执行监禁
            if penalty_info["jail_hours"] > 0:
                await self.jail_user(user_id, group_id, penalty_type, penalty_info["jail_hours"], reason)

            return {
                "description": penalty_info["description"],
                "penalty_amount": penalty_amount,
                "jail_hours": penalty_info["jail_hours"]
            }

        except Exception as e:
            self.logger.error(f"执行处罚失败: {e}")
            return {"description": "处罚执行失败"}

    async def jail_user(self, user_id: str, group_id: str, penalty_type: str, hours: int, reason: str):
        """监禁用户"""
        try:
            start_time = datetime.utcnow()
            end_time = start_time + timedelta(hours=hours)

            session = self.db_manager.get_session()
            try:
                # 删除现有的监禁记录
                existing = session.query(JailRecord).filter_by(
                    union_openid=user_id,
                    group_openid=group_id
                ).first()
                if existing:
                    session.delete(existing)

                # 创建新的监禁记录
                jail_record = JailRecord(
                    union_openid=user_id,
                    group_openid=group_id,
                    penalty_type=penalty_type,
                    start_time=start_time,
                    end_time=end_time,
                    reason=reason
                )
                session.add(jail_record)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"监禁用户失败: {e}")

    def is_user_jailed(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """检查用户是否被监禁"""
        try:
            session = self.db_manager.get_session()
            try:
                jail_record = session.query(JailRecord).filter(
                    JailRecord.union_openid == user_id,
                    JailRecord.group_openid == group_id,
                    JailRecord.end_time > datetime.utcnow()
                ).first()

                if jail_record:
                    remaining_seconds = int((jail_record.end_time - datetime.utcnow()).total_seconds())

                    return {
                        "jailed": True,
                        "penalty_type": jail_record.penalty_type,
                        "end_time": jail_record.end_time,
                        "remaining_seconds": remaining_seconds,
                        "reason": jail_record.reason
                    }

                return {"jailed": False}

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"检查监禁状态失败: {e}")
            return {"jailed": False}

    def get_report_history(self, user_id: str, group_id: str, as_reporter: bool = True) -> List[Dict[str, Any]]:
        """获取举报历史"""
        try:
            session = self.db_manager.get_session()
            try:
                if as_reporter:
                    reports = session.query(Report).filter(
                        Report.reporter_openid == user_id,
                        Report.group_openid == group_id
                    ).order_by(Report.create_time.desc()).limit(10).all()
                else:
                    reports = session.query(Report).filter(
                        Report.reported_openid == user_id,
                        Report.group_openid == group_id
                    ).order_by(Report.create_time.desc()).limit(10).all()

                history = []
                for report in reports:
                    history.append({
                        "id": report.id,
                        "reporter_id": report.reporter_openid,
                        "reported_id": report.reported_openid,
                        "report_type": report.report_type,
                        "description": report.description,
                        "status": report.status,
                        "result": report.result,
                        "penalty_type": report.penalty_type,
                        "create_time": report.create_time,
                        "process_time": report.process_time
                    })

                return history

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取举报历史失败: {e}")
            return []

    def cleanup_old_records(self, days: int = 30):
        """清理旧记录"""
        try:
            session = self.db_manager.get_session()
            try:
                cutoff_time = datetime.utcnow() - timedelta(days=days)

                # 清理旧举报记录
                session.execute("""
                                DELETE
                                FROM reports
                                WHERE create_time < ?
                                """, (cutoff_time,))

                # 清理过期监禁记录
                session.execute("""
                                DELETE
                                FROM jail_records
                                WHERE end_time < ?
                                """, (datetime.utcnow(),))

                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"清理旧记录失败: {e}")

    def get_police_stats(self, group_id: str) -> Dict[str, Any]:
        """获取公安局统计"""
        try:
            session = self.db_manager.get_session()
            try:
                # 总举报数
                total_reports = session.query(Report).filter_by(group_openid=group_id).count()

                # 已处理举报数
                processed_reports = session.query(Report).filter(
                    Report.group_openid == group_id,
                    Report.status == 'processed'
                ).count()

                # 各类处罚统计
                penalty_stats = session.query(
                    Report.penalty_type,
                    func.count(Report.penalty_type)
                ).filter(
                    Report.group_openid == group_id,
                    Report.penalty_type.isnot(None)
                ).group_by(Report.penalty_type).all()

                penalty_counts = {penalty[0]: penalty[1] for penalty in penalty_stats}

                # 当前监禁人数
                current_jailed = session.query(JailRecord).filter(
                    JailRecord.group_openid == group_id,
                    JailRecord.end_time > datetime.utcnow()
                ).count()

                return {
                    "total_reports": total_reports,
                    "processed_reports": processed_reports,
                    "pending_reports": total_reports - processed_reports,
                    "penalty_counts": penalty_counts,
                    "current_jailed": current_jailed
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取公安局统计失败: {e}")
            return {
                "total_reports": 0,
                "processed_reports": 0,
                "pending_reports": 0,
                "penalty_counts": {},
                "current_jailed": 0
            }
