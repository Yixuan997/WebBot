"""
经济系统
"""

import logging
import random
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple

from ..core.database import DatabaseManager, User, WorkRecord, Transaction


class EconomySystem:
    """经济系统"""

    def __init__(self, db_manager: DatabaseManager, logger: logging.Logger):
        self.db_manager = db_manager
        self.logger = logger

        # 经济配置
        self.base_work_income = 10  # 基础工作收入
        self.work_income_variance = 0.5  # 工作收入浮动比例
        self.master_share_rate = 0.3  # 主人分成比例
        self.work_cooldown_minutes = 1  # 工作冷却时间（分钟）

        # 随机事件配置
        self.event_probability = 0.2  # 随机事件概率
        self.event_cost_rate = 0.5  # 随机事件最大费用比例

    def check_work_cooldown(self, user: User) -> Tuple[bool, int]:
        """检查工作冷却时间"""
        if not user.last_work_time:
            return True, 0

        cooldown_delta = timedelta(minutes=self.work_cooldown_minutes)
        time_passed = datetime.utcnow() - user.last_work_time

        if time_passed < cooldown_delta:
            remaining_seconds = int((cooldown_delta - time_passed).total_seconds())
            return False, remaining_seconds

        return True, 0

    def format_time(self, seconds: int) -> str:
        """格式化时间显示"""
        if seconds < 60:
            return f"{seconds}秒"
        elif seconds < 3600:
            return f"{seconds // 60}分{seconds % 60}秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{hours}小时{minutes}分钟"

    def format_currency(self, amount: float) -> str:
        """格式化金币显示"""
        return f"{amount:.1f}" if amount % 1 != 0 else f"{int(amount)}"

    def get_work_types(self):
        """获取工作类型配置"""
        return {
            "搬砖": {
                "emoji": "🧱",
                "base_income": 8.0,
                "variance": 0.3,
                "descriptions": [
                    "在工地搬了一天砖",
                    "帮助建筑工人搬运砖块",
                    "在建筑工地辛苦劳作",
                    "搬砖虽累但收获满满"
                ]
            },
            "送外卖": {
                "emoji": "🛵",
                "base_income": 12.0,
                "variance": 0.4,
                "descriptions": [
                    "骑着小电驴送了一天外卖",
                    "穿梭在城市街道送餐",
                    "风雨无阻地配送美食",
                    "今天的外卖订单特别多"
                ]
            },
            "写代码": {
                "emoji": "💻",
                "base_income": 15.0,
                "variance": 0.5,
                "descriptions": [
                    "敲了一天代码，修复了几个bug",
                    "开发新功能，代码运行完美",
                    "在键盘上挥洒汗水",
                    "又是一个996的日子"
                ]
            },
            "直播": {
                "emoji": "📱",
                "base_income": 10.0,
                "variance": 0.8,
                "descriptions": [
                    "直播了几小时，收到不少打赏",
                    "今天直播间人气很旺",
                    "和粉丝们愉快互动",
                    "直播唱歌获得观众喜爱"
                ]
            },
            "摆摊": {
                "emoji": "🏪",
                "base_income": 6.0,
                "variance": 0.6,
                "descriptions": [
                    "在夜市摆摊卖小商品",
                    "今天摊位生意不错",
                    "和顾客讨价还价",
                    "摆摊虽辛苦但很充实"
                ]
            },
            "跑腿": {
                "emoji": "🏃",
                "base_income": 9.0,
                "variance": 0.3,
                "descriptions": [
                    "帮人跑腿办事",
                    "今天跑了好几趟腿",
                    "为客户提供便民服务",
                    "跑腿工作锻炼了身体"
                ]
            },
            "家教": {
                "emoji": "📚",
                "base_income": 18.0,
                "variance": 0.2,
                "descriptions": [
                    "给学生辅导功课",
                    "今天的学生很认真听讲",
                    "分享知识获得成就感",
                    "帮助孩子提高成绩"
                ]
            },
            "设计": {
                "emoji": "🎨",
                "base_income": 14.0,
                "variance": 0.4,
                "descriptions": [
                    "完成了一个设计项目",
                    "创意灵感爆发的一天",
                    "客户对设计很满意",
                    "用创意换取报酬"
                ]
            }
        }

    def calculate_work_income(self) -> tuple:
        """计算工作收入，返回(收入, 工作类型, 描述)"""
        work_types = self.get_work_types()

        # 随机选择工作类型
        work_type = random.choice(list(work_types.keys()))
        work_config = work_types[work_type]

        # 计算收入
        variance = random.uniform(-work_config["variance"], work_config["variance"])
        income = work_config["base_income"] * (1 + variance)
        income = max(1, round(income, 1))  # 最少1金币

        # 随机选择描述
        description = random.choice(work_config["descriptions"])

        return income, work_type, work_config["emoji"], description

    def generate_random_event(self, income: float) -> Tuple[float, str]:
        """生成随机事件"""
        if random.random() >= self.event_probability:
            return 0, ""

        event_cost = random.uniform(1, income * self.event_cost_rate)
        event_cost = round(event_cost, 1)

        event_messages = [
            f"工作时不小心弄坏了工具，赔偿了 {self.format_currency(event_cost)} 金币",
            f"路上买了点零食，花费了 {self.format_currency(event_cost)} 金币",
            f"帮助了一位老人，花费了 {self.format_currency(event_cost)} 金币",
            f"交通费用 {self.format_currency(event_cost)} 金币",
            f"请同事喝咖啡，花费了 {self.format_currency(event_cost)} 金币",
            f"买了彩票，花费了 {self.format_currency(event_cost)} 金币"
        ]

        return event_cost, random.choice(event_messages)

    async def work(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """工作逻辑"""
        try:
            user = self.db_manager.get_user(user_id, group_id)
            if not user:
                return {"success": False, "message": "用户数据不存在"}

            # 检查冷却时间
            can_work, remaining = self.check_work_cooldown(user)
            if not can_work:
                return {
                    "success": False,
                    "message": f"工作冷却中，还需等待 {self.format_time(remaining)}"
                }

            # 计算收入和工作类型
            income, work_type, work_emoji, work_description = self.calculate_work_income()

            # 检查是否是牛马
            master_openid = user.master_openid
            master_income = 0

            if master_openid:
                # 牛马工作，主人获得分成
                master_income = income * self.master_share_rate
                income = income * (1 - self.master_share_rate)

                # 更新主人金币
                master = self.db_manager.get_user(master_openid, group_id)
                if master:
                    master.currency = round(master.currency + master_income, 1)
                    master.total_earned = round(master.total_earned + master_income, 1)
                    self.db_manager.update_user(master)

            # 生成随机事件
            event_cost, event_message = self.generate_random_event(income)
            income = max(0, income - event_cost)

            # 更新用户数据
            user.currency = round(user.currency + income, 1)
            user.total_earned = round(user.total_earned + income, 1)
            user.work_count += 1
            user.last_work_time = datetime.utcnow()

            self.db_manager.update_user(user)

            # 记录工作记录
            self.record_work(user_id, group_id, income, master_income, master_openid, event_message, work_type)

            # 记录交易
            if income > 0:
                self.record_transaction(group_id, "", user_id, "work", income, "工作收入")

            return {
                "success": True,
                "income": income,
                "master_income": master_income,
                "master_id": master_openid,
                "event_message": event_message,
                "event_cost": event_cost,
                "new_currency": user.currency,
                "work_type": work_type,
                "work_emoji": work_emoji,
                "work_description": work_description
            }

        except Exception as e:
            self.logger.error(f"工作逻辑处理失败: {e}")
            return {"success": False, "message": "工作处理失败"}

    def record_work(self, user_id: str, group_id: str, income: float,
                    master_income: float, master_openid: str, event_message: str, work_type: str = '工作'):
        """记录工作记录"""
        try:
            session = self.db_manager.get_session()
            try:
                work_record = WorkRecord(
                    union_openid=user_id,
                    group_openid=group_id,
                    income=income,
                    master_income=master_income,
                    master_openid=master_openid,
                    event_message=event_message,
                    work_type=work_type
                )
                session.add(work_record)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"记录工作记录失败: {e}")

    def record_transaction(self, group_id: str, from_user: str, to_user: str,
                           trans_type: str, amount: float, description: str):
        """记录交易"""
        try:
            session = self.db_manager.get_session()
            try:
                transaction = Transaction(
                    group_openid=group_id,
                    from_union_openid=from_user,
                    to_union_openid=to_user,
                    transaction_type=trans_type,
                    amount=amount,
                    description=description
                )
                session.add(transaction)
                session.commit()

            except Exception:
                session.rollback()
                raise
            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"记录交易失败: {e}")

    def get_user_work_stats(self, user_id: str, group_id: str) -> Dict[str, Any]:
        """获取用户工作统计"""
        try:
            session = self.db_manager.get_session()
            try:
                # 获取工作记录统计
                work_records = session.query(WorkRecord).filter_by(
                    union_openid=user_id, group_openid=group_id
                ).all()

                total_income = sum(record.income for record in work_records)
                total_master_income = sum(record.master_income for record in work_records)
                work_count = len(work_records)

                # 获取最近工作时间
                user = self.db_manager.get_user(user_id, group_id)
                last_work_time = user.last_work_time if user else None

                return {
                    'total_income': total_income,
                    'total_master_income': total_master_income,
                    'work_count': work_count,
                    'last_work_time': last_work_time,
                    'average_income': total_income / work_count if work_count > 0 else 0
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取用户工作统计失败: {e}")
            return {
                'total_income': 0,
                'total_master_income': 0,
                'work_count': 0,
                'last_work_time': None,
                'average_income': 0
            }

    def get_group_economy_stats(self, group_id: str) -> Dict[str, Any]:
        """获取群组经济统计"""
        try:
            session = self.db_manager.get_session()
            try:
                # 获取所有用户
                users = session.query(User).filter_by(group_id=group_id).all()

                total_currency = sum(user.currency for user in users)
                total_value = sum(user.value for user in users)
                total_earned = sum(user.total_earned for user in users)
                total_spent = sum(user.total_spent for user in users)

                # 获取交易统计
                transactions = session.query(Transaction).filter_by(group_id=group_id).all()
                transaction_count = len(transactions)
                transaction_volume = sum(trans.amount for trans in transactions)

                return {
                    'user_count': len(users),
                    'total_currency': total_currency,
                    'total_value': total_value,
                    'total_earned': total_earned,
                    'total_spent': total_spent,
                    'transaction_count': transaction_count,
                    'transaction_volume': transaction_volume,
                    'average_currency': total_currency / len(users) if users else 0,
                    'average_value': total_value / len(users) if users else 0
                }

            finally:
                self.db_manager.close_session(session)

        except Exception as e:
            self.logger.error(f"获取群组经济统计失败: {e}")
            return {
                'user_count': 0,
                'total_currency': 0,
                'total_value': 0,
                'total_earned': 0,
                'total_spent': 0,
                'transaction_count': 0,
                'transaction_volume': 0,
                'average_currency': 0,
                'average_value': 0
            }
