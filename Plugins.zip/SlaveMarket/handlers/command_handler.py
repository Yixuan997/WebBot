"""
命令处理器
"""

import logging
import re
from typing import Dict, Any, Optional

from Core.message.builder import MessageBuilder
from ..systems.achievement import AchievementSystem
from ..systems.auth import AuthSystem
from ..systems.bodyguard import BodyguardSystem
from ..systems.economy import EconomySystem
from ..systems.police import PoliceSystem
from ..systems.pvp import PvPSystem
from ..systems.ranking import RankingSystem
from ..systems.render import RenderSystem
from ..systems.trading import TradingSystem


class CommandHandler:
    """命令处理器"""

    def __init__(self, auth_system: AuthSystem, economy_system: EconomySystem,
                 trading_system: TradingSystem, pvp_system: PvPSystem,
                 ranking_system: RankingSystem, render_system: RenderSystem,
                 bodyguard_system: BodyguardSystem, police_system: PoliceSystem,
                 achievement_system: AchievementSystem, logger: logging.Logger):
        self.auth_system = auth_system
        self.economy_system = economy_system
        self.trading_system = trading_system
        self.pvp_system = pvp_system
        self.ranking_system = ranking_system
        self.render_system = render_system
        self.bodyguard_system = bodyguard_system
        self.police_system = police_system
        self.achievement_system = achievement_system
        self.logger = logger

    def extract_mentioned_user(self, message_data: Dict[str, Any]) -> Optional[str]:
        """从消息中提取@的用户ID"""
        try:
            # 检查消息中是否有@用户
            mentions = message_data.get('mentions', [])
            if mentions:
                return mentions[0].get('id')

            # 如果没有mentions字段，尝试从content中解析
            content = message_data.get('content', '')
            # 匹配 <@!用户ID> 或 <@用户ID> 格式
            match = re.search(r'<@!?(\w+)>', content)
            if match:
                return match.group(1)

            return None

        except Exception as e:
            self.logger.error(f"提取@用户失败: {e}")
            return None

    async def handle_bind_qq(self, user_id: str, group_id: str,
                             original_msg_id: str = None, reply_msg_id: str = None,
                             bot_id: int = None) -> MessageBuilder:
        """处理绑定QQ命令"""
        try:
            # 检查是否已绑定
            existing_qq = await self.auth_system.get_bound_qq(user_id, group_id)

            if existing_qq:
                return MessageBuilder.text(f"✅ 您已绑定QQ号: {existing_qq}")

            # 开始绑定流程，传递原始消息信息
            return await self.auth_system.start_qq_bind_process(user_id, group_id,
                                                                original_msg_id, reply_msg_id, bot_id)

        except Exception as e:
            self.logger.error(f"处理绑定QQ命令失败: {e}")
            return MessageBuilder.text("❌ 绑定处理失败，请稍后重试")

    async def handle_help(self, union_openid: str, group_openid: str) -> MessageBuilder:
        """处理帮助命令（HTML转图片）"""
        try:
            # 检查是否已绑定QQ
            is_bound = await self.auth_system.is_user_bound(union_openid, group_openid)
            bound_qq = None

            if is_bound:
                bound_qq = await self.auth_system.get_bound_qq(union_openid, group_openid)

            # 准备模板数据
            help_data = {
                'is_bound': is_bound,
                'bound_qq': bound_qq
            }

            # 尝试使用HTML模板生成图片（不使用缓存，保证实时性）
            image_base64 = await self.render_system.render_to_image("help.html", help_data)
            if image_base64:
                return MessageBuilder.image(base64_data=image_base64, caption="🎮 牛马市场游戏帮助")
            else:
                # 图片生成失败，直接返回失败
                return MessageBuilder.text("❌ 帮助图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理帮助命令失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    async def handle_work(self, user_id: str, group_id: str) -> MessageBuilder:
        """处理工作命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(user_id, group_id)
            if bind_check:
                return bind_check

            # user_id和group_id实际上就是union_openid和group_openid
            result = await self.economy_system.work(user_id, group_id)

            if not result["success"]:
                # 特殊处理用户数据不存在的情况
                if result["message"] == "用户数据不存在":
                    return MessageBuilder.text("❌ 检测到您尚未创建游戏数据\n💡 请先发送 '个人状态' 命令来创建游戏数据")
                return MessageBuilder.text(f"❌ {result['message']}")

            # 生成工作结果图片
            try:
                # 准备模板数据
                event_cost = result.get('event_cost', 0)
                master_income_raw = result.get('master_income', 0)

                template_data = {
                    'work_emoji': result.get('work_emoji', '💼'),
                    'work_type': result.get('work_type', '工作'),
                    'work_description': result.get('work_description', ''),
                    'income': self.economy_system.format_currency(result['income']),
                    'new_currency': self.economy_system.format_currency(result['new_currency']),
                    'master_income': self.economy_system.format_currency(master_income_raw),
                    'master_income_raw': master_income_raw,  # 用于模板中的数值比较
                    'event_message': result.get('event_message', ''),
                    'event_cost': event_cost,  # 用于模板中的数值比较
                    'event_cost_formatted': self.economy_system.format_currency(event_cost)
                }

                # 如果有事件费用，计算基础收入
                if event_cost > 0:
                    gross_income = result['income'] + event_cost
                    template_data['gross_income'] = self.economy_system.format_currency(gross_income)

                # 生成图片
                image_data = await self.render_system.render_to_image('work_result.html', template_data)

                if image_data:
                    return MessageBuilder.image(base64_data=image_data, caption="💼 工作结果")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"工作结果图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理工作命令失败: {e}")
            return MessageBuilder.text("❌ 工作处理失败，请稍后重试")

    async def handle_status(self, union_openid: str, group_openid: str) -> MessageBuilder:
        """处理状态命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 获取用户数据，如果不存在则自动创建
            user_data = self.economy_system.db_manager.get_user(union_openid, group_openid)
            if not user_data:
                # 获取绑定的QQ号
                bound_qq = await self.auth_system.get_bound_qq(union_openid, group_openid)
                if bound_qq:
                    # 自动创建用户数据
                    success = self.economy_system.db_manager.create_user(union_openid, group_openid, bound_qq)
                    if success:
                        user_data = self.economy_system.db_manager.get_user(union_openid, group_openid)
                    else:
                        return MessageBuilder.text("❌ 创建用户数据失败")
                else:
                    return MessageBuilder.text("❌ 未找到绑定的QQ号")

            if not user_data:
                return MessageBuilder.text("❌ 用户数据获取失败")

            # 获取奴隶列表
            slaves = self.trading_system.get_user_slaves(union_openid, group_openid)

            # 获取主人信息
            master_qq = None
            master_openid = user_data.master_openid
            if master_openid:
                master_data = self.economy_system.db_manager.get_user(master_openid, group_openid)
                if master_data:
                    master_qq = master_data.qq_number

            # 获取称号信息
            highest_title = None
            try:
                user_titles = self.achievement_system.get_user_titles(union_openid, group_openid)
                # 查找当前活跃的称号
                for title_info in user_titles:
                    if title_info.get('active', False):
                        highest_title = title_info.get('title')
                        break

                # 如果没有活跃称号，使用第一个称号
                if not highest_title and user_titles:
                    highest_title = user_titles[0].get('title')

            except Exception as e:
                self.logger.debug(f"获取称号失败: {e}")

            # 准备模板数据
            user_status_data = {
                'user': {
                    'qq_number': user_data.qq_number,
                    'currency': self.economy_system.format_currency(user_data.currency),
                    'value': self.economy_system.format_currency(user_data.value),
                    'work_count': user_data.work_count,
                    'purchase_count': user_data.purchase_count,
                    'total_earned': self.economy_system.format_currency(user_data.total_earned),
                    'total_spent': self.economy_system.format_currency(user_data.total_spent),
                    'master_id': master_openid
                },
                'master_qq': master_qq,
                'slaves': slaves[:10],  # 最多显示10个奴隶
                'highest_title': highest_title  # 添加称号信息
            }

            # 尝试使用HTML模板生成图片（不使用缓存，保证实时性）
            image_base64 = await self.render_system.render_to_image("user_status.html", user_status_data)
            if image_base64:
                return MessageBuilder.image(base64_data=image_base64, caption="👤 个人状态")
            else:
                # 图片生成失败，返回错误信息
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理状态命令失败: {e}")
            return MessageBuilder.text("❌ 状态查询失败，请稍后重试")

    async def handle_purchase(self, union_openid: str, group_openid: str,
                              message_data: Dict[str, Any]) -> MessageBuilder:
        """处理购买命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 提取命令参数（QQ号）
            content = message_data.get('content', '').strip()
            parts = content.split()
            target_qq = None
            target_openid = None

            # 检查是否指定了QQ号
            if len(parts) > 1:
                # 尝试提取QQ号
                qq_part = parts[1]
                # 移除可能的前缀（如"QQ"）和非数字字符
                import re
                qq_match = re.search(r'\d{5,12}', qq_part)
                if qq_match:
                    target_qq = qq_match.group()
                    # 根据QQ号查找对应的union_openid
                    target_openid = await self.auth_system.get_user_by_qq(target_qq, group_openid)
                    if not target_openid:
                        return MessageBuilder.text(f"❌ QQ号 {target_qq} 未在本群绑定")
                    if target_openid == union_openid:
                        return MessageBuilder.text("❌ 不能购买自己")

                    # 检查目标用户是否有游戏数据
                    target_user = self.trading_system.db_manager.get_user(target_openid, group_openid)
                    if not target_user:
                        return MessageBuilder.text(
                            f"❌ QQ号 {target_qq} 尚未创建游戏数据\n💡 请让对方先发送 '我的奴隶' 命令来创建游戏数据")
                else:
                    return MessageBuilder.text("❌ QQ号格式错误，请输入正确的QQ号")

            # 如果没有指定QQ号，随机选择
            if not target_openid:
                # 获取所有有游戏数据的用户
                users_with_game_data = self.trading_system.db_manager.get_users_with_game_data(group_openid)
                if not users_with_game_data:
                    return MessageBuilder.text("❌ 群内暂无其他有游戏数据的用户")

                # 排除自己
                available_targets = [uid for uid in users_with_game_data if uid != union_openid]
                if not available_targets:
                    return MessageBuilder.text("❌ 群内暂无其他可购买的用户\n💡 让其他群友发送 '我的奴隶' 来创建游戏数据")

                # 随机选择一个目标
                import random
                target_openid = random.choice(available_targets)

            result = await self.trading_system.purchase_slave(union_openid, target_openid, group_openid)

            if not result["success"]:
                # 特殊处理用户数据不存在的情况
                if result["message"] == "用户数据不存在":
                    return MessageBuilder.text(
                        "❌ 检测到您或目标用户尚未创建游戏数据\n💡 请先发送 '我的奴隶' 命令来创建游戏数据")
                return MessageBuilder.text(f"❌ {result['message']}")

            # 生成购买结果图片
            try:
                # 获取目标用户的QQ号用于显示
                target_user = self.trading_system.db_manager.get_user(target_openid, group_openid)
                target_qq = target_user.qq_number if target_user else "未知"

                # 准备模板数据
                template_data = {
                    'target_qq': target_qq,
                    'cost': self.trading_system.format_currency(result['cost']),
                    'buyer_currency': self.trading_system.format_currency(result['buyer_new_currency']),
                    'target_value': self.trading_system.format_currency(result['target_new_value']),
                    'old_master': result.get('old_master', False)
                }

                # 生成图片
                image_data = await self.render_system.render_to_image('purchase_result.html', template_data)

                if image_data:
                    return MessageBuilder.image(base64_data=image_data, caption="🛒 购买结果")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"购买结果图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理购买命令失败: {e}")
            return MessageBuilder.text("❌ 购买处理失败，请稍后重试")

    async def handle_release(self, union_openid: str, group_openid: str,
                             message_data: Dict[str, Any]) -> MessageBuilder:
        """处理释放命令（支持指定QQ号或自动选择）"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 获取用户的奴隶列表
            slaves = self.trading_system.get_user_slaves(union_openid, group_openid)
            if not slaves:
                return MessageBuilder.text("❌ 您没有奴隶可以释放")

            # 提取命令参数（QQ号）
            content = message_data.get('content', '').strip()
            parts = content.split()
            target_openid = None

            # 检查是否指定了QQ号
            if len(parts) > 1:
                # 尝试提取QQ号
                qq_part = parts[1]
                import re
                qq_match = re.search(r'\d{5,12}', qq_part)
                if qq_match:
                    target_qq = qq_match.group()
                    # 检查这个QQ号是否是自己的奴隶
                    target_slave = None
                    for slave in slaves:
                        if slave['qq_number'] == target_qq:
                            target_slave = slave
                            target_openid = slave['union_openid']
                            break

                    if not target_slave:
                        return MessageBuilder.text(f"❌ QQ号 {target_qq} 不是您的奴隶")
                else:
                    return MessageBuilder.text("❌ QQ号格式错误，请输入正确的QQ号")

            # 如果没有指定QQ号，自动选择第一个奴隶
            if not target_openid:
                target_openid = slaves[0]['union_openid']

            result = await self.trading_system.release_slave(union_openid, target_openid, group_openid)

            if not result["success"]:
                # 特殊处理用户数据不存在的情况
                if result["message"] == "用户数据不存在":
                    return MessageBuilder.text(
                        "❌ 检测到您或目标用户尚未创建游戏数据\n💡 请先发送 '我的牛马' 命令来创建游戏数据")
                return MessageBuilder.text(f"❌ {result['message']}")

            # 生成释放结果图片
            try:
                # 准备模板数据
                template_data = {
                    'slave_qq': result.get('slave_qq', '未知')
                }

                # 生成图片
                image_data = await self.render_system.render_to_image('release_result.html', template_data)

                if image_data:
                    return MessageBuilder.image(base64_data=image_data, caption="🆓 释放结果")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"释放结果图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理释放命令失败: {e}")
            return MessageBuilder.text("❌ 释放处理失败，请稍后重试")

    async def handle_freedom(self, union_openid: str, group_openid: str) -> MessageBuilder:
        """处理赎身命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            result = await self.trading_system.buy_back_freedom(union_openid, group_openid)

            if not result["success"]:
                # 特殊处理用户数据不存在的情况
                if result["message"] == "用户数据不存在":
                    return MessageBuilder.text("❌ 检测到您尚未创建游戏数据\n💡 请先发送 '我的奴隶' 命令来创建游戏数据")
                return MessageBuilder.text(f"❌ {result['message']}")

            # 生成赎身结果图片
            try:
                # 获取原主人的QQ号用于显示
                master_qq = None
                if result.get('master_id'):
                    master_user = self.trading_system.db_manager.get_user(result['master_id'], group_openid)
                    master_qq = master_user.qq_number if master_user else None

                # 准备模板数据
                template_data = {
                    'cost': self.trading_system.format_currency(result['cost']),
                    'new_currency': self.trading_system.format_currency(result['new_currency']),
                    'new_value': self.trading_system.format_currency(result['new_value']),
                    'master_qq': master_qq
                }

                # 生成图片
                image_data = await self.render_system.render_to_image('freedom_result.html', template_data)

                if image_data:
                    return MessageBuilder.image(base64_data=image_data, caption="🕊️ 赎身结果")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"赎身结果图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理赎身命令失败: {e}")
            return MessageBuilder.text("❌ 赎身处理失败，请稍后重试")

    async def handle_rob(self, union_openid: str, group_openid: str, message_data: Dict[str, Any]) -> MessageBuilder:
        """处理抢劫命令（支持指定QQ号或随机选择）"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 提取命令参数（QQ号）
            content = message_data.get('content', '').strip()
            parts = content.split()
            target_qq = None
            target_openid = None

            # 检查是否指定了QQ号
            if len(parts) > 1:
                # 尝试提取QQ号
                qq_part = parts[1]
                import re
                qq_match = re.search(r'\d{5,12}', qq_part)
                if qq_match:
                    target_qq = qq_match.group()
                    # 根据QQ号查找对应的union_openid
                    target_openid = await self.auth_system.get_user_by_qq(target_qq, group_openid)
                    if not target_openid:
                        return MessageBuilder.text(f"❌ QQ号 {target_qq} 未在本群绑定")
                    if target_openid == union_openid:
                        return MessageBuilder.text("❌ 不能抢劫自己")
                else:
                    return MessageBuilder.text("❌ QQ号格式错误，请输入正确的QQ号")

            # 如果没有指定QQ号，随机选择
            if not target_openid:
                # 获取所有有游戏数据的用户
                users_with_game_data = self.pvp_system.db_manager.get_users_with_game_data(group_openid)
                if not users_with_game_data:
                    return MessageBuilder.text("❌ 群内暂无其他有游戏数据的用户")

                # 排除自己
                available_targets = [uid for uid in users_with_game_data if uid != union_openid]
                if not available_targets:
                    return MessageBuilder.text("❌ 群内暂无其他可抢劫的用户\n💡 让其他群友发送 '我的奴隶' 来创建游戏数据")

                # 随机选择一个目标
                import random
                target_openid = random.choice(available_targets)

            # 检查目标用户是否存在
            target_data = self.economy_system.db_manager.get_user(target_openid, group_openid)
            if not target_data:
                return MessageBuilder.text("❌ 目标用户尚未创建游戏数据\n💡 请让对方先发送 '我的奴隶' 命令来创建游戏数据")

            result = await self.pvp_system.rob_player(union_openid, target_openid, group_openid, self.bodyguard_system)

            if not result["success"]:
                # 特殊处理用户数据不存在的情况
                if result["message"] == "用户数据不存在":
                    return MessageBuilder.text("❌ 检测到您尚未创建游戏数据\n💡 请先发送 '我的奴隶' 命令来创建游戏数据")
                return MessageBuilder.text(f"❌ {result['message']}")

            # 生成抢劫结果图片
            try:
                # 获取目标用户的QQ号用于显示
                target_user = self.pvp_system.db_manager.get_user(target_openid, group_openid)
                target_qq = target_user.qq_number if target_user else "未知"

                # 准备模板数据
                template_data = {
                    'target_qq': target_qq,
                    'rob_success': result.get("rob_success", False),
                    'defended': result.get("defended", False),
                    'success_rate': result.get('success_rate', 0),
                    'robber_new_currency': self.pvp_system.format_currency(result.get('robber_new_currency', 0))
                }

                if result.get("defended"):
                    template_data.update({
                        'bodyguard_type': result.get('bodyguard_name', '保镖'),
                        'counter_attack': result.get("counter_attack", False),
                        'counter_damage': self.pvp_system.format_currency(
                            result.get('counter_damage', 0)) if result.get("counter_attack") else 0
                    })
                elif result.get("rob_success"):
                    template_data.update({
                        'rob_amount': self.pvp_system.format_currency(result.get('rob_amount', 0))
                    })
                else:
                    template_data.update({
                        'penalty': self.pvp_system.format_currency(result.get('penalty', 0))
                    })

                # 生成图片
                image_data = await self.render_system.render_to_image('rob_result.html', template_data)

                if image_data:
                    return MessageBuilder.image(base64_data=image_data, caption="⚔️ 抢劫结果")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"抢劫结果图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理抢劫命令失败: {e}")
            return MessageBuilder.text("❌ 抢劫处理失败，请稍后重试")

    async def handle_ranking(self, union_openid: str, group_openid: str, message_data: Dict[str, Any]) -> MessageBuilder:
        """处理排行榜命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 解析排行榜类型
            content = message_data.get('content', '').strip()
            parts = content.split()

            # 默认显示身价排行榜
            rank_type = "身价"
            if len(parts) > 1:
                type_param = parts[1]
                if type_param == "身价":
                    rank_type = "身价"
                elif type_param == "金币":
                    rank_type = "金币"
                else:
                    return MessageBuilder.text(
                        "❌ 不支持的排行榜类型\n"
                        "💡 支持的类型：\n"
                        "• 牛马排行 身价\n"
                        "• 牛马排行 金币"
                    )

            # 获取对应的排行榜数据
            if rank_type == "身价":
                ranking = self.ranking_system.get_value_ranking(group_openid, 10)
                caption = "🏆 身价排行榜"
            elif rank_type == "金币":
                ranking = self.ranking_system.get_currency_ranking(group_openid, 10)
                caption = "💰 金币排行榜"

            if not ranking:
                return MessageBuilder.text("❌ 暂无排行数据")

            # 尝试使用HTML模板生成图片
            ranking_data = {
                'ranking': ranking,
                'rank_type': rank_type
            }

            image_base64 = await self.render_system.render_to_image("ranking.html", ranking_data)
            if image_base64:
                return MessageBuilder.image(base64_data=image_base64, caption=caption)
            else:
                # 图片生成失败，直接返回失败
                return MessageBuilder.text("❌ 排行榜图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理排行榜命令失败: {e}")
            return MessageBuilder.text("❌ 排行榜查询失败，请稍后重试")

    async def handle_hire_bodyguard(self, user_id: str, group_id: str, bodyguard_type: str = "basic") -> MessageBuilder:
        """处理雇佣保镖命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(user_id, group_id)
            if bind_check:
                return bind_check

            # 检查是否被监禁
            jail_status = self.police_system.is_user_jailed(user_id, group_id)
            if jail_status["jailed"]:
                remaining_time = self.police_system.format_time(jail_status["remaining_seconds"])
                return MessageBuilder.text(f"🚔 您正在服刑中，无法雇佣保镖\n剩余时间: {remaining_time}")

            result = await self.bodyguard_system.hire_bodyguard(user_id, group_id, bodyguard_type)

            if not result["success"]:
                return MessageBuilder.text(f"❌ {result['message']}")

            # 尝试生成HTML图片
            try:
                # 准备模板数据
                template_data = {
                    'bodyguard_name': result['bodyguard_name'],
                    'cost': self.bodyguard_system.format_currency(result['cost']),
                    'new_currency': self.bodyguard_system.format_currency(result['new_currency']),
                    'duration_hours': result['duration_hours'],
                    'defense_rate': result['defense_rate']
                }

                # 渲染HTML图片
                image_base64 = await self.render_system.render_to_image('hire_bodyguard_result.html', template_data,
                                                                        width=600)

                if image_base64:
                    return MessageBuilder.image(base64_data=image_base64, caption="🛡️ 雇佣保镖成功")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"雇佣保镖HTML图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理雇佣保镖命令失败: {e}")
            return MessageBuilder.text("❌ 雇佣保镖失败，请稍后重试")

    async def handle_bodyguard_status(self, user_id: str, group_id: str) -> MessageBuilder:
        """处理保镖状态命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(user_id, group_id)
            if bind_check:
                return bind_check

            # 获取用户基本信息
            user_data = self.economy_system.db_manager.get_user(user_id, group_id)
            user_name = user_data.qq_number if user_data else "未知用户"

            # 获取当前保镖
            bodyguard = self.bodyguard_system.get_active_bodyguard(user_id, group_id)

            # 计算剩余时间
            remaining_time = None
            if bodyguard:
                from datetime import datetime
                remaining_seconds = int((bodyguard["expire_time"] - datetime.utcnow()).total_seconds())
                remaining_time = self.bodyguard_system.format_time(remaining_seconds)

            # 获取可雇佣保镖列表
            available_bodyguards = self.bodyguard_system.get_bodyguard_list()

            # 尝试生成HTML图片
            try:
                # 准备模板数据
                template_data = {
                    'user_name': user_name,
                    'current_bodyguard': bodyguard,
                    'remaining_time': remaining_time,
                    'available_bodyguards': available_bodyguards
                }

                # 渲染HTML图片
                image_base64 = await self.render_system.render_to_image('bodyguard_status.html', template_data,
                                                                        width=800)

                if image_base64:
                    return MessageBuilder.image(base64_data=image_base64, caption="🛡️ 保镖状态")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"保镖状态HTML图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理保镖状态命令失败: {e}")
            return MessageBuilder.text("❌ 保镖状态查询失败，请稍后重试")

    async def handle_report(self, union_openid: str, group_openid: str, message_data: Dict[str, Any]) -> MessageBuilder:
        """处理举报命令（必须输入QQ号）"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 检查是否被监禁
            jail_status = self.police_system.is_user_jailed(union_openid, group_openid)
            if jail_status["jailed"]:
                remaining_time = self.police_system.format_time(jail_status["remaining_seconds"])
                return MessageBuilder.text(f"🚔 您正在服刑中，无法举报他人\n剩余时间: {remaining_time}")

            # 提取命令参数（必须包含QQ号）
            content = message_data.get('content', '').strip()
            parts = content.split()

            if len(parts) < 2:
                return MessageBuilder.text("❌ 请输入要举报的QQ号\n例如：举报 123456789 抢劫")

            # 提取QQ号
            qq_part = parts[1]
            import re
            qq_match = re.search(r'\d{5,12}', qq_part)
            if not qq_match:
                return MessageBuilder.text("❌ QQ号格式错误，请输入正确的QQ号")

            target_qq = qq_match.group()
            # 根据QQ号查找对应的union_openid
            target_openid = await self.auth_system.get_user_by_qq(target_qq, group_openid)
            if not target_openid:
                return MessageBuilder.text(f"❌ QQ号 {target_qq} 未在本群绑定")

            if target_openid == union_openid:
                return MessageBuilder.text("❌ 不能举报自己")

            # 解析举报类型和证据
            content = message_data.get('content', '')
            report_type = "harassment"  # 默认骚扰
            evidence = ""  # 默认无证据

            if "抢劫" in content:
                report_type = "robbery"
                # 对于抢劫举报，将整个命令内容作为证据
                evidence = content
            elif "诈骗" in content:
                report_type = "fraud"
                # 对于诈骗举报，将整个命令内容作为证据
                evidence = content
            elif "虐待" in content:
                report_type = "abuse"

            result = await self.police_system.submit_report(
                union_openid, target_openid, group_openid, report_type,
                description=content, evidence=evidence
            )

            if not result["success"]:
                return MessageBuilder.text(f"❌ {result['message']}")

            message_parts = [
                f"🚔 举报提交成功！",
                f"📋 举报类型: {result['report_type']}",
                f"💰 举报费用: {self.police_system.format_currency(result['cost'])}",
                f"💳 剩余金币: {self.police_system.format_currency(result['new_currency'])}",
                f"⏰ 调查时间: {result['investigation_time']}",
                f"🆔 举报编号: {result['report_id']}"
            ]

            return MessageBuilder.text("\n".join(message_parts))

        except Exception as e:
            self.logger.error(f"处理举报命令失败: {e}")
            return MessageBuilder.text("❌ 举报提交失败，请稍后重试")

    async def handle_report_results(self, union_openid: str, group_openid: str) -> MessageBuilder:
        """处理举报结果查询命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(union_openid, group_openid)
            if bind_check:
                return bind_check

            # 获取用户的举报记录
            reports = self.police_system.get_user_reports(union_openid, group_openid)

            if not reports:
                return MessageBuilder.text("📋 您还没有提交过任何举报")

            # 构建举报结果消息
            message_parts = ["📋 您的举报记录:"]

            for i, report in enumerate(reports[:5], 1):  # 最多显示5条最新记录
                # 格式化时间
                create_time = report.get('create_time', '未知时间')
                if hasattr(create_time, 'strftime'):
                    create_time_str = create_time.strftime('%m-%d %H:%M')
                else:
                    create_time_str = str(create_time)[:16] if create_time else '未知时间'

                # 基本信息
                report_type = report.get('report_type', '未知')
                report_type_name = self.police_system.report_types.get(report_type, {}).get('name', report_type)
                reported_qq = report.get('reported_qq', '未知用户')
                status = report.get('status', 'pending')

                message_parts.append(f"\n🆔 举报#{report.get('id', '?')} ({create_time_str})")
                message_parts.append(f"📋 类型: {report_type_name}")
                message_parts.append(f"👤 被举报者: {reported_qq}")

                if status == 'pending':
                    message_parts.append("⏳ 状态: 调查中...")
                elif status == 'processed':
                    # 显示处理结果
                    penalty_type = report.get('penalty_type', '')
                    penalty_amount = report.get('penalty_amount', 0)
                    result = report.get('result', '处理完成')

                    penalty_info = self.police_system.penalties.get(penalty_type, {})
                    penalty_name = penalty_info.get('name', penalty_type)

                    message_parts.append(f"✅ 状态: 已处理")
                    message_parts.append(f"⚖️ 处罚: {penalty_name}")

                    if penalty_amount > 0:
                        formatted_amount = self.police_system.format_currency(penalty_amount)
                        message_parts.append(f"💰 罚款: {formatted_amount} 金币")

                    if penalty_info.get('jail_hours', 0) > 0:
                        jail_hours = penalty_info['jail_hours']
                        message_parts.append(f"🔒 监禁: {jail_hours}小时")

                    message_parts.append(f"📝 结果: {result}")
                else:
                    message_parts.append(f"❓ 状态: {status}")

                if i < len(reports[:5]):
                    message_parts.append("─" * 20)

            if len(reports) > 5:
                message_parts.append(f"\n💡 还有 {len(reports) - 5} 条历史记录未显示")

            return MessageBuilder.text("\n".join(message_parts))

        except Exception as e:
            self.logger.error(f"处理举报结果查询失败: {e}")
            return MessageBuilder.text("❌ 查询举报结果失败，请稍后重试")

    async def handle_achievements(self, user_id: str, group_id: str) -> MessageBuilder:
        """处理成就命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(user_id, group_id)
            if bind_check:
                return bind_check

            # 检查新成就
            new_achievements = await self.achievement_system.check_achievements(user_id, group_id)

            # 获取用户成就
            achievements = self.achievement_system.get_user_achievements(user_id, group_id)
            titles = self.achievement_system.get_user_titles(user_id, group_id)
            active_title = self.achievement_system.get_active_title(user_id, group_id)

            # 获取用户基本信息
            user_data = self.economy_system.db_manager.get_user(user_id, group_id)
            user_name = user_data.qq_number if user_data else "未知用户"

            # 成就统计
            total_achievements = len(self.achievement_system.achievements)
            unlocked_count = len(achievements)
            progress_rate = unlocked_count / total_achievements if total_achievements > 0 else 0

            # 尝试生成HTML图片
            try:
                # 准备模板数据
                template_data = {
                    'user_name': user_name,
                    'total_achievements': total_achievements,
                    'unlocked_count': unlocked_count,
                    'progress_rate': progress_rate,
                    'achievements': achievements,
                    'titles': titles,
                    'active_title': active_title,
                    'new_achievements': new_achievements
                }

                # 检查render_system是否存在
                if not hasattr(self, 'render_system') or self.render_system is None:
                    return MessageBuilder.text("❌ 渲染系统未初始化")

                # 渲染HTML图片
                image_base64 = await self.render_system.render_to_image('achievements.html', template_data, width=900)

                if image_base64:
                    return MessageBuilder.image(base64_data=image_base64, caption="🏆 成就系统")
                else:
                    return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

            except Exception as e:
                self.logger.error(f"成就HTML图片生成失败: {e}")
                return MessageBuilder.text("❌ 图片生成失败，请稍后重试")

        except Exception as e:
            self.logger.error(f"处理成就命令失败: {e}")
            return MessageBuilder.text("❌ 成就查询失败，请稍后重试")

    async def handle_set_title(self, user_id: str, group_id: str, title: str) -> MessageBuilder:
        """处理设置称号命令"""
        try:
            # 检查是否绑定QQ
            bind_check = await self.auth_system.require_qq_bind(user_id, group_id)
            if bind_check:
                return bind_check

            success = await self.achievement_system.set_active_title(user_id, group_id, title)

            if success:
                title_level = self.achievement_system.title_levels.get(title, 1)
                return MessageBuilder.text(f"👑 称号设置成功！\n当前称号: {title} (等级{title_level})")
            else:
                return MessageBuilder.text(f"❌ 称号设置失败，您可能没有该称号")

        except Exception as e:
            self.logger.error(f"处理设置称号命令失败: {e}")
            return MessageBuilder.text("❌ 称号设置失败，请稍后重试")
