"""
牛马市场插件
基于SQLAlchemy的QQ群娱乐游戏
"""

import asyncio
import logging

from Core.logging.file_logger import log_error
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin
from .core.database import DatabaseManager
from .handlers.command_handler import CommandHandler
from .systems.achievement import AchievementSystem
from .systems.auth import AuthSystem
from .systems.bodyguard import BodyguardSystem
from .systems.economy import EconomySystem
from .systems.police import PoliceSystem
from .systems.pvp import PvPSystem
from .systems.ranking import RankingSystem
from .systems.render import RenderSystem
from .systems.trading import TradingSystem


class Plugin(BasePlugin):
    """牛马市场插件主类"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "SlaveMarket"
        self.version = "1.0.0"
        self.description = "牛马市场 - QQ群娱乐经济游戏"
        self.author = "Yixuan"

        # 获取系统日志器
        self.logger = logging.getLogger(f"SlaveMarket.{self.name}")

        # 初始化数据库管理器
        self.db_manager = DatabaseManager()

        # 初始化游戏系统
        self.auth_system = AuthSystem(self.db_manager)
        self.economy_system = EconomySystem(self.db_manager, self.logger)
        self.trading_system = TradingSystem(self.db_manager, self.logger)
        self.pvp_system = PvPSystem(self.db_manager, self.logger)
        self.ranking_system = RankingSystem(self.db_manager, self.logger)
        self.render_system = RenderSystem()
        self.bodyguard_system = BodyguardSystem(self.db_manager, self.logger)
        self.police_system = PoliceSystem(self.db_manager, self.logger)
        self.achievement_system = AchievementSystem(self.db_manager, self.logger)

        # 初始化命令处理器
        self.command_handler = CommandHandler(
            auth_system=self.auth_system,
            economy_system=self.economy_system,
            trading_system=self.trading_system,
            pvp_system=self.pvp_system,
            ranking_system=self.ranking_system,
            render_system=self.render_system,
            bodyguard_system=self.bodyguard_system,
            police_system=self.police_system,
            achievement_system=self.achievement_system,
            logger=self.logger
        )

        # 初始化数据库
        try:
            self.db_manager.init_database()
            self.logger.info("牛马市场插件数据库初始化完成")

            # 清理数据精度（一次性操作）
            self.db_manager.clean_currency_precision()

        except Exception as e:
            self.logger.error(f"牛马市场插件数据库初始化失败: {e}")

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.handle_message_hook],
            'bot_start': [self.on_bot_start_hook],
            'bot_stop': [self.on_bot_stop_hook]
        }

        # 支持的命令处理器
        self.command_handlers = {
            '牛马绑定': self.handle_bind_qq,
            '牛马菜单': self.handle_help,
            '牛马工作': self.handle_work,
            '我的牛马': self.handle_status,
            '个人状态': self.handle_status,
            '购买群友': self.handle_purchase,
            '购买牛马': self.handle_purchase,
            '释放牛马': self.handle_release,
            '赎身': self.handle_freedom,
            '抢劫': self.handle_rob,
            '牛马排行': self.handle_ranking,
            '雇佣保镖': self.handle_hire_bodyguard,
            '保镖状态': self.handle_bodyguard_status,
            '举报': self.handle_report,
            '举报结果': self.handle_report_results,
            '我的成就': self.handle_achievements,
            '成就': self.handle_achievements,
            '设置称号': self.handle_set_title
        }

        # 注册命令信息
        for cmd in self.command_handlers.keys():
            self.register_command_info(cmd, f'牛马市场游戏命令', f'{cmd}')

    def run_async(self, coro):
        """在多线程环境中安全执行异步函数"""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(coro)

    def get_user_group_from_message(self, message_data):
        """从消息数据中提取用户ID和群组ID"""
        try:
            # 从消息数据中提取用户ID和群组ID
            author = message_data.get('author', {})
            user_id = author.get('id', '')

            # 群组ID可能在不同字段中
            group_id = (message_data.get('group_id') or
                        message_data.get('guild_id') or
                        message_data.get('channel_id') or
                        message_data.get('group_openid', ''))  # QQ官方机器人使用group_openid

            return user_id, group_id
        except Exception as e:
            log_error(0, f"提取用户群组信息失败: {e}", "SLAVE_MARKET_EXTRACT_INFO_ERROR")
            return None, None

    # ==================== Hook事件处理 ====================

    def handle_message_hook(self, message_data, user_id=None, bot_id=None):
        """处理消息Hook"""
        try:
            # 保存当前消息数据和bot_id
            self._current_message_data = message_data
            self._current_bot_id = bot_id

            content = message_data.get('content', '').strip()

            # 智能处理命令（支持带/和不带/的命令）
            result = self._handle_smart_command(content, bot_id)
            return result

        except Exception as e:
            log_error(bot_id or 0, f"牛马市场插件处理消息异常: {e}", "SLAVE_MARKET_HOOK_ERROR")
            return {'handled': False}

    def _handle_smart_command(self, content, bot_id=None):
        """智能命令处理 - 支持带/和不带/的命令"""
        # 检查是否是带/的命令
        if content.startswith('/'):
            return self._handle_command(content, bot_id)

        # 检查是否是不带/的命令
        parts = content.split()
        if not parts:
            return {'handled': False}

        command = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        # 检查是否是支持的命令
        if command in self.command_handlers:
            try:
                handler = self.command_handlers[command]
                response = handler(args)
                return {
                    'response': response,
                    'handled': True
                }
            except Exception as e:
                log_error(bot_id or 0, f"牛马市场命令处理异常: {e}", "SLAVE_MARKET_COMMAND_ERROR")
                return {
                    'response': MessageBuilder.text(f"❌ 命令执行出错: {str(e)}"),
                    'handled': True
                }

        return {'handled': False}

    def _handle_command(self, content, bot_id=None):
        """处理带/的命令"""
        # 解析命令
        parts = content[1:].split()  # 去掉/前缀并分割
        if not parts:
            return {'handled': False}

        command = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        # 检查是否是支持的命令
        if command in self.command_handlers:
            try:
                handler = self.command_handlers[command]
                response = handler(args)
                return {
                    'response': response,
                    'handled': True
                }
            except Exception as e:
                log_error(bot_id or 0, f"牛马市场命令处理异常: {e}", "SLAVE_MARKET_COMMAND_ERROR")
                return {
                    'response': MessageBuilder.text(f"❌ 命令执行出错: {str(e)}"),
                    'handled': True
                }

        return {'handled': False}

    # ==================== 命令处理器 ====================

    def handle_bind_qq(self, args):
        """处理绑定QQ命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)

            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 提取原始消息信息
            original_msg_id = self._current_message_data.get('id')
            reply_msg_id = self._current_message_data.get('msg_id')
            bot_id = self._current_bot_id

            result = self.run_async(self.command_handler.handle_bind_qq(user_id, group_id,
                                                                        original_msg_id, reply_msg_id, bot_id))
            return result

        except Exception as e:
            log_error(0, f"绑定QQ命令处理失败: {e}", "SLAVE_MARKET_BIND_COMMAND_ERROR")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_help(self, args):
        """处理帮助命令"""
        try:
            # 获取QQ号和群组信息
            raw_user_id, raw_group_id = self.get_user_group_from_message(self._current_message_data)
            if not raw_user_id or not raw_group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 通过QQ号查找对应的union_openid和group_openid
            try:
                # 如果raw_user_id是QQ号，需要转换为union_openid
                if raw_user_id.isdigit():
                    # 通过QQ号查找绑定记录
                    session = self.db_manager.get_session()
                    try:
                        from .core.database import QQBinding
                        binding = session.query(QQBinding).filter_by(qq_number=raw_user_id).first()
                        if binding:
                            user_id = binding.union_openid
                            group_id = binding.group_openid
                        else:
                            # 如果没有绑定记录，直接使用原始ID（帮助命令不需要绑定也能查看）
                            user_id = raw_user_id
                            group_id = raw_group_id
                    finally:
                        self.db_manager.close_session(session)
                else:
                    # 如果已经是union_openid格式，直接使用
                    user_id = raw_user_id
                    group_id = raw_group_id

                return self.run_async(self.command_handler.handle_help(user_id, group_id))

            except Exception as e:
                self.logger.error(f"查找用户绑定信息失败: {e}")
                # 帮助命令即使查找失败也应该能显示，使用原始ID
                return self.run_async(self.command_handler.handle_help(raw_user_id, raw_group_id))

        except Exception as e:
            self.logger.error(f"帮助命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_work(self, args):
        """处理工作命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_work(user_id, group_id))

        except Exception as e:
            self.logger.error(f"工作命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_status(self, args):
        """处理状态命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_status(user_id, group_id))

        except Exception as e:
            self.logger.error(f"状态命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_purchase(self, args):
        """处理购买命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_purchase(user_id, group_id, self._current_message_data))

        except Exception as e:
            self.logger.error(f"购买命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_release(self, args):
        """处理释放命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_release(user_id, group_id, self._current_message_data))

        except Exception as e:
            self.logger.error(f"释放命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_freedom(self, args):
        """处理赎身命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_freedom(user_id, group_id))

        except Exception as e:
            self.logger.error(f"赎身命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_rob(self, args):
        """处理抢劫命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_rob(user_id, group_id, self._current_message_data))

        except Exception as e:
            self.logger.error(f"抢劫命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_ranking(self, args):
        """处理排行榜命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_ranking(user_id, group_id, self._current_message_data))

        except Exception as e:
            self.logger.error(f"排行榜命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_hire_bodyguard(self, args):
        """处理雇佣保镖命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 解析保镖类型
            bodyguard_type = "basic"  # 默认普通保镖
            if args:
                content = " ".join(args).lower()
                if "高级" in content or "advanced" in content:
                    bodyguard_type = "advanced"
                elif "精英" in content or "elite" in content:
                    bodyguard_type = "elite"

            return self.run_async(self.command_handler.handle_hire_bodyguard(user_id, group_id, bodyguard_type))

        except Exception as e:
            self.logger.error(f"雇佣保镖命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_bodyguard_status(self, args):
        """处理保镖状态命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_bodyguard_status(user_id, group_id))

        except Exception as e:
            self.logger.error(f"保镖状态命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_report(self, args):
        """处理举报命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_report(user_id, group_id, self._current_message_data))

        except Exception as e:
            self.logger.error(f"举报命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_report_results(self, args):
        """处理举报结果查询命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            return self.run_async(self.command_handler.handle_report_results(user_id, group_id))

        except Exception as e:
            self.logger.error(f"举报结果查询命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_achievements(self, args):
        """处理成就命令"""
        try:
            # 获取QQ号和群组信息
            raw_user_id, raw_group_id = self.get_user_group_from_message(self._current_message_data)
            if not raw_user_id or not raw_group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 通过QQ号查找对应的union_openid和group_openid
            try:
                # 如果raw_user_id是QQ号，需要转换为union_openid
                if raw_user_id.isdigit():
                    # 通过QQ号查找绑定记录
                    session = self.db_manager.get_session()
                    try:
                        from .core.database import QQBinding
                        binding = session.query(QQBinding).filter_by(qq_number=raw_user_id).first()
                        if binding:
                            user_id = binding.union_openid
                            group_id = binding.group_openid
                        else:
                            return MessageBuilder.text("❌ 请先绑定QQ号")
                    finally:
                        self.db_manager.close_session(session)
                else:
                    # 如果已经是union_openid格式，直接使用
                    user_id = raw_user_id
                    group_id = raw_group_id

                return self.run_async(self.command_handler.handle_achievements(user_id, group_id))

            except Exception as e:
                self.logger.error(f"查找用户绑定信息失败: {e}")
                return MessageBuilder.text("❌ 用户信息查找失败")

        except Exception as e:
            self.logger.error(f"成就命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    def handle_set_title(self, args):
        """处理设置称号命令"""
        try:
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            if not args:
                return MessageBuilder.text("❌ 请指定要设置的称号\n例如：设置称号 劳模")

            title = " ".join(args)

            return self.run_async(self.command_handler.handle_set_title(user_id, group_id, title))

        except Exception as e:
            self.logger.error(f"设置称号命令处理失败: {e}")
            return MessageBuilder.text("❌ 命令处理失败，请稍后重试")

    # ==================== Hook事件处理器 ====================

    def on_bot_start_hook(self, bot_id):
        """机器人启动Hook"""
        self.logger.info(f"牛马市场插件已为机器人 {bot_id} 准备就绪")
        return {'message': f'牛马市场插件已为机器人 {bot_id} 准备就绪'}

    def on_bot_stop_hook(self, bot_id):
        """机器人停止Hook"""
        self.logger.info(f"牛马市场插件已为机器人 {bot_id} 清理资源")
        return {'message': f'牛马市场插件已为机器人 {bot_id} 清理资源'}

    # ==================== 插件生命周期 ====================

    def on_enable(self):
        """插件启用时调用"""
        super().on_enable()
        self.logger.info("牛马市场插件已启用，支持QQ绑定和游戏功能")

    def on_disable(self):
        """插件禁用时调用"""
        super().on_disable()
        self.logger.info("牛马市场插件已禁用")
