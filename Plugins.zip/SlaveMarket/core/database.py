"""
SQLAlchemy数据库管理模块
"""

import os
from datetime import datetime
from typing import Optional, List

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, Text, DECIMAL, \
    Index, CheckConstraint, UniqueConstraint
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

Base = declarative_base()


class QQBinding(Base):
    """QQ绑定表"""
    __tablename__ = 'qq_bindings'

    id = Column(Integer, primary_key=True, autoincrement=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    qq_number = Column(String(20), nullable=False)
    bind_time = Column(DateTime, default=datetime.utcnow)

    # 唯一约束
    __table_args__ = ({'sqlite_autoincrement': True},)


class AuthCode(Base):
    """授权码表"""
    __tablename__ = 'auth_codes'

    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String(100), unique=True, nullable=False)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    create_time = Column(DateTime, default=datetime.utcnow)
    used = Column(Boolean, default=False)
    # 原始消息信息，用于回复绑定成功消息
    original_msg_id = Column(String(200))  # 原始消息ID
    reply_msg_id = Column(String(200))  # 回复消息ID
    bot_id = Column(Integer)  # 机器人ID


class User(Base):
    """用户游戏数据表"""
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    qq_number = Column(String(20), nullable=False)
    currency = Column(Float, default=0.0)  # 金币数量
    value = Column(Float, default=100.0)  # 身价
    master_openid = Column(String(50), default='')
    last_work_time = Column(DateTime, default=None)
    last_rob_time = Column(DateTime, default=None)
    last_purchase_time = Column(DateTime, default=None)
    work_count = Column(Integer, default=0)
    purchase_count = Column(Integer, default=0)
    sold_count = Column(Integer, default=0)
    freedom_count = Column(Integer, default=0)
    total_earned = Column(Float, default=0.0)  # 总收入
    total_spent = Column(Float, default=0.0)  # 总支出
    create_time = Column(DateTime, default=datetime.utcnow)
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 数据完整性约束
    __table_args__ = (
        # 唯一约束：每个群组中每个用户只能有一条记录
        UniqueConstraint('union_openid', 'group_openid', name='uq_user_group'),

        # 检查约束：确保金币和身价不为负数
        CheckConstraint('currency >= 0', name='ck_currency_positive'),
        CheckConstraint('value >= 0', name='ck_value_positive'),
        CheckConstraint('total_earned >= 0', name='ck_earned_positive'),
        CheckConstraint('total_spent >= 0', name='ck_spent_positive'),

        # 性能索引
        Index('idx_users_group_union', 'group_openid', 'union_openid'),
        Index('idx_users_currency_desc', 'group_openid', 'currency'),
        Index('idx_users_value_desc', 'group_openid', 'value'),
        Index('idx_users_master', 'master_openid'),
        Index('idx_users_work_time', 'last_work_time'),
        Index('idx_users_qq', 'qq_number'),
    )

    # 关系（暂时注释掉，避免循环引用问题）
    # slaves = relationship("SlaveRelation", foreign_keys="SlaveRelation.master_id", back_populates="master")
    # master_relation = relationship("SlaveRelation", foreign_keys="SlaveRelation.slave_id", back_populates="slave")


class SlaveRelation(Base):
    """奴隶关系表"""
    __tablename__ = 'slave_relations'

    id = Column(Integer, primary_key=True, autoincrement=True)
    master_openid = Column(String(50), nullable=False)
    slave_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    purchase_time = Column(DateTime, default=datetime.utcnow)
    purchase_price = Column(Float, nullable=False)  # 购买价格

    # 数据完整性约束
    __table_args__ = (
        # 唯一约束：每个群组中每个奴隶只能有一个主人
        UniqueConstraint('slave_openid', 'group_openid', name='uq_slave_group'),

        # 检查约束：确保购买价格为正数
        CheckConstraint('purchase_price > 0', name='ck_purchase_price_positive'),

        # 检查约束：主人和奴隶不能是同一人
        CheckConstraint('master_openid != slave_openid', name='ck_no_self_ownership'),

        # 性能索引
        Index('idx_slave_master_group', 'master_openid', 'group_openid'),
        Index('idx_slave_slave_group', 'slave_openid', 'group_openid'),
        Index('idx_slave_purchase_time', 'purchase_time'),
        Index('idx_slave_group', 'group_openid'),
    )

    # 关系（暂时注释掉，避免循环引用问题）
    # master = relationship("User", foreign_keys=[master_id], back_populates="slaves")
    # slave = relationship("User", foreign_keys=[slave_id], back_populates="master_relation")


class Transaction(Base):
    """交易记录表"""
    __tablename__ = 'transactions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    group_openid = Column(String(50), nullable=False)
    from_union_openid = Column(String(50), nullable=False)
    to_union_openid = Column(String(50), nullable=False)
    transaction_type = Column(String(20), nullable=False)  # work, purchase, rob, freedom
    amount = Column(Float, nullable=False)  # 交易金额
    description = Column(Text)
    create_time = Column(DateTime, default=datetime.utcnow)

    # 数据完整性约束
    __table_args__ = (
        # 检查约束：确保交易金额为正数
        CheckConstraint('amount > 0', name='ck_transaction_amount_positive'),

        # 检查约束：确保交易类型有效
        CheckConstraint("transaction_type IN ('work', 'purchase', 'rob', 'freedom', 'bodyguard')",
                        name='ck_transaction_type_valid'),

        # 性能索引
        Index('idx_trans_group_time', 'group_openid', 'create_time'),
        Index('idx_trans_from_user', 'from_union_openid', 'create_time'),
        Index('idx_trans_to_user', 'to_union_openid', 'create_time'),
        Index('idx_trans_type_time', 'transaction_type', 'create_time'),
    )


class WorkRecord(Base):
    """工作记录表"""
    __tablename__ = 'work_records'

    id = Column(Integer, primary_key=True, autoincrement=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    income = Column(Float, nullable=False)  # 工作收入
    master_income = Column(Float, default=0.0)  # 主人分成
    master_openid = Column(String(50), default='')
    event_message = Column(Text, default='')
    work_type = Column(String(20), default='工作')  # 新增工作类型字段
    work_time = Column(DateTime, default=datetime.utcnow)

    # 数据完整性约束
    __table_args__ = (
        # 检查约束：确保收入为正数
        CheckConstraint('income >= 0', name='ck_work_income_positive'),
        CheckConstraint('master_income >= 0', name='ck_master_income_positive'),

        # 性能索引
        Index('idx_work_user_time', 'union_openid', 'work_time'),
        Index('idx_work_group_time', 'group_openid', 'work_time'),
        Index('idx_work_master_time', 'master_openid', 'work_time'),
        Index('idx_work_type_time', 'work_type', 'work_time'),
    )


class RobRecord(Base):
    """抢劫记录表"""
    __tablename__ = 'rob_records'

    id = Column(Integer, primary_key=True, autoincrement=True)
    robber_openid = Column(String(50), nullable=False)
    target_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    success = Column(Boolean, nullable=False)
    amount = Column(Float, nullable=False)  # 抢劫金额
    success_rate = Column(Float, nullable=False)  # 成功率
    rob_time = Column(DateTime, default=datetime.utcnow)

    # 数据完整性约束
    __table_args__ = (
        # 检查约束：确保金额为正数
        CheckConstraint('amount >= 0', name='ck_rob_amount_positive'),

        # 检查约束：确保成功率在0-100之间
        CheckConstraint('success_rate >= 0 AND success_rate <= 100', name='ck_success_rate_valid'),

        # 检查约束：抢劫者和目标不能是同一人
        CheckConstraint('robber_openid != target_openid', name='ck_no_self_rob'),

        # 性能索引
        Index('idx_rob_robber_time', 'robber_openid', 'rob_time'),
        Index('idx_rob_target_time', 'target_openid', 'rob_time'),
        Index('idx_rob_group_time', 'group_openid', 'rob_time'),
        Index('idx_rob_success', 'success', 'rob_time'),
    )


class Bodyguard(Base):
    """保镖记录表"""
    __tablename__ = 'bodyguards'

    id = Column(Integer, primary_key=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    bodyguard_type = Column(String(20), nullable=False)
    hire_time = Column(DateTime, nullable=False)
    expire_time = Column(DateTime, nullable=False)
    defense_count = Column(Integer, default=0)
    counter_count = Column(Integer, default=0)

    # 数据完整性约束
    __table_args__ = (
        # 唯一约束：每个用户在每个群组中只能有一个有效保镖
        UniqueConstraint('union_openid', 'group_openid', name='uq_bodyguard_user_group'),

        # 检查约束：确保时间逻辑正确
        CheckConstraint('expire_time > hire_time', name='ck_bodyguard_time_valid'),

        # 检查约束：确保计数为非负数
        CheckConstraint('defense_count >= 0', name='ck_defense_count_positive'),
        CheckConstraint('counter_count >= 0', name='ck_counter_count_positive'),

        # 性能索引
        Index('idx_bodyguard_user_group', 'union_openid', 'group_openid'),
        Index('idx_bodyguard_expire', 'expire_time'),
        Index('idx_bodyguard_type', 'bodyguard_type'),
    )


class Report(Base):
    """举报记录表"""
    __tablename__ = 'reports'

    id = Column(Integer, primary_key=True)
    reporter_openid = Column(String(50), nullable=False)
    reported_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    report_type = Column(String(20), nullable=False)
    description = Column(Text)
    evidence = Column(Text)
    status = Column(String(20), default='pending')
    result = Column(Text)
    penalty_type = Column(String(20))
    penalty_amount = Column(Float, default=0)
    create_time = Column(DateTime, nullable=False)
    process_time = Column(DateTime)


class JailRecord(Base):
    """监禁记录表"""
    __tablename__ = 'jail_records'

    id = Column(Integer, primary_key=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    penalty_type = Column(String(20), nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    reason = Column(Text)


class UserAchievement(Base):
    """用户成就表"""
    __tablename__ = 'user_achievements'

    id = Column(Integer, primary_key=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    achievement_id = Column(String(50), nullable=False)
    unlock_time = Column(DateTime, nullable=False)


class UserTitle(Base):
    """用户称号表"""
    __tablename__ = 'user_titles'

    id = Column(Integer, primary_key=True)
    union_openid = Column(String(50), nullable=False)
    group_openid = Column(String(50), nullable=False)
    title = Column(String(50), nullable=False)
    active = Column(Boolean, default=False)
    unlock_time = Column(DateTime, nullable=False)


class DatabaseManager:
    """SQLAlchemy数据库管理器"""

    def __init__(self, db_path: str = None):
        if db_path is None:
            # 获取插件根目录
            plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(plugin_dir, "data", "slave_market.db")

        self.db_path = db_path
        self.ensure_data_dir()

        # 创建数据库引擎
        self.engine = create_engine(f'sqlite:///{self.db_path}', echo=False)

        # 创建会话工厂
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

    def ensure_data_dir(self):
        """确保数据目录存在"""
        dir_path = os.path.dirname(self.db_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)

    def init_database(self):
        """初始化数据库表"""
        try:
            Base.metadata.create_all(bind=self.engine)
        except SQLAlchemyError as e:
            raise Exception(f"数据库初始化失败: {e}")

    def get_session(self) -> Session:
        """获取数据库会话"""
        return self.SessionLocal()

    def close_session(self, session: Session):
        """关闭数据库会话"""
        try:
            session.close()
        except Exception:
            pass

    # ==================== QQ绑定相关 ====================

    def save_qq_binding(self, union_openid: str, group_openid: str, qq_number: str) -> bool:
        """保存QQ绑定"""
        session = self.get_session()
        try:
            # 检查是否已存在绑定
            existing = session.query(QQBinding).filter_by(
                union_openid=union_openid, group_openid=group_openid
            ).first()

            if existing:
                existing.qq_number = qq_number
                existing.bind_time = datetime.utcnow()
            else:
                binding = QQBinding(
                    union_openid=union_openid,
                    group_openid=group_openid,
                    qq_number=qq_number
                )
                session.add(binding)

            session.commit()
            return True

        except SQLAlchemyError:
            session.rollback()
            return False
        finally:
            self.close_session(session)

    def get_qq_binding(self, union_openid: str, group_openid: str) -> Optional[str]:
        """获取QQ绑定"""
        session = self.get_session()
        try:
            binding = session.query(QQBinding).filter_by(
                union_openid=union_openid, group_openid=group_openid
            ).first()

            if binding:
                return binding.qq_number
            else:
                return None

        except SQLAlchemyError as e:
            return None
        finally:
            self.close_session(session)

    def save_auth_code(self, code: str, union_openid: str, group_openid: str,
                       original_msg_id: str = None, reply_msg_id: str = None, bot_id: int = None) -> bool:
        """保存授权码"""
        session = self.get_session()
        try:
            auth_code = AuthCode(
                code=code,
                union_openid=union_openid,
                group_openid=group_openid,
                original_msg_id=original_msg_id,
                reply_msg_id=reply_msg_id,
                bot_id=bot_id
            )
            session.add(auth_code)
            session.commit()
            return True

        except SQLAlchemyError as e:
            session.rollback()
            # 记录具体错误信息
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"保存授权码失败: {e}")
            return False
        finally:
            self.close_session(session)

    def get_auth_code_info(self, code: str) -> Optional[dict]:
        """获取授权码信息"""
        session = self.get_session()
        try:
            auth_code = session.query(AuthCode).filter_by(code=code).first()

            if auth_code:
                result = {
                    'union_openid': auth_code.union_openid,
                    'group_openid': auth_code.group_openid,
                    'create_time': auth_code.create_time,
                    'used': auth_code.used,
                    'original_msg_id': auth_code.original_msg_id,
                    'reply_msg_id': auth_code.reply_msg_id,
                    'bot_id': auth_code.bot_id
                }
                return result
            else:
                return None

        except SQLAlchemyError as e:
            return None
        finally:
            self.close_session(session)

    def mark_auth_code_used(self, code: str) -> bool:
        """标记授权码已使用"""
        session = self.get_session()
        try:
            auth_code = session.query(AuthCode).filter_by(code=code).first()
            if auth_code:
                auth_code.used = True
                session.commit()
                return True
            return False

        except SQLAlchemyError:
            session.rollback()
            return False
        finally:
            self.close_session(session)

    def cleanup_expired_auth_codes(self, expire_minutes: int = 5):
        """清理过期的授权码"""
        session = self.get_session()
        try:
            from datetime import timedelta
            expire_time = datetime.utcnow() - timedelta(minutes=expire_minutes)

            session.query(AuthCode).filter(
                AuthCode.create_time < expire_time
            ).delete()

            session.commit()

        except SQLAlchemyError:
            session.rollback()
        finally:
            self.close_session(session)

    # ==================== 用户数据相关 ====================

    def create_user(self, union_openid: str, group_openid: str, qq_number: str) -> bool:
        """创建用户"""
        session = self.get_session()
        try:
            # 检查是否已存在
            existing = session.query(User).filter_by(
                union_openid=union_openid, group_openid=group_openid
            ).first()

            if existing:
                existing.qq_number = qq_number
                existing.update_time = datetime.utcnow()
            else:
                user = User(
                    union_openid=union_openid,
                    group_openid=group_openid,
                    qq_number=qq_number
                )
                session.add(user)

            session.commit()
            return True

        except SQLAlchemyError:
            session.rollback()
            return False
        finally:
            self.close_session(session)

    def get_user(self, union_openid: str, group_openid: str) -> Optional[User]:
        """获取用户数据"""
        session = self.get_session()
        try:
            user = session.query(User).filter_by(
                union_openid=union_openid, group_openid=group_openid
            ).first()

            if user:
                # 分离对象以便在会话外使用
                session.expunge(user)

            return user

        except SQLAlchemyError:
            return None
        finally:
            self.close_session(session)

    def update_user(self, user: User) -> bool:
        """更新用户数据"""
        session = self.get_session()
        try:
            user.update_time = datetime.utcnow()
            session.merge(user)
            session.commit()
            return True
        except SQLAlchemyError:
            session.rollback()
            return False
        finally:
            self.close_session(session)

    def get_users_with_game_data(self, group_openid: str) -> List[str]:
        """获取有游戏数据的用户列表（返回union_openid列表）"""
        session = self.get_session()
        try:
            users = session.query(User).filter_by(group_openid=group_openid).all()
            return [user.union_openid for user in users]

        except SQLAlchemyError:
            return []
        finally:
            self.close_session(session)

    def clean_currency_precision(self) -> bool:
        """清理金币数据精度，将所有金币相关字段四舍五入到1位小数"""
        session = self.get_session()
        try:
            # 获取所有用户
            users = session.query(User).all()

            updated_count = 0
            for user in users:
                # 四舍五入到1位小数
                old_currency = user.currency
                old_value = user.value
                old_earned = user.total_earned
                old_spent = user.total_spent

                user.currency = round(float(user.currency), 1)
                user.value = round(float(user.value), 1)
                user.total_earned = round(float(user.total_earned), 1)
                user.total_spent = round(float(user.total_spent), 1)

                # 检查是否有变化
                if (old_currency != user.currency or old_value != user.value or
                        old_earned != user.total_earned or old_spent != user.total_spent):
                    updated_count += 1

            session.commit()
            return True

        except SQLAlchemyError as e:
            session.rollback()
            return False
        finally:
            self.close_session(session)
