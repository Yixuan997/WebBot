"""
QQ绑定插件
提供统一的QQ绑定服务，供其他插件调用
功能：绑定、绑定查询、取消绑定
"""

import asyncio
from typing import Dict, Any, Optional

from Core.logging.file_logger import log_info, log_error
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin

# 导入绑定系统
from .bind import QQBindSystem
from .database import QQBindDatabase


class Plugin(BasePlugin):
    """QQ绑定插件"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "QQBind"
        self.version = "1.0.0"
        self.description = "QQ绑定服务"
        self.author = "Yixuan"
        self.priority = 10  # 高优先级，其他插件可能依赖此插件

        # 注册命令信息
        self.register_command_info('绑定')
        self.register_command_info('绑定查询')
        self.register_command_info('解绑')

        # 命令处理器
        self.command_handlers = {
            '绑定': self.handle_bind_qq,
            '绑定查询': self.handle_my_info,
            '解绑': self.handle_unbind_qq
        }

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.handle_message_hook],
            'bot_start': [self.on_bot_start_hook],
            'bot_stop': [self.on_bot_stop_hook]
        }

        # 初始化系统组件
        self.database = None
        self.bind_system = None
        
        # 当前消息数据和bot_id
        self._current_message_data = None
        self._current_bot_id = None

    def on_enable(self):
        """插件启用时调用"""
        super().on_enable()
        try:
            
            # 初始化数据库
            self.database = QQBindDatabase()
            
            # 初始化绑定系统
            self.bind_system = QQBindSystem(self.database)
            log_info(0, "QQBind插件已启用", "QQBIND_PLUGIN_ENABLED")
        except Exception as e:
            log_error(0, f"QQBind插件启用失败: {e}", "QQBIND_PLUGIN_ENABLE_ERROR", error=str(e))

    def on_disable(self):
        """插件禁用时调用"""
        super().on_disable()
        log_info(0, "QQBind插件已禁用", "QQBIND_PLUGIN_DISABLED")

    def run_async(self, coro):
        """在多线程环境中安全执行异步函数"""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(coro)

    def get_user_group_from_message(self, message_data: Dict[str, Any]) -> tuple:
        """从消息数据中提取用户ID和群组ID"""
        try:
            # 获取用户ID（union_openid）
            author = message_data.get('author', {})
            user_id = author.get('union_openid') or author.get('id')

            # 获取群组ID
            group_id = message_data.get('group_openid') or message_data.get('guild_id')

            return user_id, group_id
        except Exception as e:
            log_error(0, f"提取用户群组信息失败: {e}", "QQBIND_EXTRACT_USER_GROUP_ERROR", error=str(e))
            return None, None

    # ==================== Hook事件处理 ====================

    def handle_message_hook(self, message_data, user_id=None, bot_id=None):
        """处理消息Hook"""
        try:
            # 保存当前消息数据和bot_id
            self._current_message_data = message_data
            self._current_bot_id = bot_id

            content = message_data.get('content', '').strip()

            # 智能处理命令（支持带/和不带/的命令）
            result = self._handle_smart_command(content, bot_id)
            return result

        except Exception as e:
            log_error(bot_id or 0, f"QQBind插件处理消息异常: {e}", "QQBIND_MESSAGE_HOOK_ERROR", error=str(e))
            return {'handled': False}

    def _handle_smart_command(self, content, bot_id=None):
        """智能命令处理 - 支持带/和不带/的命令"""
        # 检查是否是带/的命令
        if content.startswith('/'):
            return self._handle_command(content, bot_id)

        # 检查是否是不带/的命令
        parts = content.split()
        if not parts:
            return {'handled': False}

        command = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        # 检查是否是支持的命令
        if command in self.command_handlers:
            try:
                handler = self.command_handlers[command]
                response = handler(args)
                return {
                    'response': response,
                    'handled': True
                }
            except Exception as e:
                log_error(bot_id or 0, f"QQBind命令处理异常: {e}", "QQBIND_COMMAND_ERROR")
                return {
                    'response': MessageBuilder.text(f"❌ 命令执行出错: {str(e)}"),
                    'handled': True
                }

        return {'handled': False}

    def _handle_command(self, content, bot_id=None):
        """处理带/的命令"""
        # 解析命令
        parts = content[1:].split()  # 去掉/前缀并分割
        if not parts:
            return {'handled': False}

        command = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        # 检查是否是支持的命令
        if command in self.command_handlers:
            try:
                handler = self.command_handlers[command]
                response = handler(args)
                return {
                    'response': response,
                    'handled': True
                }
            except Exception as e:
                log_error(bot_id or 0, f"QQBind命令处理异常: {e}", "QQBIND_COMMAND_ERROR")
                return {
                    'response': MessageBuilder.text(f"❌ 命令执行出错: {str(e)}"),
                    'handled': True
                }

        return {'handled': False}

    def on_bot_start_hook(self, bot_id):
        """机器人启动Hook"""
        return {'message': f'QQBind插件已为机器人 {bot_id} 准备就绪'}

    def on_bot_stop_hook(self, bot_id):
        """机器人停止Hook"""
        return {'message': f'QQBind插件已为机器人 {bot_id} 清理资源'}

    # ==================== 命令处理器 ====================

    def handle_bind_qq(self, args):
        """处理绑定QQ命令"""
        try:
            
            # 检查系统组件是否已初始化
            if not self.bind_system:
                self.on_enable()
            
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")


            # 提取原始消息信息
            original_msg_id = self._current_message_data.get('id')
            reply_msg_id = self._current_message_data.get('msg_id')
            bot_id = self._current_bot_id

            # 调用绑定系统
            result = self.run_async(self.bind_system.handle_bind_qq(
                user_id, group_id, original_msg_id, reply_msg_id, bot_id
            ))
            return result

        except Exception as e:
            log_error(0, f"QQBind绑定命令处理失败: {e}", "QQBIND_BIND_COMMAND_ERROR")
            return MessageBuilder.text("❌ 绑定失败，请稍后重试")

    def handle_my_info(self, args):
        """处理绑定查询命令"""
        try:
            
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 获取绑定信息
            bound_qq = self.run_async(self.bind_system.get_bound_qq(user_id))

            if not bound_qq:
                return MessageBuilder.text("❌ 您还没有绑定QQ号\n\n发送：绑定")

            # 获取绑定时间
            bind_info = self.database.get_bind_info(user_id)
            bind_time = bind_info.get('bind_time', '未知') if bind_info else '未知'

            message_parts = [
                "📱 我的绑定信息",
                f"🆔 用户ID: {user_id[:8]}...{user_id[-8:]}",
                f"📞 绑定QQ: {bound_qq}",
                f"📅 绑定时间: {bind_time}",
                "",
                "💡 发送 '解绑' 可以解除绑定"
            ]

            return MessageBuilder.text("\n".join(message_parts))

        except Exception as e:
            log_error(0, f"QQBind查看信息命令处理失败: {e}", "QQBIND_INFO_COMMAND_ERROR")
            return MessageBuilder.text("❌ 查看信息失败，请稍后重试")

    def handle_unbind_qq(self, args):
        """处理取消绑定命令"""
        try:
            
            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 检查是否已绑定
            bound_qq = self.run_async(self.bind_system.get_bound_qq(user_id))
            if not bound_qq:
                return MessageBuilder.text("❌ 您还没有绑定QQ号")

            # 执行取消绑定
            success = self.database.unbind_qq(user_id)
            
            if success:
                return MessageBuilder.text(f"✅ 已成功取消绑定QQ号: {bound_qq}")
            else:
                return MessageBuilder.text("❌ 取消绑定失败，请稍后重试")

        except Exception as e:
            log_error(0, f"QQBind取消绑定命令处理失败: {e}", "QQBIND_UNBIND_COMMAND_ERROR")
            return MessageBuilder.text("❌ 取消绑定失败，请稍后重试")

    # ==================== 公共API（供其他插件调用） ====================

    def get_bound_qq_for_plugin(self, user_id: str) -> Optional[str]:
        """供其他插件调用：获取绑定的QQ号"""
        try:
            if not self.bind_system:
                return None
            return self.run_async(self.bind_system.get_bound_qq(user_id))
        except Exception as e:
            log_error(0, f"插件API调用失败: {e}", "QQBIND_API_ERROR")
            return None

    def is_user_bound_for_plugin(self, user_id: str) -> bool:
        """供其他插件调用：检查用户是否已绑定"""
        try:
            if not self.bind_system:
                return False
            return self.run_async(self.bind_system.is_user_bound(user_id))
        except Exception as e:
            log_error(0, f"插件API调用失败: {e}", "QQBIND_API_ERROR")
            return False

    def require_qq_bind_for_plugin(self, user_id: str) -> Optional[MessageBuilder]:
        """供其他插件调用：要求用户绑定QQ号"""
        try:
            if not self.bind_system:
                return MessageBuilder.text("❌ 绑定系统未初始化")
            return self.run_async(self.bind_system.require_qq_bind(user_id))
        except Exception as e:
            log_error(0, f"插件API调用失败: {e}", "QQBIND_API_ERROR")
            return MessageBuilder.text("❌ 绑定检查失败")

    def start_bind_with_hint_for_plugin(self, user_id: str, group_id: str, custom_hint: str,
                                        original_msg_id: str = None, reply_msg_id: str = None,
                                        bot_id: int = None) -> MessageBuilder:
        """供其他插件调用：启动绑定流程并添加自定义提示"""
        try:
            if not self.bind_system:
                return MessageBuilder.text("❌ 绑定系统未初始化")

            return self.run_async(self.bind_system.handle_bind_qq(
                user_id, group_id, original_msg_id, reply_msg_id, bot_id, custom_hint
            ))
        except Exception as e:
            log_error(0, f"插件API调用失败: {e}", "QQBIND_API_ERROR")
            return MessageBuilder.text("❌ 绑定启动失败")
