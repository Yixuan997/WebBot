"""
QQ绑定数据库模块
简化的数据库设计，只存储用户ID和绑定的QQ号
"""

import sqlite3
import os
from datetime import datetime
from typing import Optional, Dict, Any
from contextlib import contextmanager

from Core.logging.file_logger import log_info, log_error


class QQBindDatabase:
    """QQ绑定数据库管理器"""

    def __init__(self, db_path: str = None):
        """初始化数据库"""
        if db_path is None:
            # 默认数据库路径
            db_dir = os.path.join(os.path.dirname(__file__), 'data')
            os.makedirs(db_dir, exist_ok=True)
            db_path = os.path.join(db_dir, 'bind.db')
        
        self.db_path = db_path
        
        # 初始化数据库表
        self._init_database()

    def _init_database(self):
        """初始化数据库表"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 创建QQ绑定表
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS qq_bindings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id TEXT UNIQUE NOT NULL,
                        qq_number TEXT NOT NULL,
                        bind_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # 创建授权码表（用于绑定流程）
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS auth_codes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        code TEXT UNIQUE NOT NULL,
                        user_id TEXT NOT NULL,
                        group_id TEXT NOT NULL,
                        create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        used BOOLEAN DEFAULT FALSE,
                        original_msg_id TEXT,
                        reply_msg_id TEXT,
                        bot_id INTEGER
                    )
                ''')
                
                conn.commit()
                
        except Exception as e:
            log_error(0, f"QQBind数据库初始化失败: {e}", "QQBIND_DB_INIT_ERROR", error=str(e))

    @contextmanager
    def _get_connection(self):
        """获取数据库连接（上下文管理器）"""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # 使结果可以像字典一样访问
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            raise e
        finally:
            if conn:
                conn.close()

    # ==================== QQ绑定相关 ====================

    def save_qq_binding(self, user_id: str, qq_number: str) -> bool:
        """保存QQ绑定"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                # 使用INSERT OR REPLACE来处理重复绑定
                cursor.execute('''
                    INSERT OR REPLACE INTO qq_bindings (user_id, qq_number, bind_time)
                    VALUES (?, ?, ?)
                ''', (user_id, qq_number, datetime.now()))

                conn.commit()
                return True

        except Exception as e:
            log_error(0, f"QQBind保存绑定失败: {e}", "QQBIND_SAVE_BINDING_ERROR", error=str(e))
            return False

    def get_qq_binding(self, user_id: str) -> Optional[str]:
        """获取QQ绑定"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    SELECT qq_number FROM qq_bindings
                    WHERE user_id = ?
                ''', (user_id,))

                result = cursor.fetchone()
                if result:
                    qq_number = result['qq_number']
                    return qq_number
                else:
                    return None

        except Exception as e:
            log_error(0, f"QQBind获取绑定失败: {e}", "QQBIND_GET_BINDING_ERROR", error=str(e))
            return None

    def get_bind_info(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取完整的绑定信息"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    SELECT * FROM qq_bindings
                    WHERE user_id = ?
                ''', (user_id,))

                result = cursor.fetchone()
                if result:
                    return dict(result)
                else:
                    return None

        except Exception as e:
            log_error(0, f"QQBind获取绑定信息失败: {e}", "QQBIND_GET_BIND_INFO_ERROR", error=str(e))
            return None

    def unbind_qq(self, user_id: str) -> bool:
        """取消QQ绑定"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    DELETE FROM qq_bindings
                    WHERE user_id = ?
                ''', (user_id,))

                conn.commit()

                if cursor.rowcount > 0:
                    return True
                else:
                    return False

        except Exception as e:
            log_error(0, f"QQBind取消绑定失败: {e}", "QQBIND_UNBIND_ERROR", error=str(e))
            return False

    # ==================== 授权码相关 ====================

    def save_auth_code(self, code: str, user_id: str, group_id: str,
                       original_msg_id: str = None, reply_msg_id: str = None,
                       bot_id: int = None) -> bool:
        """保存授权码"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO auth_codes (code, user_id, group_id, original_msg_id, reply_msg_id, bot_id)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (code, user_id, group_id, original_msg_id, reply_msg_id, bot_id))
                
                conn.commit()
                return True
                
        except Exception as e:
            log_error(0, f"QQBind保存授权码失败: {e}", "QQBIND_SAVE_AUTH_CODE_ERROR", error=str(e))
            return False

    def get_auth_code_info(self, code: str) -> Optional[Dict[str, Any]]:
        """获取授权码信息"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    SELECT * FROM auth_codes WHERE code = ?
                ''', (code,))
                
                result = cursor.fetchone()
                if result:
                    return dict(result)
                else:
                    return None
                    
        except Exception as e:
            log_error(0, f"QQBind获取授权码信息失败: {e}", "QQBIND_GET_AUTH_CODE_ERROR", error=str(e))
            return None

    def mark_auth_code_used(self, code: str) -> bool:
        """标记授权码已使用"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    UPDATE auth_codes SET used = TRUE WHERE code = ?
                ''', (code,))
                
                conn.commit()
                return True
                
        except Exception as e:
            log_error(0, f"QQBind标记授权码失败: {e}", "QQBIND_MARK_AUTH_CODE_ERROR", error=str(e))
            return False

    def cleanup_expired_auth_codes(self, expire_minutes: int = 5) -> int:
        """清理过期的授权码"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    DELETE FROM auth_codes 
                    WHERE datetime(create_time, '+{} minutes') < datetime('now')
                '''.format(expire_minutes))
                
                conn.commit()
                deleted_count = cursor.rowcount
                
                if deleted_count > 0:
                    pass
                
                return deleted_count
                
        except Exception as e:
            log_error(0, f"QQBind清理授权码失败: {e}", "QQBIND_CLEANUP_AUTH_CODE_ERROR", error=str(e))
            return 0

    # ==================== 统计信息 ====================

    def get_binding_stats(self) -> Dict[str, int]:
        """获取绑定统计信息"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 总绑定数
                cursor.execute('SELECT COUNT(*) as total FROM qq_bindings')
                total = cursor.fetchone()['total']
                
                # 今日绑定数
                cursor.execute('''
                    SELECT COUNT(*) as today FROM qq_bindings 
                    WHERE date(bind_time) = date('now')
                ''')
                today = cursor.fetchone()['today']
                
                return {
                    'total_bindings': total,
                    'today_bindings': today
                }
                
        except Exception as e:
            log_error(0, f"QQBind获取统计信息失败: {e}", "QQBIND_GET_STATS_ERROR", error=str(e))
            return {'total_bindings': 0, 'today_bindings': 0}
