"""
QQ绑定插件配置文件
"""

# 插件基本配置
PLUGIN_CONFIG = {
    'name': 'QQBind',
    'version': '1.0.0',
    'description': '统一的QQ绑定服务',
    'author': 'Yixuan',
    'priority': 10
}

# QQ绑定API配置
QQ_AUTH_CONFIG = {
    'base_url': 'https://q.qq.com/ide/devtoolAuth',
    'qzone_url': 'https://h5.qzone.qq.com/qqq/code',
    'timeout': 10,
    'auth_timeout': 300,  # 授权超时时间（秒）
    'check_interval': 10,  # 检查间隔（秒）
    'max_checks': 2  # 最大检查次数
}

# 数据库配置
DATABASE_CONFIG = {
    'db_name': 'bind.db',
    'data_dir': 'data'
}
