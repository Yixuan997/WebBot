"""
QQ绑定系统
处理QQ绑定的核心逻辑
"""

import asyncio
from datetime import datetime, timedelta
from typing import Optional

import requests
from Core.logging.file_logger import log_info, log_error
from Core.message.builder import MessageBuilder
from .database import QQBindDatabase


class QQBindSystem:
    """QQ绑定系统"""

    def __init__(self, database: QQBindDatabase):
        self.database = database

        # QQ绑定相关配置
        self.qq_auth_base_url = "https://q.qq.com/ide/devtoolAuth"
        self.qzone_base_url = "https://h5.qzone.qq.com/qqq/code"
        self.auth_timeout = 300  # 授权超时时间（秒）
        self.check_interval = 10  # 检查间隔（秒）

        # 内存中存储自定义提示（临时数据）
        self._custom_hints = {}  # {auth_code: custom_hint}

    async def get_qq_auth_code(self) -> Optional[str]:
        """获取QQ授权码"""
        try:
            url = f"{self.qq_auth_base_url}/GetLoginCode"
            response = requests.get(url, timeout=10)

            if response.status_code == 200:
                data = response.json()
                if data.get("code") == 0:
                    auth_code = data.get("data", {}).get("code")
                    return auth_code

            return None

        except Exception as e:
            return None

    async def check_qq_auth_status(self, code: str) -> Optional[str]:
        """检查QQ授权状态并获取QQ号"""
        try:
            url = f"{self.qq_auth_base_url}/syncScanSateGetTicket"
            params = {"code": code}

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()

                if data.get("code") == 0:
                    # 根据实际返回的数据结构来解析QQ号
                    ticket_data = data.get("data", {})

                    # 可能的QQ号字段名
                    qq_number = (ticket_data.get("qq") or
                                 ticket_data.get("uin") or
                                 ticket_data.get("openid") or
                                 ticket_data.get("qq_number"))

                    if qq_number:
                        # 确保QQ号是纯数字字符串
                        qq_str = str(qq_number).strip()
                        if qq_str.isdigit():
                            return qq_str

            return None

        except Exception as e:
            return None

    def check_qq_auth_status_sync(self, code: str) -> Optional[str]:
        """检查QQ授权状态并获取QQ号（同步版本）"""
        try:
            url = f"{self.qq_auth_base_url}/syncScanSateGetTicket"
            params = {"code": code}

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()

                if data.get("code") == 0:
                    # 根据实际返回的数据结构来解析QQ号
                    ticket_data = data.get("data", {})

                    # 可能的QQ号字段名
                    qq_number = (ticket_data.get("qq") or
                                 ticket_data.get("uin") or
                                 ticket_data.get("openid") or
                                 ticket_data.get("qq_number"))

                    if qq_number:
                        # 确保QQ号是纯数字字符串
                        qq_str = str(qq_number).strip()
                        if qq_str.isdigit():
                            return qq_str

            return None

        except Exception as e:
            return None

    async def get_bound_qq(self, user_id: str) -> Optional[str]:
        """获取已绑定的QQ号"""
        try:
            result = self.database.get_qq_binding(user_id)
            return result
        except Exception as e:
            return None

    async def is_user_bound(self, user_id: str) -> bool:
        """检查用户是否已绑定QQ号"""
        bound_qq = await self.get_bound_qq(user_id)
        return bound_qq is not None

    async def require_qq_bind(self, user_id: str) -> Optional[MessageBuilder]:
        """要求用户绑定QQ号"""
        is_bound = await self.is_user_bound(user_id)
        if not is_bound:
            return MessageBuilder.text(
                "❌ 请先绑定QQ号才能使用此功能\n\n"
                "发送：绑定"
            )
        return None

    async def handle_bind_qq(self, user_id: str, group_id: str,
                             original_msg_id: str = None, reply_msg_id: str = None,
                             bot_id: int = None, custom_hint: str = None) -> MessageBuilder:
        """处理绑定QQ命令"""
        try:
            # 检查是否已经绑定
            bound_qq = await self.get_bound_qq(user_id)
            if bound_qq:
                return MessageBuilder.text(f"✅ 您已绑定QQ号: {bound_qq}\n如需重新绑定，请先发送 '解绑'")

            # 开始绑定流程
            return await self.start_qq_bind_process(user_id, group_id,
                                                    original_msg_id, reply_msg_id, bot_id, custom_hint)

        except Exception as e:

            return MessageBuilder.text("❌ 绑定处理失败，请稍后重试")

    async def start_qq_bind_process(self, user_id: str, group_id: str,
                                    original_msg_id: str = None, reply_msg_id: str = None,
                                    bot_id: int = None, custom_hint: str = None) -> MessageBuilder:
        """开始QQ绑定流程"""
        try:
            # 获取授权码
            auth_code = await self.get_qq_auth_code()

            if not auth_code:
                return MessageBuilder.text("❌ 获取授权码失败，请稍后重试")


            # 保存授权码和用户信息的关联
            success = self.database.save_auth_code(auth_code, user_id, group_id,
                                                   original_msg_id, reply_msg_id, bot_id)

            # 在内存中保存自定义提示（如果有的话）
            if custom_hint:
                self._custom_hints[auth_code] = custom_hint
            if not success:
                return MessageBuilder.text("❌ 保存授权信息失败，请稍后重试")

            # 生成授权链接
            auth_url = f"{self.qzone_base_url}/{auth_code}?_proxy=1&from=ide"
            # 将.com换成大写.COM
            auth_url = auth_url.replace('.com', '.COM')


            # 启动后台检查任务（使用线程方式）
            import threading
            thread = threading.Thread(target=self._run_check_in_thread, args=(auth_code,))
            thread.daemon = True
            thread.start()

            # 使用text_card_link
            content = f"🔗 QQ号绑定\n\n"
            content += f"请点击下方链接完成QQ号绑定，绑定后即可使用相关功能！\n\n"
            content += f"⏰ 链接5分钟内有效"

            result = MessageBuilder.text_card_link(
                text=content,
                button_text="🔗 点击登录",
                button_url=auth_url,
                description="QQ绑定服务",
                prompt="QQBind"
            )
            return result

        except Exception as e:
            return MessageBuilder.text("❌ 绑定流程启动失败，请稍后重试")

    def _run_check_in_thread(self, auth_code: str):
        """在线程中运行检查任务"""
        try:
            import time

            # 检查2次，每10秒检查一次
            max_checks = 2
            for check_count in range(max_checks):
                time.sleep(self.check_interval)

                # 检查授权码是否还有效
                try:
                    code_info = self.database.get_auth_code_info(auth_code)
                    if not code_info or code_info.get('used'):
                        break
                except Exception as e:
                    continue

                # 检查是否超时
                create_time = code_info['create_time']
                if isinstance(create_time, str):
                    create_time = datetime.fromisoformat(create_time)

                if datetime.utcnow() - create_time > timedelta(seconds=self.auth_timeout):
                    break

                # 检查授权状态（同步方式）
                qq_number = self.check_qq_auth_status_sync(auth_code)

                if qq_number:
                    user_id = code_info["user_id"]
                    group_id = code_info["group_id"]

                    # 保存绑定
                    success = self.database.save_qq_binding(user_id, qq_number)

                    if success:
                        # 标记授权码已使用
                        self.database.mark_auth_code_used(auth_code)

                        try:
                            # 获取原始消息信息
                            original_msg_id = code_info.get('original_msg_id')
                            reply_msg_id = code_info.get('reply_msg_id')
                            bot_id = code_info.get('bot_id')

                            # 获取内存中的自定义提示
                            custom_hint = self._custom_hints.get(auth_code)

                            self._send_bind_success_message(user_id, group_id, qq_number,
                                                            original_msg_id, reply_msg_id, bot_id, custom_hint)

                            # 清理内存中的自定义提示
                            if auth_code in self._custom_hints:
                                del self._custom_hints[auth_code]
                        except Exception as msg_e:
                            log_error(0, f"QQBind发送绑定成功消息失败: {msg_e}", "QQBIND_SEND_SUCCESS_MSG_ERROR")
                        break

        except Exception as e:
            log_error(0, f"QQBind后台检查线程异常: {e}", "QQBIND_BACKGROUND_THREAD_ERROR")

    def _send_bind_success_message(self, user_id: str, group_id: str, qq_number: str,
                                   original_msg_id: str = None, reply_msg_id: str = None, bot_id: int = None, custom_hint: str = None):
        """发送绑定成功消息"""
        try:
            # 构建成功消息
            content = f"🆔 绑定QQ号: {qq_number}\n"
            content += f"✅ 绑定成功！现在可以使用需要QQ绑定的功能了\n\n"
            content += f"💡 发送 '绑定查询' 查看绑定详情\n"
            content += f"💡 发送 '解绑' 可以解除绑定"

            # 如果有自定义提示，添加到消息中
            if custom_hint:
                content += f"\n💡 {custom_hint}"

            success_message = MessageBuilder.text_card(
                text=f"🎉 QQ号绑定成功！\n\n{content}",
                description="QQ绑定服务",
                prompt="QQBind"
            )

            # 在后台线程中需要创建Flask应用上下文
            from flask import current_app
            try:
                # 尝试获取当前应用上下文
                app = current_app._get_current_object()
            except RuntimeError:
                # 如果没有应用上下文，导入应用实例
                from app import app

            # 在应用上下文中执行
            with app.app_context():
                from Adapters import get_adapter_manager
                adapter_manager = get_adapter_manager()

                if adapter_manager:
                    # 构建目标（群聊）
                    target = f"group:{group_id}"
                    # 使用保存的bot_id，如果没有则使用默认值
                    actual_bot_id = bot_id or 2

                    # 使用原始消息信息进行回复
                    success = adapter_manager.send_message(actual_bot_id, target, success_message,
                                                           reply_to_msg_id=reply_msg_id,
                                                           original_msg_id=original_msg_id)
                else:
                    log_error(0, "QQBind适配器管理器为空", "QQBIND_ADAPTER_MANAGER_NULL")
        except Exception as e:
            log_error(0, f"QQBind发送绑定成功消息异常: {e}", "QQBIND_SEND_SUCCESS_MSG_EXCEPTION")
