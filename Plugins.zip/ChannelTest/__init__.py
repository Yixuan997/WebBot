"""
QQ频道功能测试插件
用于测试频道消息发送和接收功能
"""

from Core.logging.file_logger import log_info, log_error
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin


class Plugin(BasePlugin):
    """频道测试插件"""

    def __init__(self):
        super().__init__()
        self.plugin_name = "ChannelTest"
        self.description = "QQ频道功能测试插件"
        self.version = "1.0.0"
        self.author = "QQ Bot Framework"
        self.priority = 10

        # 注册命令
        self.command_handlers = {
            '频道测试': self.handle_channel_test,
            '私信测试': self.handle_dm_test,
            '频道信息': self.handle_channel_info,
        }

        # 注册命令信息
        self.register_command_info('频道测试', '测试频道消息发送功能', '/频道测试 或 频道测试')
        self.register_command_info('私信测试', '测试频道私信发送功能', '/私信测试 或 私信测试')
        self.register_command_info('频道信息', '显示当前频道信息', '/频道信息 或 频道信息')

        # 注册Hook
        self.register_hook('message_received', self.handle_message_hook)
        self.register_hook('guild_event', self.handle_guild_event_hook)
        self.register_hook('channel_event', self.handle_channel_event_hook)
        self.register_hook('member_event', self.handle_member_event_hook)

    def handle_channel_test(self, args, bot_id):
        """处理频道测试命令"""
        try:
            _ = args  # 标记参数已使用
            log_info(bot_id or 0, "处理频道测试命令", "CHANNEL_TEST_COMMAND")
            
            # 构建测试消息
            test_message = MessageBuilder.text("🎉 频道消息发送测试成功！\n\n这是一条来自QQ机器人的频道消息。")
            
            return test_message
            
        except Exception as e:
            log_error(bot_id or 0, f"处理频道测试命令失败: {e}", "CHANNEL_TEST_COMMAND_ERROR", error=str(e))
            return MessageBuilder.text(f"❌ 频道测试失败: {str(e)}")

    def handle_dm_test(self, args, bot_id):
        """处理私信测试命令"""
        try:
            _ = args  # 标记参数已使用
            log_info(bot_id or 0, "处理私信测试命令", "DM_TEST_COMMAND")
            
            # 构建测试消息
            test_message = MessageBuilder.text("📩 频道私信发送测试成功！\n\n这是一条来自QQ机器人的频道私信。")
            
            return test_message
            
        except Exception as e:
            log_error(bot_id or 0, f"处理私信测试命令失败: {e}", "DM_TEST_COMMAND_ERROR", error=str(e))
            return MessageBuilder.text(f"❌ 私信测试失败: {str(e)}")

    def handle_channel_info(self, args, bot_id):
        """处理频道信息命令"""
        try:
            _ = args  # 标记参数已使用
            log_info(bot_id or 0, "处理频道信息命令", "CHANNEL_INFO_COMMAND")
            
            # 构建信息消息
            info_message = MessageBuilder.markdown("""
# 📺 QQ频道功能支持

## ✅ 已支持功能
- **频道消息接收**: 支持接收频道内的普通消息
- **@消息接收**: 支持接收公域频道的@机器人消息  
- **频道消息发送**: 支持发送各种类型的频道消息
- **频道私信**: 支持发送和接收频道私信
- **频道管理事件**: 支持频道创建/更新/删除事件
- **成员管理事件**: 支持成员加入/离开/更新事件

## 🎯 消息类型支持
- 文本消息 (msg_type: 0)
- Markdown消息 (msg_type: 2)  
- Ark卡片消息 (msg_type: 3)
- 富媒体消息 (msg_type: 7)

## 🔧 测试命令
- `频道测试` - 测试频道消息发送
- `私信测试` - 测试频道私信发送
- `频道信息` - 显示此信息

> 💡 **提示**: 所有现有插件都可以在频道中正常工作！
            """)
            
            return info_message
            
        except Exception as e:
            log_error(bot_id or 0, f"处理频道信息命令失败: {e}", "CHANNEL_INFO_COMMAND_ERROR", error=str(e))
            return MessageBuilder.text(f"❌ 获取频道信息失败: {str(e)}")

    def handle_message_hook(self, message_data, user_id, bot_id):
        """处理消息Hook - 记录频道消息"""
        try:
            message_type = message_data.get('type', 'unknown')
            
            # 只处理频道相关消息
            if message_type in ['channel', 'at_message', 'direct_message']:
                content = message_data.get('content', '')
                
                # 记录频道消息
                if message_type == 'channel':
                    log_info(bot_id or 0, f"📢 频道消息: {content[:50]}", "CHANNEL_MESSAGE_RECEIVED",
                             channel_id=message_data.get('channel_id'),
                             guild_id=message_data.get('guild_id'))
                elif message_type == 'at_message':
                    log_info(bot_id or 0, f"📣 @消息: {content[:50]}", "AT_MESSAGE_RECEIVED",
                             channel_id=message_data.get('channel_id'),
                             guild_id=message_data.get('guild_id'))
                elif message_type == 'direct_message':
                    log_info(bot_id or 0, f"📩 私信: {content[:50]}", "DM_MESSAGE_RECEIVED",
                             guild_id=message_data.get('guild_id'))
            
            # 不处理消息，让其他插件继续处理
            return {'handled': False}
            
        except Exception as e:
            log_error(bot_id or 0, f"处理消息Hook失败: {e}", "CHANNEL_MESSAGE_HOOK_ERROR", error=str(e))
            return {'handled': False}

    def handle_guild_event_hook(self, guild_info, bot_id):
        """处理频道管理事件Hook"""
        try:
            event_type = guild_info.get('event_type', 'unknown')
            guild_name = guild_info.get('name', '未知频道')
            
            log_info(bot_id or 0, f"🏰 频道事件: {event_type} - {guild_name}", "GUILD_EVENT_HOOK",
                     event_type=event_type, guild_id=guild_info.get('id'))
            
        except Exception as e:
            log_error(bot_id or 0, f"处理频道事件Hook失败: {e}", "GUILD_EVENT_HOOK_ERROR", error=str(e))

    def handle_channel_event_hook(self, channel_info, bot_id):
        """处理子频道管理事件Hook"""
        try:
            event_type = channel_info.get('event_type', 'unknown')
            channel_name = channel_info.get('name', '未知子频道')
            
            log_info(bot_id or 0, f"📺 子频道事件: {event_type} - {channel_name}", "CHANNEL_EVENT_HOOK",
                     event_type=event_type, channel_id=channel_info.get('id'))
            
        except Exception as e:
            log_error(bot_id or 0, f"处理子频道事件Hook失败: {e}", "CHANNEL_EVENT_HOOK_ERROR", error=str(e))

    def handle_member_event_hook(self, member_info, bot_id):
        """处理成员事件Hook"""
        try:
            event_type = member_info.get('event_type', 'unknown')
            user_info = member_info.get('user', {})
            username = user_info.get('username', '未知用户')
            
            log_info(bot_id or 0, f"👤 成员事件: {event_type} - {username}", "MEMBER_EVENT_HOOK",
                     event_type=event_type, user_id=user_info.get('id'))
            
        except Exception as e:
            log_error(bot_id or 0, f"处理成员事件Hook失败: {e}", "MEMBER_EVENT_HOOK_ERROR", error=str(e))
