#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
QQ开放平台认证管理器
处理用户登录、会话管理等功能
"""

import json
import time
from datetime import datetime, timedelta
from typing import Dict, Optional

import requests

from Core.logging.file_logger import log_info, log_error


class AuthManager:
    """QQ开放平台认证管理器"""

    def __init__(self):
        # 用户会话存储 {user_id: session_data}
        self.sessions = {}
        # 会话有效期（24小时）
        self.session_timeout = 24 * 60 * 60

    def get_login_qr(self) -> Dict:
        """获取登录二维码"""
        try:
            url = "https://q.qq.com/qrcode/create"
            headers = {
                "Content-Type": "application/json"
            }
            data = {"type": "777"}

            response = requests.post(url, headers=headers, json=data, timeout=10)

            if response.status_code == 200:
                result = response.json()

                if result.get('code') == 0 and 'data' in result:
                    qr_code = result['data'].get('QrCode')

                    if qr_code:
                        login_url = f"https://q.qq.com/login/applist?client=qq&code={qr_code}&ticket=null"
                        return {
                            'status': 'success',
                            'qrcode': qr_code,
                            'url': login_url
                        }

                return {
                    'status': 'error',
                    'message': '获取二维码失败'
                }
            else:
                return {
                    'status': 'error',
                    'message': f'请求失败，状态码: {response.status_code}'
                }

        except requests.RequestException as e:
            log_error(0, f"获取登录二维码失败: {e}", "QQDEV_LOGIN_QR_ERROR")
            return {
                'status': 'error',
                'message': '网络请求失败'
            }
        except Exception as e:
            log_error(0, f"获取登录二维码异常: {e}", "QQDEV_LOGIN_QR_EXCEPTION")
            return {
                'status': 'error',
                'message': '未知错误'
            }

    def verify_auth(self, user_id: str, uin: str, uid: str, ticket: str) -> bool:
        """验证并保存用户认证信息"""
        try:
            # 验证认证信息的有效性
            if not all([uin, uid, ticket]):
                return False

            # 构建Cookie字符串
            cookie_string = f"quin={uin}; quid={uid}; qticket={ticket}"

            # 保存会话信息
            session_data = {
                'uin': uin,
                'uid': uid,
                'ticket': ticket,
                'cookie': cookie_string,  # 添加完整的cookie字符串
                'login_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'expires_at': (datetime.now() + timedelta(seconds=self.session_timeout)).strftime('%Y-%m-%d %H:%M:%S'),
                'created_timestamp': time.time()
            }

            self.sessions[user_id] = session_data

            log_info(0, f"用户 {user_id} 登录成功", "QQDEV_LOGIN_SUCCESS")
            return True

        except Exception as e:
            log_error(0, f"验证认证信息失败: {e}", "QQDEV_VERIFY_AUTH_ERROR")
            return False

    def is_authenticated(self, user_id: str) -> bool:
        """检查用户是否已认证且会话有效"""
        if user_id not in self.sessions:
            return False

        session = self.sessions[user_id]
        current_time = time.time()
        session_age = current_time - session.get('created_timestamp', 0)

        # 检查会话是否过期
        if session_age > self.session_timeout:
            # 会话过期，删除
            del self.sessions[user_id]
            return False

        return True

    def get_session_info(self, user_id: str) -> Optional[Dict]:
        """获取用户会话信息"""
        if not self.is_authenticated(user_id):
            return None

        return self.sessions.get(user_id)

    def logout(self, user_id: str) -> bool:
        """用户登出"""
        if user_id in self.sessions:
            del self.sessions[user_id]
            log_info(0, f"用户 {user_id} 已登出", "QQDEV_LOGOUT")
            return True
        return False

    def cleanup_expired_sessions(self):
        """清理过期会话"""
        current_time = time.time()
        expired_users = []

        for user_id, session in self.sessions.items():
            if current_time - session.get('created_timestamp', 0) > self.session_timeout:
                expired_users.append(user_id)

        for user_id in expired_users:
            del self.sessions[user_id]
            log_info(0, f"清理过期会话: {user_id}", "QQDEV_SESSION_CLEANUP")

        return len(expired_users)

    def get_auth_headers(self, user_id: str) -> Optional[Dict]:
        """获取用户的认证请求头"""
        session = self.get_session_info(user_id)
        if not session:
            return None

        return {
            "Content-Type": "application/json",
            "Cookie": f"quin={session['uin']}; quid={session['uid']}; qticket={session['ticket']}"
        }

    def manual_login(self, user_id: str, uin: str, uid: str, ticket: str) -> Dict:
        """手动登录（用于测试或特殊情况）"""
        try:
            if self.verify_auth(user_id, uin, uid, ticket):
                return {
                    'status': 'success',
                    'message': '登录成功'
                }
            else:
                return {
                    'status': 'error',
                    'message': '认证信息无效'
                }
        except Exception as e:
            log_error(0, f"手动登录失败: {e}", "QQDEV_MANUAL_LOGIN_ERROR")
            return {
                'status': 'error',
                'message': '登录失败'
            }

    def get_session_count(self) -> int:
        """获取当前活跃会话数量"""
        # 先清理过期会话
        self.cleanup_expired_sessions()
        return len(self.sessions)

    def get_all_sessions(self) -> Dict:
        """获取所有活跃会话信息（管理用）"""
        self.cleanup_expired_sessions()
        return {
            user_id: {
                'uin': session.get('uin'),
                'login_time': session.get('login_time'),
                'expires_at': session.get('expires_at')
            }
            for user_id, session in self.sessions.items()
        }

    def check_qr_login_status(self, qr_code: str) -> Dict:
        """检查二维码登录状态 - 使用PHP robot.php的方式"""
        try:
            # 使用PHP robot.php中相同的API
            check_url = "https://q.qq.com/qrcode/get"

            # POST数据
            data = {
                "qrcode": qr_code
            }

            # 使用PHP中相同的请求头
            headers = {
                "Host": "q.qq.com",
                "Connection": "keep-alive",
                "Cache-Control": "max-age=0",
                "User-Agent": "Mozilla/5.0 (Linux; U; Android 14; zh-cn; 22122RK93C Build/UP1A.231005.007) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/109.0.5414.118 Mobile Safari/537.36 XiaoMi/MiuiBrowser/17.8.220115 swan-mibrowser",
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Origin": "https://q.qq.com",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Dest": "empty",
                "Referer": "https://q.qq.com/",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7"
            }

            response = requests.post(check_url, json=data, headers=headers, timeout=10)

            if response.status_code == 200:
                try:
                    result = response.json()

                    # 检查返回结果
                    code = result.get('code')
                    data_obj = result.get('data', {})

                    # 检查data中的具体信息
                    inner_data = data_obj.get('data', {})
                    wait_status = data_obj.get('wait')
                    time_left = data_obj.get('time')
                    start_time = data_obj.get('start')

                    # 重新判断状态
                    if inner_data and len(inner_data) > 0:  # 有登录数据
                        # 提取认证信息
                        uin = inner_data.get('uin')
                        ticket = inner_data.get('ticket')
                        developer_id = inner_data.get('developerId')

                        if uin and ticket and developer_id:
                            return {
                                'status': 'success',
                                'uin': str(uin),
                                'uid': str(developer_id),
                                'ticket': str(ticket)
                            }

                    # 检查是否真的过期（根据时间判断）
                    if start_time and time_left:
                        import time as time_module
                        current_time = time_module.time()
                        elapsed = current_time - start_time

                        if elapsed > time_left:
                            return {
                                'status': 'expired',
                                'message': '二维码已过期'
                            }

                    # 根据wait状态判断
                    if wait_status == 1:
                        return {
                            'status': 'waiting',
                            'message': '等待用户扫码'
                        }
                    else:
                        return {
                            'status': 'waiting',
                            'message': '等待用户扫码'
                        }

                except json.JSONDecodeError as e:
                    return {
                        'status': 'waiting',
                        'message': '等待用户扫码'
                    }
            else:
                return {
                    'status': 'error',
                    'message': f'HTTP请求失败，状态码: {response.status_code}'
                }

        except requests.RequestException as e:
            return {
                'status': 'error',
                'message': '网络请求失败'
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': '未知错误'
            }
