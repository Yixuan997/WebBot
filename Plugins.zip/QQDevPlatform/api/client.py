#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
QQ开放平台API客户端
封装QQ开放平台的各种API调用
"""

import json
from typing import Dict, List, Optional

import requests

from Core.logging.file_logger import log_error


class QQDevAPIClient:
    """QQ开放平台API客户端"""

    def __init__(self, session_data: Dict):
        """
        初始化API客户端

        Args:
            session_data: 用户会话数据，包含uin, uid, ticket
        """

        self.session = session_data
        self.base_headers = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Content-Type": "application/json",
            "Cookie": f"quin={session_data['uin']}; quid={session_data['uid']}; qticket={session_data['ticket']}; developerId={session_data['uid']}",
            "Host": "q.qq.com",
            "Origin": "https://q.qq.com",
            "Referer": "https://q.qq.com/",
            "Sec-CH-UA": '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
            "Sec-CH-UA-Mobile": "?0",
            "Sec-CH-UA-Platform": '"Windows"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0"
        }
        self.timeout = 10

    def _make_request(self, method: str, url: str, data: Optional[Dict] = None, params: Optional[Dict] = None,
                      headers: Optional[Dict] = None) -> Dict:
        """
        发起HTTP请求的通用方法

        Args:
            method: HTTP方法 (GET, POST)
            url: 请求URL
            data: POST请求的数据
            params: URL参数

        Returns:
            包含success, data, message的字典
        """
        try:
            # 使用自定义headers或默认headers
            request_headers = headers if headers else self.base_headers
            if method.upper() == 'GET':
                response = requests.get(
                    url,
                    headers=request_headers,
                    params=params,
                    timeout=self.timeout
                )
            elif method.upper() == 'POST':
                response = requests.post(
                    url,
                    headers=request_headers,
                    json=data,
                    params=params,
                    timeout=self.timeout
                )
            else:
                return {
                    'success': False,
                    'message': f'不支持的HTTP方法: {method}'
                }

            # 直接使用响应文本（requests会自动处理压缩）
            content = response.text

            if response.status_code == 200:
                try:
                    result = json.loads(content)
                    return {
                        'success': True,
                        'data': result
                    }
                except json.JSONDecodeError as e:
                    return {
                        'success': False,
                        'message': '响应数据格式错误'
                    }
            else:
                return {
                    'success': False,
                    'message': f'请求失败，状态码: {response.status_code}'
                }

        except requests.RequestException as e:
            log_error(0, f"API请求失败: {e}", "QQDEV_API_REQUEST_ERROR")
            return {
                'success': False,
                'message': '网络请求失败'
            }
        except Exception as e:
            log_error(0, f"API请求异常: {e}", "QQDEV_API_REQUEST_EXCEPTION")
            return {
                'success': False,
                'message': '未知错误'
            }

    def get_bot_info(self, appid: str) -> Dict:
        """
        获取机器人信息

        Args:
            appid: 机器人AppID

        Returns:
            机器人信息
        """
        url = f"https://bot.q.qq.com/cgi-bin/info/query?bot_appid={appid}"
        result = self._make_request('GET', url)
        return result

    def get_message_templates(self, appid: str, start: int = 0, limit: int = 30) -> Dict:
        """
        获取消息模板列表
        
        Args:
            appid: 机器人AppID
            start: 起始位置
            limit: 限制数量
            
        Returns:
            消息模板列表
        """
        url = "https://bot.q.qq.com/cgi-bin/msg_tpl/list"
        data = {
            "bot_appid": appid,
            "start": start,
            "limit": limit
        }
        return self._make_request('POST', url, data)

    def delete_message_template(self, appid: str, template_ids: List[str], qrcode: str) -> Dict:
        """
        删除消息模板
        
        Args:
            appid: 机器人AppID
            template_ids: 模板ID列表
            qrcode: 操作验证码
            
        Returns:
            删除结果
        """
        url = "https://bot.q.qq.com/cgi-bin/msg_tpl/delete"
        data = {
            "bot_appid": appid,
            "tpl_id": template_ids,
            "qrcode": qrcode
        }
        return self._make_request('POST', url, data)

    def get_member_list(self, appid: str, app_type: int = 2) -> Dict:
        """
        获取成员列表
        
        Args:
            appid: 机器人AppID
            app_type: 应用类型
            
        Returns:
            成员列表
        """
        url = "https://q.qq.com/pb/GetMemberList"
        data = {
            "appType": app_type,
            "appid": appid
        }
        return self._make_request('POST', url, data)

    def get_ark_urls(self, appid: str) -> Dict:
        """
        获取ARK链接配置
        
        Args:
            appid: 机器人AppID
            
        Returns:
            ARK链接信息
        """
        url = f"https://bot.q.qq.com/cgi-bin/ark_url/query?bot_appid={appid}"
        return self._make_request('GET', url)

    def get_app_list(self) -> Dict:
        """获取应用列表"""
        url = "https://q.qq.com/homepagepb/GetAppListForLogin"
        data = {
            "uin": self.session.get('uin'),
            "developer_id": self.session.get('uid'),
            "ticket": self.session.get('ticket'),
            "app_type": [2]  # 添加app_type参数，2表示QQ机器人
        }
        result = self._make_request('POST', url, data)
        return result

    def get_dau_data(self, bot_appid: str) -> Dict:
        """获取DAU数据"""

        # 构建请求URL
        url = "https://bot.q.qq.com/cgi-bin/datareport/read"
        params = {
            "bot_appid": bot_appid,
            "data_type": "1",
            "data_range": "0",
            "scene_id": "1"
        }

        # 修改请求头，使用bot.q.qq.com域名
        headers = self.base_headers.copy()
        headers.update({
            "Host": "bot.q.qq.com",
            "Referer": "https://q.qq.com/",
            "Origin": "https://q.qq.com"
        })

        result = self._make_request('GET', url, params=params, headers=headers)
        return result

    def get_notifications(self) -> Dict:
        """获取通知消息"""

        # 构建请求URL
        url = "https://q.qq.com/pb/AppFetchPrivateMsg"

        # 构建请求数据
        data = {
            "page_num": 0,
            "page_size": 10,
            "receiver": self.session.get('uid'),  # 开发者ID
            "appType": 2  # 应用类型：2表示机器人
        }

        # 修改请求头，使用q.qq.com域名
        headers = self.base_headers.copy()
        headers.update({
            "Referer": "https://q.qq.com/qqbot/"
        })

        result = self._make_request('POST', url, data=data, headers=headers)
        return result

    def get_message_templates(self, bot_appid: str) -> Dict:
        """获取消息模板列表"""

        # 构建请求URL
        url = "https://bot.q.qq.com/cgi-bin/msg_tpl/list"

        # 构建请求数据
        data = {
            "bot_appid": int(bot_appid),
            "start": 0,
            "limit": 30
        }

        # 修改请求头，使用bot.q.qq.com域名
        headers = self.base_headers.copy()
        headers.update({
            "Host": "bot.q.qq.com",
            "Referer": "https://q.qq.com/",
            "Origin": "https://q.qq.com"
        })

        result = self._make_request('POST', url, data=data, headers=headers)
        return result

    def get_robot_share_info(self, robot_uin: str) -> Dict:
        """获取机器人分享信息"""

        # 构建请求URL
        url = f"https://qun.qq.com/qunng/http2rpc/gotrpc/noauth/trpc.group_pro_robot.manager.TrpcHandler/GetShareInfo"

        # 构建请求参数
        params = {
            "robot_uin": robot_uin
        }

        # 修改请求头，使用qun.qq.com域名
        headers = self.base_headers.copy()
        headers.update({
            "Host": "qun.qq.com",
            "Referer": "https://qun.qq.com/",
            "Origin": "https://qun.qq.com"
        })

        result = self._make_request('GET', url, params=params, headers=headers)
        return result

    def get_bot_info_by_appid(self, bot_appid: str) -> Dict:
        """通过AppID获取机器人基本信息"""

        # 构建请求URL
        url = "https://bot.q.qq.com/cgi-bin/info/query"

        # 构建请求参数
        params = {
            "bot_appid": bot_appid
        }

        # 修改请求头，使用bot.q.qq.com域名
        headers = self.base_headers.copy()
        headers.update({
            "Host": "bot.q.qq.com",
            "Referer": "https://q.qq.com/",
            "Origin": "https://q.qq.com"
        })

        result = self._make_request('GET', url, params=params, headers=headers)
        return result
