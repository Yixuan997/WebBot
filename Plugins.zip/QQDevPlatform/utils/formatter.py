#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
QQ开放平台数据格式化工具
用于格式化API返回的数据，生成用户友好的显示内容
"""

from datetime import datetime
from typing import Dict, List


class DevPlatformFormatter:
    """QQ开放平台数据格式化器"""

    def format_bot_info(self, bot_data: Dict) -> str:
        """
        格式化机器人信息

        Args:
            bot_data: API返回的机器人数据

        Returns:
            格式化后的文本
        """
        try:
            if bot_data.get('retcode') != 0:
                error_msg = f"❌ 查询失败：{bot_data.get('msg', '未知错误')}"
                return error_msg

            data = bot_data.get('data', {})
            bot_info = data.get('bot_info', {})

            # 基本信息
            name = bot_info.get('bot_name', 'N/A')
            appid = bot_info.get('bot_appid', 'N/A')
            avatar = bot_info.get('bot_avatar', '')

            # 状态信息
            status_map = {
                0: "❌ 未上线",
                1: "✅ 已上线",
                2: "⚠️ 审核中",
                3: "❌ 审核失败",
                4: "⏸️ 已下线"
            }
            bot_status_code = bot_info.get('bot_status', 0)
            status = status_map.get(bot_status_code, "❓ 未知状态")

            # 权限信息
            permissions = bot_info.get('bot_scope', [])
            perm_text = "、".join(permissions) if permissions else "无特殊权限"

            # 创建时间
            create_time = bot_info.get('create_time', '')
            if create_time:
                try:
                    # 假设时间戳是秒级
                    if isinstance(create_time, (int, float)):
                        create_time = datetime.fromtimestamp(create_time).strftime('%Y-%m-%d %H:%M:%S')
                except Exception as e:
                    pass

            result = f"""🤖 机器人信息

📋 基本信息：
• 名称：{name}
• AppID：{appid}
• 状态：{status}
• 创建时间：{create_time or 'N/A'}

🔐 权限范围：
{perm_text}

📊 统计信息：
• 服务器数：{bot_info.get('guild_count', 'N/A')}
• 用户数：{bot_info.get('user_count', 'N/A')}"""

            return result

        except Exception as e:
            error_msg = f"❌ 格式化机器人信息失败：{str(e)}"
            return error_msg

    def format_templates(self, templates_data: Dict) -> str:
        """
        格式化消息模板信息
        
        Args:
            templates_data: API返回的模板数据
            
        Returns:
            格式化后的文本
        """
        try:
            if templates_data.get('retcode') != 0:
                return f"❌ 查询失败：{templates_data.get('msg', '未知错误')}"

            data = templates_data.get('data', {})
            templates = data.get('templates', [])
            total = data.get('total', 0)

            if not templates:
                return "📨 消息模板管理\n\n❌ 暂无消息模板"

            template_list = []
            for i, template in enumerate(templates, 1):
                tpl_id = template.get('tpl_id', 'N/A')
                tpl_name = template.get('tpl_name', 'N/A')
                tpl_type = template.get('tpl_type', 'N/A')
                status_map = {
                    0: "❌ 审核失败",
                    1: "✅ 审核通过",
                    2: "⏳ 审核中"
                }
                status = status_map.get(template.get('audit_status', 0), "❓ 未知")

                template_list.append(f"{i}. {tpl_name}\n   ID: {tpl_id} | 类型: {tpl_type} | 状态: {status}")

            result = f"""📨 消息模板管理

📊 模板列表（共{total}个）：
""" + "\n\n".join(template_list) + """

💡 操作说明：
• 使用 '开放平台 删除模板 [AppID] [模板ID]' 删除模板
• 删除操作需要二维码验证
• 审核通过的模板才能正常使用"""

            return result

        except Exception as e:
            return f"❌ 格式化模板信息失败：{str(e)}"

    def format_member_list(self, members_data: Dict) -> str:
        """
        格式化成员列表信息
        
        Args:
            members_data: API返回的成员数据
            
        Returns:
            格式化后的文本
        """
        try:
            if members_data.get('retcode') != 0:
                return f"❌ 查询失败：{members_data.get('msg', '未知错误')}"

            data = members_data.get('data', {})
            members = data.get('members', [])

            if not members:
                return "👥 成员管理\n\n❌ 暂无成员信息"

            member_list = []
            for member in members:
                nickname = member.get('nickname', 'N/A')
                role = member.get('role', 'N/A')
                status = member.get('status', 'N/A')
                member_list.append(f"• {nickname} ({role}) - {status}")

            result = f"""👥 成员管理

📊 成员列表（共{len(members)}人）：
""" + "\n".join(member_list) + """

💡 说明：
• 显示有权限管理此机器人的成员
• 不同角色拥有不同的管理权限"""

            return result

        except Exception as e:
            return f"❌ 格式化成员信息失败：{str(e)}"

    def format_login_success_html(self, uin: str, apps: List[Dict], login_time: str) -> str:
        """
        生成登录成功的HTML页面

        Args:
            uin: QQ号
            apps: 应用列表（最多显示5个）
            login_time: 登录时间

        Returns:
            HTML字符串
        """
        # 限制最多显示5个应用
        display_apps = apps[:5] if apps else []

        # 构建应用卡片HTML
        app_cards_html = ""
        for i, app in enumerate(display_apps, 1):
            app_name = app.get('app_name', '未知应用')
            app_id = app.get('app_id', '未知')
            app_desc = app.get('app_desc', '暂无描述')
            icon_url = app.get('icon_url', '')

            # 如果描述太长，截断
            if len(app_desc) > 50:
                app_desc = app_desc[:47] + "..."

            app_cards_html += f"""
            <div class="app-card">
                <div class="app-icon">
                    <img src="{icon_url}" alt="{app_name}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iOCIgZmlsbD0iIzM0OTVGRiIvPgo8dGV4dCB4PSIyMCIgeT0iMjYiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj7wn6SWPC90ZXh0Pgo8L3N2Zz4K'">
                </div>
                <div class="app-info">
                    <div class="app-name">{app_name}</div>
                    <div class="app-id">AppID: {app_id}</div>
                    <div class="app-desc">{app_desc}</div>
                </div>
                <div class="app-number">{i}</div>
            </div>
            """

        # 如果没有应用
        if not display_apps:
            app_cards_html = """
            <div class="no-apps">
                <div class="no-apps-icon">🤖</div>
                <div class="no-apps-text">暂无机器人应用</div>
            </div>
            """

        # 如果有超过5个应用，显示提示
        more_apps_html = ""
        if len(apps) > 5:
            more_count = len(apps) - 5
            more_apps_html = f"""
            <div class="more-apps">
                <div class="more-apps-text">还有 {more_count} 个应用未显示</div>
            </div>
            """

        html_content = f"""
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>QQ开放平台登录成功</title>
            <style>
                * {{
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }}

                body {{
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }}

                .container {{
                    background: white;
                    border-radius: 16px;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                    padding: 30px;
                    max-width: 500px;
                    width: 100%;
                }}

                .header {{
                    text-align: center;
                    margin-bottom: 25px;
                }}

                .success-icon {{
                    font-size: 48px;
                    margin-bottom: 10px;
                }}

                .title {{
                    font-size: 24px;
                    font-weight: bold;
                    color: #2c3e50;
                    margin-bottom: 8px;
                }}

                .subtitle {{
                    color: #7f8c8d;
                    font-size: 14px;
                }}

                .info-section {{
                    background: #f8f9fa;
                    border-radius: 12px;
                    padding: 20px;
                    margin-bottom: 25px;
                }}

                .info-row {{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 12px;
                }}

                .info-row:last-child {{
                    margin-bottom: 0;
                }}

                .info-label {{
                    color: #7f8c8d;
                    font-size: 14px;
                }}

                .info-value {{
                    color: #2c3e50;
                    font-weight: 500;
                    font-size: 14px;
                }}

                .apps-section {{
                    margin-bottom: 20px;
                }}

                .apps-title {{
                    font-size: 18px;
                    font-weight: bold;
                    color: #2c3e50;
                    margin-bottom: 15px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }}

                .apps-count {{
                    background: #3498db;
                    color: white;
                    font-size: 12px;
                    padding: 2px 8px;
                    border-radius: 12px;
                    font-weight: normal;
                }}

                .app-card {{
                    background: #f8f9fa;
                    border-radius: 12px;
                    padding: 15px;
                    margin-bottom: 12px;
                    display: flex;
                    align-items: center;
                    gap: 15px;
                    position: relative;
                    border: 2px solid transparent;
                    transition: all 0.3s ease;
                }}

                .app-card:hover {{
                    border-color: #3498db;
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.15);
                }}

                .app-icon {{
                    width: 50px;
                    height: 50px;
                    border-radius: 12px;
                    overflow: hidden;
                    flex-shrink: 0;
                    background: #ecf0f1;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }}

                .app-icon img {{
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                }}

                .app-info {{
                    flex: 1;
                    min-width: 0;
                }}

                .app-name {{
                    font-size: 16px;
                    font-weight: bold;
                    color: #2c3e50;
                    margin-bottom: 4px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }}

                .app-id {{
                    font-size: 12px;
                    color: #7f8c8d;
                    margin-bottom: 4px;
                    font-family: 'Courier New', monospace;
                }}

                .app-desc {{
                    font-size: 13px;
                    color: #95a5a6;
                    line-height: 1.4;
                }}

                .app-number {{
                    position: absolute;
                    top: -8px;
                    right: -8px;
                    background: #3498db;
                    color: white;
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 12px;
                    font-weight: bold;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }}

                .no-apps {{
                    text-align: center;
                    padding: 40px 20px;
                    color: #95a5a6;
                }}

                .no-apps-icon {{
                    font-size: 48px;
                    margin-bottom: 10px;
                }}

                .no-apps-text {{
                    font-size: 16px;
                }}

                .more-apps {{
                    text-align: center;
                    padding: 15px;
                    background: #e8f4fd;
                    border-radius: 8px;
                    margin-top: 10px;
                }}

                .more-apps-text {{
                    color: #3498db;
                    font-size: 14px;
                    font-weight: 500;
                }}

                .footer {{
                    text-align: center;
                    color: #95a5a6;
                    font-size: 13px;
                    margin-top: 20px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="success-icon">✅</div>
                    <div class="title">登录成功</div>
                    <div class="subtitle">QQ开放平台</div>
                </div>

                <div class="info-section">
                    <div class="info-row">
                        <span class="info-label">QQ号</span>
                        <span class="info-value">{uin}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">登录时间</span>
                        <span class="info-value">{login_time}</span>
                    </div>
                </div>

                <div class="apps-section">
                    <div class="apps-title">
                        机器人应用
                        <span class="apps-count">{len(display_apps)}</span>
                    </div>
                    {app_cards_html}
                    {more_apps_html}
                </div>

                <div class="footer">
                    输入 '开放平台 状态' 查看详细信息
                </div>
            </div>
        </body>
        </html>
        """

        return html_content
