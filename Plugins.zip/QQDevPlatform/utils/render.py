"""
QQ开放平台插件渲染系统
"""

from Core.message.builder import MessageBuilder
from Core.tools.browser import browser


class RenderSystem:
    """渲染系统 - 简单封装"""

    def __init__(self):
        """初始化渲染系统"""
        pass  # 不需要任何初始化

    async def render_to_image(self, template_name: str, data: dict, width: int = None) -> str:
        """
        渲染模板为图片

        Args:
            template_name: 模板文件名（如 'login_success.html'）
            data: 模板数据
            width: 图片宽度，None为自适应

        Returns:
            纯base64图片数据（不包含data:image/png;base64,前缀）
        """
        # 构建模板路径：QQDevPlatform/templates/xxx.html
        template_path = f'QQDevPlatform/templates/{template_name}'

        # 直接使用系统级浏览器管理器
        return browser.render(template_path, data, width)

    def render_to_message(self, template_name: str, data: dict, caption: str = "", width: int = None) -> dict:
        """
        渲染模板为消息对象

        Args:
            template_name: 模板文件名
            data: 模板数据
            caption: 图片说明
            width: 图片宽度

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        try:
            # 构建模板路径
            template_path = f'QQDevPlatform/templates/{template_name}'

            # 使用浏览器渲染
            image_base64 = browser.render(template_path, data, width or 600)

            if image_base64:
                # 返回MessageBuilder图片消息
                return MessageBuilder.image(caption=caption, base64_data=image_base64)
            else:
                return None

        except Exception as e:
            return None

    def render_login_success(self, uin: str, apps: list, login_time: str) -> dict:
        """
        渲染登录成功图片

        Args:
            uin: QQ号
            apps: 应用列表
            login_time: 登录时间

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        template_data = {
            'uin': uin,
            'login_time': login_time,
            'apps': apps[:5],  # 最多显示5个应用
            'total_apps': len(apps),
            'has_more': len(apps) > 5
        }

        return self.render_to_message(
            'login_success.html',
            template_data,
            caption="QQ开放平台登录成功",
            width=600
        )

    def render_logout_success(self, uin: str) -> dict:
        """
        渲染退出登录成功图片

        Args:
            uin: QQ号

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        template_data = {
            'uin': uin,
            'logout_time': __import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        return self.render_to_message(
            'logout_success.html',
            template_data,
            caption="QQ开放平台退出登录",
            width=600
        )

    def render_bot_info(self, bot_data: dict) -> dict:
        """
        渲染机器人信息图片

        Args:
            bot_data: 机器人数据

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        return self.render_to_message(
            'bot_info.html',
            bot_data,
            caption="机器人信息",
            width=600
        )

    def render_whitelist(self, whitelist_data: dict) -> dict:
        """
        渲染IP白名单图片

        Args:
            whitelist_data: 白名单数据

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        return self.render_to_message(
            'whitelist.html',
            whitelist_data,
            caption="IP白名单",
            width=600
        )

    def render_events(self, events_data: dict) -> dict:
        """
        渲染事件订阅图片

        Args:
            events_data: 事件数据

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        return self.render_to_message(
            'events.html',
            events_data,
            caption="事件订阅",
            width=600
        )

    def render_templates(self, templates_data: dict) -> dict:
        """
        渲染消息模板图片

        Args:
            templates_data: 模板数据

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        return self.render_to_message(
            'templates.html',
            templates_data,
            caption="消息模板",
            width=600
        )

    def render_dau_data(self, dau_data: dict, app_name: str, app_id: str) -> dict:
        """
        渲染DAU数据图片

        Args:
            dau_data: DAU数据
            app_name: 应用名称
            app_id: 应用ID

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        # DAU API返回的数据结构: {"retcode": 0, "data": {"msg_data": [...]}}
        actual_data = dau_data.get('data', {}) if 'data' in dau_data else dau_data
        msg_data = actual_data.get('msg_data', [])[:7]  # 最多显示7天数据

        template_data = {
            'app_name': app_name,
            'app_id': app_id,
            'dau_data': actual_data,
            'msg_data': msg_data
        }

        return self.render_to_message(
            'dau_data.html',
            template_data,
            caption=f"{app_name} DAU数据",
            width=800
        )

    def render_notifications(self, notifications: list, total_count: int) -> dict:
        """
        渲染通知列表图片

        Args:
            notifications: 通知列表
            total_count: 总通知数

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        # 格式化所有通知的时间
        notifications_with_time = []
        for notification in notifications:
            notification_copy = notification.copy()
            send_time = notification.get('send_time', '')
            if send_time:
                try:
                    from datetime import datetime
                    formatted_time = datetime.fromtimestamp(int(send_time)).strftime('%Y-%m-%d %H:%M:%S')
                except:
                    formatted_time = send_time
            else:
                formatted_time = '未知时间'

            notification_copy['formatted_time'] = formatted_time
            notifications_with_time.append(notification_copy)

        template_data = {
            'notifications': notifications_with_time,
            'total_count': total_count
        }

        return self.render_to_message(
            'notification.html',
            template_data,
            caption=f"QQ开放平台通知 ({len(notifications)}条)",
            width=900
        )

    def render_message_templates(self, template_data: dict, app_name: str, app_id: str) -> dict:
        """
        渲染消息模板图片

        Args:
            template_data: 模板数据
            app_name: 应用名称
            app_id: 应用ID

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        # 处理嵌套的数据结构：template_data可能包含retcode/msg/data
        actual_data = template_data
        if 'data' in template_data and isinstance(template_data['data'], dict):
            actual_data = template_data['data']

        templates = actual_data.get('list', [])
        max_count = actual_data.get('max_msg_tpl_count', 10)

        template_render_data = {
            'app_name': app_name,
            'app_id': app_id,
            'templates': templates,
            'template_count': len(templates),
            'max_count': max_count
        }

        return self.render_to_message(
            'message_templates.html',
            template_render_data,
            caption=f"{app_name} 消息模板",
            width=800
        )

    def render_bot_info(self, bot_data: dict, app_name: str, app_id: str) -> dict:
        """
        渲染机器人信息图片

        Args:
            bot_data: 机器人数据
            app_name: 应用名称
            app_id: 应用ID

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        # 处理嵌套的数据结构
        actual_bot_data = bot_data
        if 'data' in bot_data and isinstance(bot_data['data'], dict):
            if 'data' in bot_data['data']:
                actual_bot_data = bot_data['data']['data']
            else:
                actual_bot_data = bot_data['data']

        # 检查是否有有效数据（修复检查逻辑）
        if not actual_bot_data:
            return None

        # 检查是否有retcode字段，如果有则检查是否为0
        if 'retcode' in actual_bot_data and actual_bot_data.get('retcode') != 0:
            return None

        template_data = {
            'app_name': app_name,
            'app_id': app_id,
            'bot_data': actual_bot_data
        }

        return self.render_to_message(
            'bot_info.html',
            template_data,
            caption=f"{app_name} 机器人信息",
            width=700
        )

    def render_main_menu(self) -> dict:
        """
        渲染主菜单图片

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        template_data = {
            'title': 'QQ开放平台管理工具',
            'subtitle': '便捷管理您的QQ机器人应用'
        }

        return self.render_to_message(
            'main_menu.html',
            template_data,
            caption="QQ开放平台管理工具",
            width=800
        )
