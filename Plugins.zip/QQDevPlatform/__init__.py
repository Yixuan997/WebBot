#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
QQ开放平台管理插件
提供QQ机器人开放平台的便捷管理功能
"""

import time
from datetime import datetime
from typing import List

from Core.logging.file_logger import log_error
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin

# 延迟导入，避免初始化时的导入错误
from .api.client import QQDevAPIClient
from .auth.manager import AuthManager
from .utils.formatter import DevPlatformFormatter


class Plugin(BasePlugin):
    """QQ开放平台管理插件"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "QQDevPlatform"
        self.version = "1.0.0"
        self.description = "QQ开放平台管理工具，支持机器人信息查询、白名单管理等功能"
        self.author = "Yixuan"

        # 注册命令信息
        self.register_command_info('开放平台', 'QQ开放平台管理', '开放平台 [操作]')

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.handle_message_hook]
        }

        # 初始化管理器
        try:
            if AuthManager is not None:
                self.auth_manager = AuthManager()
            else:
                self.auth_manager = None
        except Exception as e:
            self.auth_manager = None

        try:
            if DevPlatformFormatter is not None:
                self.formatter = DevPlatformFormatter()
            else:
                self.formatter = None
        except Exception as e:
            self.formatter = None

        # 初始化渲染系统
        try:
            from .utils.render import RenderSystem
            self.render_system = RenderSystem()
        except Exception as e:
            self.render_system = None

        # 权限设置
        self.admin_only = False  # 临时改为False进行测试

    def handle_message_hook(self, message_data, user_id, bot_id):
        """处理消息Hook"""
        content = message_data.get('content', '').strip()

        # 检查是否是开放平台命令
        if content.startswith('开放平台'):
            result = self.handle_message(bot_id, message_data)

            if result is not None:
                # 如果result已经是Hook格式，直接返回
                if isinstance(result, dict) and 'handled' in result:
                    return result
                # 否则包装成Hook格式
                return {
                    'handled': True,
                    'response': result
                }

        return {'handled': False}

    def handle_message(self, bot_id: str, message_data: dict) -> dict:
        """处理消息"""
        try:
            content = message_data.get('content', '').strip()
            user_id = message_data.get('author', {}).get('id', '')

            # 检查是否是开放平台命令
            if not content.startswith('开放平台'):
                return {'handled': False}

            # 解析命令
            parts = content.split()

            if len(parts) == 1:
                # 显示主菜单
                return self._show_main_menu()

            command = parts[1]
            args = parts[2:] if len(parts) > 2 else []

            # 路由命令
            if command == '登录':
                return self._handle_login(bot_id, user_id, message_data)
            elif command == '退出':
                return self._handle_logout(bot_id, user_id)
            elif command == '状态':
                return self._handle_status(bot_id, user_id)
            elif command == '机器人':
                return self._handle_bot_info(bot_id, user_id, args)
            elif command == 'dau':
                return self._handle_dau_command(bot_id, user_id, args)
            elif command == '通知':
                return self._handle_notification_command(bot_id, user_id, args)
            elif command == '模板':
                return self._handle_template_command(bot_id, user_id, args)
            else:
                return self._show_unknown_command(command)

        except Exception as e:
            log_error(bot_id, f"QQ开放平台插件处理消息失败: {e}", "QQDEV_HANDLE_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 处理命令时发生错误，请稍后重试")
            }

    def _show_main_menu(self) -> dict:
        """显示主菜单"""
        try:
            # 使用渲染系统生成主菜单图片
            if self.render_system:
                menu_image = self.render_system.render_main_menu()

                if menu_image:
                    return {
                        'handled': True,
                        'response': menu_image
                    }
                else:
                    return {
                        'handled': True,
                        'response': MessageBuilder.text("❌ 主菜单图片生成失败")
                    }

        except Exception as e:
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 主菜单显示失败，请稍后重试")
            }

    def _handle_login(self, bot_id: str, user_id: str, message_data: dict = None) -> dict:
        """处理登录命令"""
        try:

            # 提取回复所需的信息
            if message_data:
                msg_id = message_data.get('id')
                openid = message_data.get('author', {}).get('user_openid') or message_data.get('openid')
                group_openid = message_data.get('group_openid')
                message_type = message_data.get('type', 'unknown')

            # 检查是否已登录
            is_authenticated = self.auth_manager.is_authenticated(user_id)
            if is_authenticated:

                # 获取用户的登录信息
                session_info = self.auth_manager.get_session_info(user_id)
                uin = session_info.get('uin', '未知')

                # 获取应用列表
                try:
                    from .api.client import QQDevAPIClient
                    api_client = QQDevAPIClient(session_info)
                    app_result = api_client.get_app_list()

                    apps = []
                    if app_result.get('success') and app_result.get('data'):
                        api_data = app_result['data']
                        if isinstance(api_data, dict) and 'data' in api_data:
                            apps = api_data['data'].get('apps', [])
                        elif isinstance(api_data, dict) and 'apps' in api_data:
                            apps = api_data.get('apps', [])



                except Exception as e:
                    apps = []

                # 生成登录状态图片
                login_time = session_info.get('login_time', '未知时间')

                if self.render_system:
                    status_image = self.render_system.render_login_success(uin, apps, login_time)

                    if status_image:
                        return {
                            'handled': True,
                            'response': status_image
                        }
                    else:
                        return {
                            'handled': True,
                            'response': MessageBuilder.text("❌ 登录状态图片生成失败")
                        }

                # 如果渲染系统未初始化，返回简单提示
                return {
                    'handled': True,
                    'response': MessageBuilder.text("✅ 您已经登录\n💡 输入 '开放平台 状态' 查看详细信息")
                }

            # 获取登录二维码
            qr_result = self.auth_manager.get_login_qr()
            if qr_result['status'] == 'success':

                # 记录登录请求信息，用于后续回复
                if message_data:
                    login_info = {
                        'user_id': user_id,
                        'bot_id': bot_id,
                        'msg_id': msg_id,
                        'openid': openid,
                        'group_openid': group_openid,
                        'message_type': message_type,
                        'qr_code': qr_result.get('qrcode'),
                        'timestamp': time.time()
                    }

                    # 存储登录信息，用于后续检测
                    if not hasattr(self, 'pending_logins'):
                        self.pending_logins = {}
                    self.pending_logins[user_id] = login_info

                # 处理URL，将.com换成大写.COM
                login_url = qr_result['url'].replace('.com', '.COM')

                # 使用text_card_link发送登录链接
                login_card = MessageBuilder.text_card_link(
                    text="🔐 QQ开放平台登录\n\n📱 点击下方按钮登录QQ开放平台，管理您的机器人\n\n⏰ 系统将在1分钟内自动检测登录状态",
                    button_text="🚀 点击登录",
                    button_url=login_url,
                    description="QQ开放平台管理工具",
                    prompt="⏰ 链接有效期：1分钟"
                )

                # 启动后台检测任务
                self._start_login_detection(user_id)

                return {
                    'handled': True,
                    'response': login_card
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"❌ 获取登录二维码失败：{qr_result.get('message', '未知错误')}")
                }

        except Exception as e:
            log_error(bot_id, f"处理登录命令失败: {e}", "QQDEV_LOGIN_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 登录失败，请稍后重试")
            }

    def _handle_logout(self, bot_id: str, user_id: str) -> dict:
        """处理退出登录命令"""
        try:
            # 检查是否已登录
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 您尚未登录，无需退出")
                }

            # 获取用户信息（在退出前）
            session_info = self.auth_manager.get_session_info(user_id)
            uin = session_info.get('uin', '未知') if session_info else '未知'

            # 执行退出登录
            logout_success = self.auth_manager.logout(user_id)

            if logout_success:
                # 清理待处理的登录信息（如果有）
                if hasattr(self, 'pending_logins') and user_id in self.pending_logins:
                    del self.pending_logins[user_id]

                # 生成退出成功图片
                if self.render_system:
                    logout_image = self.render_system.render_logout_success(uin)
                    if logout_image:
                        return {
                            'handled': True,
                            'response': logout_image
                        }

                # 如果图片生成失败，返回文本消息
                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"✅ 退出登录成功\n👤 用户：{uin}\n💡 输入 '开放平台 登录' 可重新登录")
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 退出登录失败，请稍后重试")
                }

        except Exception as e:
            log_error(bot_id, f"处理退出登录命令失败: {e}", "QQDEV_LOGOUT_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 退出登录失败，请稍后重试")
            }

    def _handle_status(self, bot_id: str, user_id: str) -> dict:
        """处理状态查询"""
        try:
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 您尚未登录\n💡 输入 '开放平台 登录' 开始登录")
                }

            session_info = self.auth_manager.get_session_info(user_id)
            status_text = f"""✅ 登录状态

👤 用户ID: {session_info.get('uin', 'N/A')}
🕐 登录时间: {session_info.get('login_time', 'N/A')}
⏰ 会话有效期: {session_info.get('expires_at', 'N/A')}

🎯 可用功能：
• 机器人信息查询
• IP白名单管理
• 事件订阅查看
• 消息模板管理"""

            return {
                'handled': True,
                'response': MessageBuilder.text(status_text)
            }

        except Exception as e:
            log_error(bot_id, f"处理状态查询失败: {e}", "QQDEV_STATUS_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 查询状态失败")
            }

    def _handle_bot_info(self, bot_id: str, user_id: str, args: List[str]) -> dict:
        """处理机器人信息查询"""
        try:

            # 检查认证状态
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 请先登录\n💡 输入 '开放平台 登录' 进行登录")
                }

            # 获取应用列表
            session_info = self.auth_manager.get_session_info(user_id)
            from .api.client import QQDevAPIClient
            api_client = QQDevAPIClient(session_info)
            app_result = api_client.get_app_list()

            if not app_result.get('success'):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取应用列表失败")
                }

            # 解析应用列表
            apps = []
            api_data = app_result['data']
            if isinstance(api_data, dict) and 'data' in api_data:
                apps = api_data['data'].get('apps', [])
            elif isinstance(api_data, dict) and 'apps' in api_data:
                apps = api_data.get('apps', [])

            if not apps:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 暂无机器人应用")
                }

            # 解析参数：机器人 [序号]
            app_index = 1  # 默认第一个应用
            if args and len(args) > 0:
                try:
                    app_index = int(args[0])
                    if app_index < 1 or app_index > min(len(apps), 5):
                        return {
                            'handled': True,
                            'response': MessageBuilder.text(f"❌ 应用序号无效，请输入1-{min(len(apps), 5)}之间的数字")
                        }
                except ValueError:
                    return {
                        'handled': True,
                        'response': MessageBuilder.text("❌ 应用序号必须是数字")
                    }

            # 获取指定应用
            selected_app = apps[app_index - 1]
            app_id = selected_app.get('app_id')
            app_name = selected_app.get('app_name')

            # 第一步：通过AppID获取机器人基本信息（包含bot_uin）
            bot_basic_info = api_client.get_bot_info_by_appid(app_id)

            if not bot_basic_info.get('success'):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取机器人基本信息失败")
                }

            # 解析bot_uin
            basic_data = bot_basic_info['data']
            if isinstance(basic_data, dict) and 'data' in basic_data:
                basic_data = basic_data['data']

            bot_infos = basic_data.get('bot_infos', [])
            if not bot_infos:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 未找到机器人信息")
                }

            # 获取bot_uin（优先使用formal_info，如果没有则使用dev_info）
            bot_info_data = bot_infos[0]
            formal_info = bot_info_data.get('formal_info', {})
            dev_info = bot_info_data.get('dev_info', {})

            bot_uin = formal_info.get('bot_uin') or dev_info.get('bot_uin')
            if not bot_uin:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 未找到机器人UIN")
                }

            # 第二步：使用bot_uin查询机器人分享信息
            bot_share_info = api_client.get_robot_share_info(bot_uin)

            if bot_share_info.get('success'):
                # 检查API是否返回了错误
                api_data = bot_share_info.get('data', {})
                if api_data.get('retcode') != 0:
                    error_msg = api_data.get('message', '未知错误')
                    return {
                        'handled': True,
                        'response': MessageBuilder.text(f"❌ 获取机器人分享信息失败: {error_msg}")
                    }
                # 使用渲染系统生成机器人信息图片
                if self.render_system:
                    bot_image = self.render_system.render_bot_info(
                        bot_share_info['data'],
                        app_name,
                        app_id
                    )

                    if bot_image:
                        return {
                            'handled': True,
                            'response': bot_image
                        }
                    else:
                        return {
                            'handled': True,
                            'response': MessageBuilder.text("❌ 机器人信息图片生成失败")
                        }

                # 如果渲染系统未初始化
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 渲染系统未初始化")
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text(
                        f"❌ 获取机器人分享信息失败: {bot_share_info.get('message', '未知错误')}")
                }

        except Exception as e:
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 机器人信息查询失败，请稍后重试")
            }

    def _show_unknown_command(self, command: str) -> dict:
        """显示未知命令提示"""
        return {
            'handled': True,
            'response': MessageBuilder.text(f"❌ 未知命令：{command}\n💡 输入 '开放平台 帮助' 查看可用命令")
        }

    def _start_login_detection(self, user_id: str):
        """启动登录检测任务"""
        try:

            if not hasattr(self, 'pending_logins') or user_id not in self.pending_logins:
                return

            login_info = self.pending_logins[user_id]

            # 使用线程进行后台检测
            import threading
            detection_thread = threading.Thread(
                target=self._login_detection_worker,
                args=(user_id, login_info),
                daemon=True
            )
            detection_thread.start()


        except Exception as e:
            pass

    def _login_detection_worker(self, user_id: str, login_info: dict):
        """登录检测工作线程"""
        try:

            qr_code = login_info.get('qr_code')
            start_time = time.time()
            timeout = 60  # 1分钟超时
            check_interval = 5  # 每5秒检查一次
            initial_delay = 5  # 首次检查前等待5秒

            # 首次等待，给用户时间点击链接
            time.sleep(initial_delay)

            while time.time() - start_time < timeout:
                try:

                    # 检查登录状态
                    check_result = self.auth_manager.check_qr_login_status(qr_code)

                    if check_result['status'] == 'success':
                        # 登录成功，保存认证信息
                        uin = check_result.get('uin')
                        uid = check_result.get('uid')
                        ticket = check_result.get('ticket')

                        if self.auth_manager.verify_auth(user_id, uin, uid, ticket):

                            # 准备登录成功消息，通过Hook系统发送
                            self._prepare_login_success_hook(user_id, login_info, uin, uid, ticket)

                            # 清除待检查的登录信息
                            if hasattr(self, 'pending_logins') and user_id in self.pending_logins:
                                del self.pending_logins[user_id]

                            return
                        else:
                            pass

                    elif check_result['status'] == 'expired':
                        break
                    elif check_result['status'] == 'waiting':
                        pass
                    else:
                        pass

                    # 等待下次检查
                    time.sleep(check_interval)

                except Exception as e:
                    time.sleep(check_interval)

            # 清除过期的登录信息
            if hasattr(self, 'pending_logins') and user_id in self.pending_logins:
                del self.pending_logins[user_id]

        except Exception as e:
            pass

    def _prepare_login_success_hook(self, user_id: str, login_info: dict, uin: str, uid: str, ticket: str):
        """发送登录成功回复（包含应用列表）"""
        try:

            bot_id = login_info.get('bot_id')
            msg_id = login_info.get('msg_id')
            group_openid = login_info.get('group_openid')
            message_type = login_info.get('message_type')

            # 获取应用列表
            session_data = {
                'uin': uin,
                'uid': uid,
                'ticket': ticket
            }

            from .api.client import QQDevAPIClient
            api_client = QQDevAPIClient(session_data)
            app_result = api_client.get_app_list()

            # 获取应用列表数据
            apps = []
            if app_result.get('success') and app_result.get('data'):
                api_data = app_result['data']

                # 检查是否有data字段且包含apps
                if isinstance(api_data, dict) and 'data' in api_data:
                    apps = api_data['data'].get('apps', [])
                elif isinstance(api_data, dict) and 'apps' in api_data:
                    apps = api_data.get('apps', [])

            else:
                apps = []

            # 使用渲染系统生成登录成功图片
            login_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            if self.render_system:
                success_image = self.render_system.render_login_success(uin, apps, login_time)

                if success_image:
                    success_message = success_image
                else:
                    success_message = MessageBuilder.text("❌ 登录成功图片生成失败，请稍后重试")
            else:
                success_message = MessageBuilder.text("❌ 渲染系统未初始化，无法生成图片")

            # 发送回复消息（有权限）
            bot_id = login_info.get('bot_id')
            group_openid = login_info.get('group_openid')
            message_type = login_info.get('message_type')
            msg_id = login_info.get('msg_id')  # 原始消息ID，用于回复

            if message_type == 'group_at' and group_openid and msg_id:
                target = f"group:{group_openid}"

                try:
                    # 在Flask应用上下文中发送消息
                    from flask import current_app
                    try:
                        app = current_app._get_current_object()
                    except RuntimeError:
                        # 如果无法获取当前应用，导入应用实例
                        from app import app

                    with app.app_context():
                        from Adapters import get_adapter_manager
                        adapter_manager = get_adapter_manager()

                        # 发送回复消息，而不是主动消息
                        success = adapter_manager.send_message(
                            bot_id,
                            target,
                            success_message,
                            reply_to_msg_id=msg_id,  # 回复原始消息
                            original_msg_id=msg_id  # 原始消息ID
                        )

                except Exception as e:
                    pass

        except Exception as e:
            pass

    def _send_group_reply(self, bot_id: int, group_openid: str, msg_id: str, message: str):
        """发送群聊回复 - 使用Yapi的方式处理Flask应用上下文"""
        try:

            # 在后台线程中需要创建Flask应用上下文
            from flask import current_app
            try:
                # 尝试获取当前应用上下文
                app = current_app._get_current_object()
            except RuntimeError:
                # 如果没有应用上下文，导入应用实例
                from app import app

            with app.app_context():
                # 获取适配器管理器
                from Adapters import get_adapter_manager
                adapter_manager = get_adapter_manager()

                if adapter_manager:
                    # 构建目标信息 - 使用SlaveMarket的格式
                    target = f"group:{group_openid}"

                    # 构建响应消息
                    response_data = MessageBuilder.text(message)

                    # 使用原始消息ID进行回复
                    success = adapter_manager.send_message(bot_id, target, response_data, reply_to_msg_id=msg_id)

        except Exception as e:
            pass

    def _send_private_reply(self, bot_id: int, openid: str, msg_id: str, message: str):
        """发送私聊回复 - 处理Flask应用上下文"""
        try:
            # 在后台线程中需要创建Flask应用上下文
            from flask import current_app
            try:
                # 尝试获取当前应用上下文
                app = current_app._get_current_object()
            except RuntimeError:
                # 如果没有应用上下文，导入应用实例
                from app import app

            with app.app_context():
                # 获取适配器管理器
                from Adapters import get_adapter_manager
                adapter_manager = get_adapter_manager()

                if adapter_manager:
                    # 构建目标信息 - 使用SlaveMarket的格式
                    target = f"user:{openid}"

                    # 构建响应消息
                    response_data = MessageBuilder.text(message)

                    # 使用原始消息ID进行回复
                    success = adapter_manager.send_message(bot_id, target, response_data, reply_to_msg_id=msg_id)

        except Exception as e:
            pass

    def _handle_dau_command(self, bot_id: int, user_id: str, args: list):
        """处理DAU数据查询命令"""
        try:

            # 检查认证状态
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 请先登录\n💡 输入 '开放平台 登录' 进行登录")
                }

            # 获取应用列表
            session_info = self.auth_manager.get_session_info(user_id)
            from .api.client import QQDevAPIClient
            api_client = QQDevAPIClient(session_info)
            app_result = api_client.get_app_list()

            if not app_result.get('success'):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取应用列表失败")
                }

            # 解析应用列表
            apps = []
            api_data = app_result['data']
            if isinstance(api_data, dict) and 'data' in api_data:
                apps = api_data['data'].get('apps', [])
            elif isinstance(api_data, dict) and 'apps' in api_data:
                apps = api_data.get('apps', [])

            if not apps:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 暂无机器人应用")
                }

            # 解析参数：dau [序号]
            app_index = 1  # 默认第一个应用
            if args and len(args) > 0:
                try:
                    app_index = int(args[0])
                    if app_index < 1 or app_index > min(len(apps), 5):
                        return {
                            'handled': True,
                            'response': MessageBuilder.text(f"❌ 应用序号无效，请输入1-{min(len(apps), 5)}之间的数字")
                        }
                except ValueError:
                    return {
                        'handled': True,
                        'response': MessageBuilder.text("❌ 应用序号必须是数字")
                    }

            # 获取指定应用
            selected_app = apps[app_index - 1]
            app_id = selected_app.get('app_id')
            app_name = selected_app.get('app_name')

            # 获取DAU数据
            dau_result = api_client.get_dau_data(app_id)

            if dau_result.get('success'):
                # 使用渲染系统生成DAU图片
                if self.render_system:
                    dau_image = self.render_system.render_dau_data(dau_result['data'], app_name, app_id)

                    if dau_image:
                        return {
                            'handled': True,
                            'response': dau_image
                        }
                    else:
                        return {
                            'handled': True,
                            'response': MessageBuilder.text("❌ DAU数据图片生成失败")
                        }

                # 如果渲染系统未初始化
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 渲染系统未初始化")
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"❌ 获取DAU数据失败: {dau_result.get('message', '未知错误')}")
                }

        except Exception as e:
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ DAU查询失败，请稍后重试")
            }

    def _format_dau_text(self, dau_data: dict, app_name: str, app_id: str) -> str:
        """格式化DAU数据为文本"""
        try:
            msg_data = dau_data.get('msg_data', [])
            if not msg_data:
                return f"📊 {app_name} (AppID: {app_id})\n❌ 暂无数据"

            result = f"📊 {app_name} DAU数据\nAppID: {app_id}\n\n"

            for i, data in enumerate(msg_data[:7]):  # 最多显示7天
                date = str(data.get('report_date', ''))
                formatted_date = f"{date[:4]}-{date[4:6]}-{date[6:8]}" if len(date) == 8 else date

                up_msg_uv = data.get('up_msg_uv', 0)
                up_msg_cnt = data.get('up_msg_cnt', 0)
                down_msg_cnt = data.get('down_msg_cnt', 0)
                bot_msg_cnt = data.get('bot_msg_cnt', 0)
                retention = data.get('next_day_retention', 0)

                result += f"📅 {formatted_date}\n"
                result += f"👥 活跃用户: {up_msg_uv}\n"
                result += f"📤 上行消息: {up_msg_cnt}\n"
                result += f"📥 下行消息: {down_msg_cnt}\n"
                result += f"💬 总消息量: {bot_msg_cnt}\n"
                result += f"📈 次日留存: {retention:.1%}\n\n"

            return result.strip()

        except Exception as e:
            return f"📊 {app_name} (AppID: {app_id})\n❌ 数据格式化失败"

    def _handle_notification_command(self, bot_id: int, user_id: str, args: list):
        """处理通知查询命令"""
        try:

            # 检查认证状态
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 请先登录\n💡 输入 '开放平台 登录' 进行登录")
                }

            # 获取通知数据
            session_info = self.auth_manager.get_session_info(user_id)
            from .api.client import QQDevAPIClient
            api_client = QQDevAPIClient(session_info)
            notification_result = api_client.get_notifications()

            if not notification_result.get('success'):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取通知失败")
                }

            # 解析通知数据
            notifications = []
            total_count = 0
            api_data = notification_result['data']
            if isinstance(api_data, dict) and 'data' in api_data:
                notifications = api_data['data'].get('privateMsgs', [])
                total_count = api_data['data'].get('total_count', len(notifications))
            elif isinstance(api_data, dict) and 'privateMsgs' in api_data:
                notifications = api_data.get('privateMsgs', [])
                total_count = api_data.get('total_count', len(notifications))

            if not notifications:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("📬 暂无通知消息")
                }

            # 使用渲染系统生成通知图片（显示所有通知）
            if self.render_system:
                notification_image = self.render_system.render_notifications(
                    notifications[:10],  # 最多显示10条
                    total_count
                )

                if notification_image:
                    return {
                        'handled': True,
                        'response': notification_image
                    }
                else:
                    return {
                        'handled': True,
                        'response': MessageBuilder.text("❌ 通知图片生成失败")
                    }

            # 如果渲染系统未初始化
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 渲染系统未初始化")
            }

        except Exception as e:
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 通知查询失败，请稍后重试")
            }

    def _format_notifications_text(self, notifications: list, total_count: int) -> str:
        """格式化通知列表为文本"""
        try:
            result = f"📬 QQ开放平台通知\n"
            result += f"共 {total_count} 条消息，显示最新 {len(notifications)} 条\n\n"

            for i, notification in enumerate(notifications, 1):
                title = notification.get('title', '无标题')
                send_time = notification.get('send_time', '')

                # 转换时间戳
                if send_time:
                    try:
                        from datetime import datetime
                        formatted_time = datetime.fromtimestamp(int(send_time)).strftime('%m-%d %H:%M')
                    except:
                        formatted_time = send_time
                else:
                    formatted_time = '未知时间'

                # 清理HTML标签
                import re
                clean_title = re.sub(r'<[^>]+>', '', title)

                # 判断状态
                if '被拒绝' in title or 'color="red"' in title:
                    status = "❌"
                elif '已通过' in title or '通过平台审核' in title:
                    status = "✅"
                else:
                    status = "📋"

                result += f"{status} {clean_title}\n"
                result += f"   🕐 {formatted_time}\n\n"

            return result.strip()

        except Exception as e:
            return f"📬 QQ开放平台通知\n❌ 通知格式化失败"

    def _handle_template_command(self, bot_id: int, user_id: str, args: list):
        """处理消息模板查询命令"""
        try:

            # 检查认证状态
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 请先登录\n💡 输入 '开放平台 登录' 进行登录")
                }

            # 获取应用列表
            session_info = self.auth_manager.get_session_info(user_id)
            from .api.client import QQDevAPIClient
            api_client = QQDevAPIClient(session_info)
            app_result = api_client.get_app_list()

            if not app_result.get('success'):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取应用列表失败")
                }

            # 解析应用列表
            apps = []
            api_data = app_result['data']
            if isinstance(api_data, dict) and 'data' in api_data:
                apps = api_data['data'].get('apps', [])
            elif isinstance(api_data, dict) and 'apps' in api_data:
                apps = api_data.get('apps', [])

            if not apps:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 暂无机器人应用")
                }

            # 解析参数：模板 [序号]
            app_index = 1  # 默认第一个应用
            if args and len(args) > 0:
                try:
                    app_index = int(args[0])
                    if app_index < 1 or app_index > min(len(apps), 5):
                        return {
                            'handled': True,
                            'response': MessageBuilder.text(f"❌ 应用序号无效，请输入1-{min(len(apps), 5)}之间的数字")
                        }
                except ValueError:
                    return {
                        'handled': True,
                        'response': MessageBuilder.text("❌ 应用序号必须是数字")
                    }

            # 获取指定应用
            selected_app = apps[app_index - 1]
            app_id = selected_app.get('app_id')
            app_name = selected_app.get('app_name')

            # 获取消息模板
            template_result = api_client.get_message_templates(app_id)

            if template_result.get('success'):
                # 使用渲染系统生成模板图片
                if self.render_system:
                    template_image = self.render_system.render_message_templates(
                        template_result['data'],
                        app_name,
                        app_id
                    )

                    if template_image:
                        return {
                            'handled': True,
                            'response': template_image
                        }
                    else:
                        return {
                            'handled': True,
                            'response': MessageBuilder.text("❌ 消息模板图片生成失败")
                        }

                # 如果渲染系统未初始化
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 渲染系统未初始化")
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"❌ 获取消息模板失败: {template_result.get('message', '未知错误')}")
                }

        except Exception as e:
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 模板查询失败，请稍后重试")
            }

    def _format_templates_text(self, template_data: dict, app_name: str, app_id: str) -> str:
        """格式化消息模板为文本"""
        try:
            templates = template_data.get('list', [])
            max_count = template_data.get('max_msg_tpl_count', 10)

            if not templates:
                return f"📨 {app_name} (AppID: {app_id})\n❌ 暂无消息模板"

            result = f"📨 {app_name} 消息模板\nAppID: {app_id}\n"
            result += f"模板数量: {len(templates)}/{max_count}\n\n"

            # 状态映射
            status_map = {
                1: "🟡 待审核",
                2: "❌ 审核拒绝",
                3: "✅ 审核通过",
                4: "🔄 修改中"
            }

            # 类型映射
            type_map = {
                1: "🔘 按钮模板",
                2: "📝 Markdown模板"
            }

            for i, template in enumerate(templates[:10], 1):
                tpl_name = template.get('tpl_name', '未命名模板')
                tpl_type = template.get('tpl_type', 0)
                status = template.get('status', 0)
                tpl_id = template.get('tpl_id', '')

                result += f"{i}. {tpl_name}\n"
                result += f"   ID: {tpl_id}\n"
                result += f"   类型: {type_map.get(tpl_type, '未知类型')}\n"
                result += f"   状态: {status_map.get(status, '未知状态')}\n\n"

            return result.strip()

        except Exception as e:
            return f"📨 {app_name} (AppID: {app_id})\n❌ 模板格式化失败"

    def _format_bot_info_text(self, bot_data: dict, app_name: str, app_id: str) -> str:
        """格式化机器人信息为文本"""
        try:
            # 处理嵌套数据结构
            actual_data = bot_data
            if 'data' in bot_data and isinstance(bot_data['data'], dict):
                if 'data' in bot_data['data']:
                    actual_data = bot_data['data']['data']
                else:
                    actual_data = bot_data['data']

            robot_name = actual_data.get('robot_name', app_name)
            result = f"🤖 {robot_name} 机器人信息\n\n"

            # 基本信息
            result += f"📋 基本信息:\n"
            result += f"  名称: {actual_data.get('robot_name', '未知')}\n"
            result += f"  UIN: {actual_data.get('robot_uin', '未知')}\n"
            result += f"  应用ID: {actual_data.get('appid', app_id)}\n"
            result += f"  描述: {actual_data.get('robot_desc', '无描述')}\n\n"

            # 状态信息
            result += f"📊 状态信息:\n"
            ban_status = "已封禁" if actual_data.get('robot_ban') else "正常"
            result += f"  机器人状态: {ban_status}\n"

            mute_status = "已禁言" if actual_data.get('mute_status', 0) != 0 else "正常"
            result += f"  禁言状态: {mute_status}\n\n"

            # 命令信息
            commands = actual_data.get('commands', [])
            if commands:
                result += f"⚡ 可用命令 ({len(commands)}个):\n"
                for cmd in commands[:5]:  # 最多显示5个命令
                    status = "✅" if cmd.get('status') == 0 else "❌"
                    result += f"  {status} {cmd.get('name', '未知命令')}\n"
                if len(commands) > 5:
                    result += f"  ... 还有{len(commands) - 5}个命令\n"

            return result.strip()

        except Exception as e:
            return f"🤖 {app_name} (AppID: {app_id})\n❌ 信息格式化失败"
