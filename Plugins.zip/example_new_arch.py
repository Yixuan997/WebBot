"""
示例插件 - 演示新适配器架构的使用

此插件展示如何：
1. 使用BaseEvent进行协议无关的编程
2. 使用特定协议的Event处理协议特定功能
3. 使用BaseMessage构建消息
"""

from Adapters.base import BaseEvent, BaseMessage, BaseMessageSegment
from Adapters.qq.event import QQMessageEvent
from Adapters.qq.message import QQMessage, QQMessageSegment
from Adapters.onebot.v11.event import OneBotMessageEvent
from Adapters.onebot.v11.message import OneBotMessage, OneBotMessageSegment


async def handle_message(event: BaseEvent):
    """
    处理消息事件（协议无关）
    
    Args:
        event: 基础事件对象
    """
    # 协议无关的处理
    if event.get_type() != "message":
        return
    
    user_id = event.get_user_id()
    message_text = event.get_plaintext()
    
    # 示例1: 协议无关的echo命令
    if message_text.startswith("/echo "):
        content = message_text[6:]
        
        # 根据协议类型构建消息
        if isinstance(event, QQMessageEvent):
            # QQ协议
            msg = QQMessage()
            msg.append(QQMessageSegment.text(f"Echo: {content}"))
            await event.bot.send(event, msg)
        
        elif isinstance(event, OneBotMessageEvent):
            # OneBot协议
            msg = OneBotMessage()
            msg.append(OneBotMessageSegment.text(f"Echo: {content}"))
            await event.bot.send(event, msg)
    
    # 示例2: 协议特定的功能
    elif message_text == "/status":
        if isinstance(event, QQMessageEvent):
            # QQ协议特有功能：Markdown消息
            msg = QQMessage()
            msg.append(QQMessageSegment.markdown(
                "# 机器人状态\\n"
                f"- 协议: QQ Official\\n"
                f"- 用户ID: {user_id}\\n"
                f"- 会话ID: {event.get_session_id()}"
            ))
            await event.bot.send(event, msg)
        
        elif isinstance(event, OneBotMessageEvent):
            # OneBot协议
            msg = OneBotMessage()
            msg.append(OneBotMessageSegment.text(
                f"机器人状态\\n"
                f"协议: OneBot V11\\n"
                f"用户ID: {user_id}\\n"
                f"会话ID: {event.get_session_id()}"
            ))
            await event.bot.send(event, msg)
    
    # 示例3: 完全协议无关的处理（只使用BaseEvent接口）
    elif message_text == "/ping":
        # 使用is_tome检查是否@机器人
        if event.is_tome():
            # 这里需要协议特定的消息构建
            # 实际项目中可以提供工具函数统一处理
            pass


# 插件元信息
__plugin_name__ = "新架构示例"
__plugin_description__ = "演示新适配器架构的使用方法"
__plugin_usage__ = """
/echo <文本> - 回显文本
/status - 查看机器人状态（协议特定格式）
/ping - 测试响应
"""
