"""
Minecraft查询插件

提供Minecraft服务器和玩家查询功能：
- 服务器状态查询
- 玩家信息查询

命令：
- mc <服务器:端口> - 查询服务器状态
- mc player <玩家名> - 查询玩家信息
"""

from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin
import time
import asyncio


class Plugin(BasePlugin):
    """Minecraft查询插件"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "MinecraftQuery"
        self.version = "1.0.0"
        self.description = "Minecraft服务器和玩家查询插件"
        self.author = "AI Assistant"
        self.priority = 5

        # 统计信息
        self.stats = {
            'queries_processed': 0,
            'servers_queried': 0,
            'players_queried': 0,
            'start_time': time.time()
        }

        # 注册命令信息
        self.register_command_info('mc', 'Minecraft查询主命令', 'mc <服务器:端口> 或 mc player <玩家名>')

        # 命令处理器
        self.command_handlers = {
            'mc': self.cmd_main
        }

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.on_message_received],
            'bot_start': [self.on_bot_start],
            'bot_stop': [self.on_bot_stop]
        }

    # ===== Hook事件处理器 =====

    def on_message_received(self, message_data, user_id, bot_id):
        """消息接收事件处理器"""
        try:
            content = message_data.get('content', '').strip()

            # 处理mc相关命令
            result = self._handle_mc_command(content)
            if result['handled']:
                self.stats['queries_processed'] += 1
                return result

        except Exception as e:
            return {
                'response': MessageBuilder.text(f'❌ 处理消息时发生错误: {str(e)}'),
                'handled': True
            }

        return {'handled': False}

    def on_bot_start(self, bot_id):
        """机器人启动事件"""
        return {
            'message': f'⛏️ Minecraft查询插件已启动',
            'handled': True
        }

    def on_bot_stop(self, bot_id):
        """机器人停止事件"""
        return {
            'message': f'🛑 Minecraft查询插件已停止',
            'handled': True
        }

    # ===== 命令处理方法 =====

    def _handle_mc_command(self, content):
        """处理mc相关命令"""
        # 检查是否是mc命令（带/和不带/）
        if content.startswith('/mc ') or content.startswith('mc '):
            # 去掉前缀，获取参数
            if content.startswith('/'):
                args_str = content[4:]  # 去掉 "/mc "
            else:
                args_str = content[3:]  # 去掉 "mc "
            
            args = args_str.split() if args_str else []
            
            try:
                result = self.cmd_main(args)
                return {
                    'response': result,
                    'handled': True
                }
            except Exception as e:
                return {
                    'response': MessageBuilder.text(f"❌ 命令执行失败: {str(e)}"),
                    'handled': True
                }

        return {'handled': False}

    def cmd_main(self, args):
        """主命令处理"""
        if not args:
            return MessageBuilder.text("❌ 请提供参数\n\n使用方法：\n• mc <服务器:端口> - 查询服务器\n• mc player <玩家名> - 查询玩家")
        
        subcommand = args[0].lower()
        
        if subcommand == 'player':
            # 玩家查询
            if len(args) < 2:
                return MessageBuilder.text("❌ 请提供玩家名，格式：mc player <玩家名>")
            return self.cmd_player_query(args[1:])
        else:
            # 服务器查询
            return self.cmd_server_query(args)

    def cmd_server_query(self, args):
        """查询服务器状态"""
        if not args:
            return MessageBuilder.text("❌ 请提供服务器地址，格式：mc <服务器:端口>")

        server_address = args[0]
        
        # 验证地址格式
        is_valid, host, port = self._validate_address(server_address)
        if not is_valid:
            return MessageBuilder.text(f"❌ 服务器地址格式错误: {server_address}\n\n正确格式：\n• example.com\n• example.com:25565\n• 192.168.1.1:25565")

        # 执行查询
        try:
            from .core.server_query import server_query
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result = loop.run_until_complete(server_query.query_server(host, port))
            finally:
                loop.close()
        except Exception as e:
            return MessageBuilder.text(f"❌ 查询失败: {str(e)}")

        # 处理查询结果
        if result['success']:
            self.stats['servers_queried'] += 1
            return self._render_server_result(result)
        else:
            display_host = self._format_host_for_display(host)
            return self._render_server_error(result, host, port)

    def cmd_player_query(self, args):
        """查询玩家信息"""
        if not args:
            return MessageBuilder.text("❌ 请提供玩家名，格式：mc player <玩家名>")

        player_name = args[0]

        # 执行查询
        try:
            from .core.player_query import player_query
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result = loop.run_until_complete(player_query.query_player(player_name))
            finally:
                loop.close()
        except Exception as e:
            return MessageBuilder.text(f"❌ 查询失败: {str(e)}")

        # 处理查询结果
        if result['success']:
            self.stats['players_queried'] += 1
            return self._render_player_result(result)
        else:
            return self._render_player_error(result, player_name)

    # ===== 图片渲染方法 =====

    def _render_server_result(self, result):
        """渲染服务器查询结果为图片"""
        try:
            from .core.render import minecraft_renderer
            image_result = minecraft_renderer.render_server_status(result)
            if image_result:
                return image_result
            else:
                return MessageBuilder.text("❌ 图片生成失败")
        except Exception:
            return MessageBuilder.text("❌ 图片生成失败")

    def _render_server_error(self, result, host, port):
        """服务器查询错误直接返回文字"""
        display_host = self._format_host_for_display(host)
        return MessageBuilder.text(f"❌ 服务器查询失败\n\n🌐 服务器: {display_host}:{port}\n💥 错误: {result.get('error', '未知错误')}")

    def _render_player_result(self, result):
        """渲染玩家查询结果为图片"""
        try:
            from .core.render import minecraft_renderer
            image_result = minecraft_renderer.render_player_info(result)
            if image_result:
                return image_result
            else:
                return MessageBuilder.text("❌ 图片生成失败")
        except Exception:
            return MessageBuilder.text("❌ 图片生成失败")

    def _render_player_error(self, result, player_name):
        """玩家查询错误直接返回文字"""
        return MessageBuilder.text(f"❌ 玩家查询失败\n\n👤 玩家: {player_name}\n💥 错误: {result.get('error', '未知错误')}")

    # ===== 工具方法 =====

    def _validate_address(self, address):
        """验证服务器地址格式"""
        try:
            if ':' in address:
                host, port_str = address.rsplit(':', 1)
                port = int(port_str)
                if not (1 <= port <= 65535):
                    return False, '', 0
            else:
                host = address.strip()
                port = 25565
            
            if not host or len(host) > 253:
                return False, '', 0
            
            return True, host, port
        except Exception:
            return False, '', 0

    def _format_host_for_display(self, host):
        """格式化主机名以避免QQ URL过滤"""
        try:
            import re
            # 检查是否是IP地址
            if re.match(r'^\d+\.\d+\.\d+\.\d+$', host):
                return host
            # 域名转换为大写
            return host.upper()
        except Exception:
            return host
