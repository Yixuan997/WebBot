"""
Minecraft插件渲染系统
"""

from Core.tools.browser import browser
from Core.message.builder import MessageBuilder
from datetime import datetime


class MinecraftRenderer:
    """Minecraft插件渲染系统 - 简单封装"""

    def __init__(self):
        """初始化渲染系统"""
        pass

    def render_server_status(self, result: dict):
        """渲染服务器状态为图片消息"""

        try:
            # 处理数据
            host = result['host']
            port = result['port']
            latency = result.get('latency', 0)
            motd = result.get('motd', '')
            version = result.get('version', 'Unknown')
            server_type = result.get('server_type', 'Unknown')
            players = result.get('players', {})

            # 格式化玩家信息
            players_online = players.get('online', 0)
            players_max = players.get('max', 0)
            player_list = players.get('list', [])

            # 计算玩家百分比
            if players_max > 0:
                player_percentage = round((players_online / players_max) * 100, 1)
            else:
                player_percentage = 0

            # 准备模板数据
            template_data = {
                'display_host': host,
                'port': port,
                'latency': round(latency, 1),
                'motd': motd,
                'version': version,
                'server_type': server_type,
                'players_online': players_online,
                'players_max': players_max,
                'player_percentage': player_percentage,
                'player_list': player_list,
                'query_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

            # 渲染模板
            template_path = 'Minecraft/templates/server_status.html'
            image_base64 = browser.render(template_path, template_data, width=600)


            if image_base64:
                return MessageBuilder.image(
                    base64_data=image_base64,
                    caption=f"⛏️服务器状态"
                )
            else:
                return None

        except Exception:
            return None

    def render_player_info(self, result: dict):
        """渲染玩家信息为图片消息"""

        try:
            username = result['username']
            uuid = result['uuid']
            avatar_url = result.get('avatar_url')
            skin_url = result.get('skin_url')
            body_render_url = result.get('body_render_url')
            head_render_url = result.get('head_render_url')
            has_custom_skin = result.get('has_custom_skin', False)
            cape_url = result.get('cape_url')

            # 准备模板数据
            template_data = {
                'username': username,
                'uuid': uuid,
                'avatar_url': avatar_url,
                'skin_url': skin_url,
                'body_render_url': body_render_url,
                'head_render_url': head_render_url,
                'has_custom_skin': has_custom_skin,
                'cape_url': cape_url,
                'is_premium': True
            }

            # 渲染模板
            template_path = 'Minecraft/templates/player_info.html'
            image_base64 = browser.render(template_path, template_data, width=500)

            if image_base64:
                return MessageBuilder.image(
                    base64_data=image_base64,
                    caption=f"👤 {username} 玩家信息"
                )
            else:
                return None

        except Exception:
            return None


# 创建全局渲染器实例
minecraft_renderer = MinecraftRenderer()
