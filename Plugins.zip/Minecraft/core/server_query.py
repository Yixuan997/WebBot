"""
Minecraft服务器查询核心模块
"""

import asyncio
import socket
import time
import re
from typing import Dict, Any, Tuple

# 导入mcstatus库
from mcstatus import JavaServer


class ServerQuery:
    """Minecraft服务器查询类"""

    def __init__(self):
        self.timeout = 8  # 查询超时时间（秒）

    async def query_server(self, host: str, port: int = 25565) -> Dict[str, Any]:
        """查询Minecraft服务器状态"""
        try:
            # 尝试mcstatus查询
            result = await self._query_with_mcstatus(host, port)
            if result['success']:
                return result

            # 回退到基础连接测试
            return await self._basic_connection_test(host, port)

        except Exception as e:
            return {
                'success': False,
                'error': f'Query failed: {str(e)}',
                'host': host,
                'port': port
            }
    
    async def _query_with_mcstatus(self, host: str, port: int) -> Dict[str, Any]:
        """使用mcstatus库查询服务器"""
        try:
            # 创建服务器对象 - 修复端口处理问题
            if port == 25565:
                # 默认端口，不指定端口避免DNS解析问题
                server = JavaServer.lookup(host)
            else:
                # 非默认端口，使用正确的方式
                server = JavaServer(host, port)

            # 记录查询开始时间
            start_time = time.time()

            # 执行状态查询（在线程池中运行同步代码）
            status = await asyncio.wait_for(
                asyncio.to_thread(server.status),
                timeout=self.timeout
            )

            # 计算延迟
            latency = round((time.time() - start_time) * 1000, 2)

            # 解析服务器信息
            return self._parse_server_status(status, host, port, latency)

        except asyncio.TimeoutError:
            return {
                'success': False,
                'error': 'Query timeout',
                'host': host,
                'port': port
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'mcstatus query failed: {str(e)}',
                'host': host,
                'port': port
            }
    
    async def _basic_connection_test(self, host: str, port: int) -> Dict[str, Any]:
        """基础连接测试"""
        try:
            # 记录开始时间
            start_time = time.time()

            # 创建socket连接
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)

            try:
                # 尝试连接
                result = sock.connect_ex((host, port))
                latency = round((time.time() - start_time) * 1000, 2)

                if result == 0:
                    # 连接成功
                    return {
                        'success': True,
                        'host': host,
                        'port': port,
                        'latency': latency,
                        'motd': 'Minecraft Server (Connection Test)',
                        'version': 'Unknown',
                        'server_type': 'Unknown',
                        'players': {
                            'online': 0,
                            'max': 0,
                            'list': []
                        }
                    }
                else:
                    return {
                        'success': False,
                        'error': 'Connection refused',
                        'host': host,
                        'port': port
                    }

            finally:
                sock.close()

        except socket.timeout:
            return {
                'success': False,
                'error': 'Connection timeout',
                'host': host,
                'port': port
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'Connection failed: {str(e)}',
                'host': host,
                'port': port
            }
    
    def _parse_server_status(self, status, host: str, port: int, latency: float) -> Dict[str, Any]:
        """解析服务器状态"""
        try:
            # 清理MOTD中的格式代码
            motd = self._clean_motd(getattr(status, 'description', 'Minecraft Server'))

            # 获取玩家信息
            players_online = 0
            players_max = 0
            player_list = []

            if hasattr(status, 'players') and status.players:
                players_online = getattr(status.players, 'online', 0)
                players_max = getattr(status.players, 'max', 0)

                # 获取玩家列表（如果可用）
                if hasattr(status.players, 'sample') and status.players.sample:
                    player_list = [getattr(player, 'name', str(player)) for player in status.players.sample]

            # 获取版本信息
            version = 'Unknown'
            if hasattr(status, 'version') and status.version:
                version = getattr(status.version, 'name', 'Unknown')

            return {
                'success': True,
                'host': host,
                'port': port,
                'latency': latency,
                'motd': motd,
                'version': version,
                'server_type': 'Java Edition',
                'players': {
                    'online': players_online,
                    'max': players_max,
                    'list': player_list
                }
            }

        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to parse server status: {str(e)}',
                'host': host,
                'port': port
            }
    

    
    def _clean_motd(self, description) -> str:
        """清理MOTD中的格式代码"""
        try:
            text = str(description)
            # 移除颜色代码并清理空白
            text = re.sub(r'[§&].', '', text)
            return ' '.join(text.split()).strip()
        except Exception:
            return 'Minecraft Server'
    
    def validate_address(self, address: str) -> Tuple[bool, str, int]:
        """验证服务器地址格式"""
        try:
            if ':' in address:
                host, port_str = address.rsplit(':', 1)
                port = int(port_str)
                if not (1 <= port <= 65535):
                    return False, '', 0
            else:
                host = address.strip()
                port = 25565

            if not host or len(host) > 253:
                return False, '', 0

            return True, host, port
        except Exception:
            return False, '', 0

# 创建全局查询实例
server_query = ServerQuery()
