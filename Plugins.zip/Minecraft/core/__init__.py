"""
Minecraft查询插件核心模块

包含服务器查询和玩家查询功能
"""

from .server_query import server_query
from .player_query import player_query

__all__ = ['server_query', 'player_query']
