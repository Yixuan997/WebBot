"""
Minecraft玩家查询核心模块
"""

import asyncio
import aiohttp
from typing import Dict, Any
import re


class PlayerQuery:
    """Minecraft玩家查询类"""

    def __init__(self):
        self.timeout = 8

    async def query_player(self, username: str) -> Dict[str, Any]:
        """查询玩家信息"""
        try:
            if not self._validate_username(username):
                return {
                    'success': False,
                    'error': 'Invalid username format',
                    'username': username
                }

            # 查询玩家UUID
            uuid_result = await self._get_player_uuid(username)
            if not uuid_result['success']:
                return uuid_result

            uuid = uuid_result['uuid']

            # 获取皮肤信息
            skin_info = await self._get_player_skin(uuid)

            return {
                'success': True,
                'username': uuid_result['name'],
                'uuid': uuid,
                'avatar_url': f"https://crafatar.com/avatars/{uuid}?size=64",
                'skin_url': f"https://crafatar.com/skins/{uuid}",  # 使用渲染服务
                'skin_raw_url': skin_info.get('skin_url'),  # 原始纹理URL
                'cape_url': skin_info.get('cape_url'),
                'has_custom_skin': skin_info.get('has_custom_skin', False),
                'body_render_url': f"https://crafatar.com/renders/body/{uuid}?size=128",  # 身体渲染
                'head_render_url': f"https://crafatar.com/renders/head/{uuid}?size=64"   # 头部渲染
            }

        except Exception as e:
            return {
                'success': False,
                'error': f'Player query failed: {str(e)}',
                'username': username
            }

    async def _get_player_uuid(self, username: str) -> Dict[str, Any]:
        """获取玩家UUID"""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                url = f"https://api.mojang.com/users/profiles/minecraft/{username}"
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'success': True,
                            'uuid': data['id'],
                            'name': data['name']
                        }
                    elif response.status == 204:
                        return {
                            'success': False,
                            'error': 'Player not found',
                            'username': username
                        }
                    else:
                        return {
                            'success': False,
                            'error': f'API error: {response.status}',
                            'username': username
                        }
        except Exception as e:
            return {
                'success': False,
                'error': f'UUID query failed: {str(e)}',
                'username': username
            }

    async def _get_player_skin(self, uuid: str) -> Dict[str, Any]:
        """获取玩家皮肤信息"""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout)) as session:
                url = f"https://sessionserver.mojang.com/session/minecraft/profile/{uuid}"
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()

                        # 解析 textures 属性
                        if 'properties' in data:
                            for prop in data['properties']:
                                if prop.get('name') == 'textures':
                                    import base64
                                    import json

                                    # 解码 base64 纹理数据
                                    texture_data = base64.b64decode(prop['value']).decode('utf-8')
                                    textures = json.loads(texture_data)

                                    result = {}

                                    # 获取皮肤URL
                                    if 'textures' in textures and 'SKIN' in textures['textures']:
                                        skin_info = textures['textures']['SKIN']
                                        result['skin_url'] = skin_info.get('url')
                                        result['has_custom_skin'] = True
                                    else:
                                        result['has_custom_skin'] = False

                                    # 获取披风URL
                                    if 'textures' in textures and 'CAPE' in textures['textures']:
                                        cape_info = textures['textures']['CAPE']
                                        result['cape_url'] = cape_info.get('url')

                                    return result

                        return {'has_custom_skin': False}
                    else:
                        return {'has_custom_skin': False}
        except Exception:
            return {'has_custom_skin': False}

    def _validate_username(self, username: str) -> bool:
        """验证用户名格式"""
        if not username or len(username) < 3 or len(username) > 16:
            return False
        return re.match(r'^[a-zA-Z0-9_]+$', username) is not None


# 创建全局查询实例
player_query = PlayerQuery()