#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
QQ开放平台自动提交插件
提供QQ机器人开放平台的自动提交功能
"""

import time
from datetime import datetime
from typing import List

from Core.logging.file_logger import log_error, log_info
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin

# 使用本地的认证管理器
try:
    from .auth.manager import AuthManager
except ImportError:
    AuthManager = None


class Plugin(BasePlugin):
    """自动提交插件"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "AutoSubmit"
        self.version = "1.0.0"
        self.description = "QQ开放平台自动提交工具，支持配置自动提交、白名单管理等功能"
        self.author = "Yixuan"

        # 注册命令信息
        self.register_command_info('自动提交', 'QQ开放平台自动提交', '自动提交 [操作]')

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.handle_message_hook]
        }

        # 初始化认证管理器（复用QQDevPlatform的）
        try:
            if AuthManager is not None:
                self.auth_manager = AuthManager()
            else:
                self.auth_manager = None
                log_error(0, "无法加载认证管理器", "AUTOSUBMIT_AUTH_ERROR")
        except Exception as e:
            self.auth_manager = None
            log_error(0, f"初始化认证管理器失败: {e}", "AUTOSUBMIT_AUTH_INIT_ERROR")

        # 初始化渲染系统
        try:
            from .utils.render import AutoSubmitRenderSystem
            self.render_system = AutoSubmitRenderSystem()
            log_info(0, "自动提交插件渲染系统初始化成功", "AUTOSUBMIT_RENDER_INIT_SUCCESS")
        except Exception as e:
            log_error(0, f"自动提交插件渲染系统初始化失败: {e}", "AUTOSUBMIT_RENDER_INIT_ERROR")
            self.render_system = None

        # 权限设置
        self.admin_only = False

    def handle_message_hook(self, message_data, user_id, bot_id):
        """处理消息Hook - 仅支持私聊"""
        content = message_data.get('content', '').strip()

        # 检查是否是自动提交命令
        if content.startswith('自动提交'):
            print(f"[AutoSubmit] 收到自动提交命令: {content} (用户: {user_id}, Bot: {bot_id})")

            # 检查是否为私聊消息
            if not self._is_private_message(message_data):
                print(f"[AutoSubmit] 拒绝非私聊消息: {content}")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 自动提交功能仅支持私聊使用\n💡 请私聊机器人使用此功能")
                }

            print(f"[AutoSubmit] 开始处理私聊消息: {content}")
            result = self.handle_message(bot_id, message_data)

            if result is not None:
                print(f"[AutoSubmit] 消息处理完成，返回结果")
                # 如果result已经是Hook格式，直接返回
                if isinstance(result, dict) and 'handled' in result:
                    return result
                # 否则包装成Hook格式
                return {
                    'handled': True,
                    'response': result
                }

        return {'handled': False}

    def handle_message(self, bot_id: str, message_data: dict) -> dict:
        """处理消息"""
        try:
            content = message_data.get('content', '').strip()
            user_id = message_data.get('author', {}).get('id', '')

            print(f"[AutoSubmit] 处理消息: {content} (用户: {user_id})")

            # 检查是否是自动提交命令
            if not content.startswith('自动提交'):
                return {'handled': False}

            # 解析命令
            parts = content.split()
            print(f"[AutoSubmit] 解析命令部分: {parts}")

            if len(parts) == 1:
                print(f"[AutoSubmit] 显示主菜单")
                # 显示主菜单
                return self._show_main_menu()

            command = parts[1]
            args = parts[2:] if len(parts) > 2 else []
            print(f"[AutoSubmit] 执行命令: {command}, 参数: {args}")

            # 路由命令
            if command == '登录':
                print(f"[AutoSubmit] 处理登录命令")
                return self._handle_login(bot_id, user_id, message_data)
            elif command == '退出':
                print(f"[AutoSubmit] 处理退出命令")
                return self._handle_logout(bot_id, user_id)
            elif command == '状态':
                print(f"[AutoSubmit] 处理状态查询命令")
                return self._handle_status(bot_id, user_id)
            elif command == '配置':
                print(f"[AutoSubmit] 处理配置提交命令")
                return self._handle_config_submit(bot_id, user_id, args)
            elif command == '白名单':
                print(f"[AutoSubmit] 处理白名单提交命令")
                return self._handle_whitelist_submit(bot_id, user_id, args)
            elif command == '事件':
                print(f"[AutoSubmit] 处理事件提交命令")
                return self._handle_events_submit(bot_id, user_id, args)
            elif command == '全部':
                print(f"[AutoSubmit] 处理全部提交命令")
                return self._handle_submit_all(bot_id, user_id, args)
            elif command == '帮助':
                print(f"[AutoSubmit] 处理帮助命令")
                return self._handle_help_command(bot_id, user_id)
            else:
                print(f"[AutoSubmit] 未知命令: {command}")
                return self._show_unknown_command(command)

        except Exception as e:
            print(f"[AutoSubmit] 处理消息异常: {e}")
            log_error(bot_id, f"自动提交插件处理消息失败: {e}", "AUTOSUBMIT_HANDLE_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 处理命令时发生错误，请稍后重试")
            }

    def _show_main_menu(self) -> dict:
        """显示主菜单"""
        menu_text = """🤖 自动提交工具

🔒 仅支持私聊使用，确保账号安全

🔐 认证管理：
• 自动提交 登录 - 登录QQ开放平台
• 自动提交 退出 - 退出登录
• 自动提交 状态 - 查看登录状态

⚡ 自动提交功能：
• 自动提交 配置 - 自动提交机器人配置
• 自动提交 白名单 - 自动提交IP白名单
• 自动提交 事件 - 自动提交事件订阅
• 自动提交 全部 - 一键提交所有配置

💡 使用说明：
1. 首次使用请先登录
2. 选择需要自动提交的功能
3. 系统将自动完成提交流程

⚠️ 注意：此功能仅在私聊中可用"""

        return {
            'handled': True,
            'response': MessageBuilder.text(menu_text)
        }

    def _show_unknown_command(self, command: str) -> dict:
        """显示未知命令提示"""
        return {
            'handled': True,
            'response': MessageBuilder.text(f"❌ 未知命令：{command}\n💡 输入 '自动提交' 查看可用命令")
        }

    def _check_auth_required(self, user_id: str) -> dict:
        """检查是否需要认证"""
        print(f"[AutoSubmit] 检查用户认证要求 (用户: {user_id})")

        if not self.auth_manager:
            print(f"[AutoSubmit] 认证系统不可用")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 认证系统不可用，请检查QQDevPlatform插件")
            }

        if not self.auth_manager.is_authenticated(user_id):
            print(f"[AutoSubmit] 用户未认证")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 您尚未登录\n💡 输入 '自动提交 登录' 开始登录")
            }

        print(f"[AutoSubmit] 用户认证检查通过")
        return None

    # 认证相关方法
    def _handle_login(self, bot_id: str, user_id: str, message_data: dict = None) -> dict:
        """处理登录命令"""
        try:
            print(f"[AutoSubmit] 处理登录命令 (用户: {user_id})")

            if not self.auth_manager:
                print(f"[AutoSubmit] 认证系统不可用")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 认证系统不可用")
                }

            # 提取回复所需的信息
            if message_data:
                msg_id = message_data.get('id')
                openid = message_data.get('author', {}).get('user_openid') or message_data.get('openid')
                group_openid = message_data.get('group_openid')
                message_type = message_data.get('type', 'unknown')
                print(f"[AutoSubmit] 消息信息: msg_id={msg_id}, openid={openid}")

            # 检查是否已登录
            print(f"[AutoSubmit] 检查用户登录状态")
            is_authenticated = self.auth_manager.is_authenticated(user_id)
            if is_authenticated:
                print(f"[AutoSubmit] 用户已登录，显示应用列表图片")
                # 获取用户的登录信息
                session_info = self.auth_manager.get_session_info(user_id)
                uin = session_info.get('uin', '未知')
                uid = session_info.get('uid', '')
                ticket = session_info.get('ticket', '')
                login_time = session_info.get('login_time', '未知时间')

                # 获取应用列表并生成图片
                try:
                    print(f"[AutoSubmit] 获取应用列表用于已登录用户")
                    from .api.client import AutoSubmitAPIClient
                    api_client = AutoSubmitAPIClient(session_info)
                    app_result = api_client.get_app_list()

                    # 获取应用列表数据
                    apps = []
                    if app_result.get('success') and app_result.get('data'):
                        api_data = app_result['data']
                        if isinstance(api_data, dict) and 'apps' in api_data:
                            apps = api_data.get('apps', [])

                    print(f"[AutoSubmit] 已登录用户找到 {len(apps)} 个应用")

                    # 使用渲染系统生成图片
                    if self.render_system:
                        print(f"[AutoSubmit] 为已登录用户生成应用列表图片")
                        status_message = self.render_system.render_login_success(uin, apps, login_time)

                        if status_message:
                            print(f"[AutoSubmit] 已登录用户图片生成成功")
                            return {
                                'handled': True,
                                'response': status_message
                            }
                        else:
                            print(f"[AutoSubmit] 已登录用户图片生成失败")
                            return {
                                'handled': True,
                                'response': MessageBuilder.text("❌ 应用列表图片生成失败")
                            }
                    else:
                        print(f"[AutoSubmit] 渲染系统未初始化")
                        return {
                            'handled': True,
                            'response': MessageBuilder.text("❌ 渲染系统未初始化")
                        }

                except Exception as e:
                    print(f"[AutoSubmit] 获取已登录用户应用列表失败: {e}")
                    return {
                        'handled': True,
                        'response': MessageBuilder.text(f"❌ 获取应用列表失败: {e}")
                    }

            # 获取登录二维码
            print(f"[AutoSubmit] 获取登录二维码")
            qr_result = self.auth_manager.get_login_qr()
            print(f"[AutoSubmit] 二维码获取结果: {qr_result.get('status')}")

            if qr_result['status'] == 'success':
                print(f"[AutoSubmit] 二维码获取成功")
                # 记录登录请求信息，用于后续回复
                if message_data:
                    login_info = {
                        'user_id': user_id,
                        'bot_id': bot_id,
                        'msg_id': msg_id,
                        'openid': openid,
                        'group_openid': group_openid,
                        'message_type': message_type,
                        'qr_code': qr_result.get('qrcode'),
                        'timestamp': time.time()
                    }

                    # 存储登录信息，用于后续检测
                    if not hasattr(self, 'pending_logins'):
                        self.pending_logins = {}
                    self.pending_logins[user_id] = login_info
                    print(f"[AutoSubmit] 登录信息已存储")

                # 处理URL，将.com换成大写.COM
                login_url = qr_result['url'].replace('.com', '.COM')

                # 使用text_card_link发送登录链接
                login_card = MessageBuilder.text_card_link(
                    text="🔐 QQ开放平台登录\n\n📱 点击下方按钮登录QQ开放平台，管理您的机器人\n\n⏰ 系统将在1分钟内自动检测登录状态",
                    button_text="🚀 点击登录",
                    button_url=login_url,
                    description="自动提交工具",
                    prompt="⏰ 链接有效期：1分钟"
                )

                # 启动后台检测任务
                self._start_login_detection(user_id)

                return {
                    'handled': True,
                    'response': login_card
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"❌ 获取登录二维码失败：{qr_result.get('message', '未知错误')}")
                }

        except Exception as e:
            log_error(bot_id, f"处理登录命令失败: {e}", "AUTOSUBMIT_LOGIN_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 登录失败，请稍后重试")
            }

    def _handle_logout(self, bot_id: str, user_id: str) -> dict:
        """处理退出登录命令"""
        try:
            if not self.auth_manager:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 认证系统不可用")
                }

            # 检查是否已登录
            if not self.auth_manager.is_authenticated(user_id):
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 您尚未登录，无需退出")
                }

            # 获取用户信息（在退出前）
            session_info = self.auth_manager.get_session_info(user_id)
            uin = session_info.get('uin', '未知') if session_info else '未知'

            # 执行退出登录
            logout_success = self.auth_manager.logout(user_id)

            if logout_success:
                # 清理待处理的登录信息（如果有）
                if hasattr(self, 'pending_logins') and user_id in self.pending_logins:
                    del self.pending_logins[user_id]

                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"✅ 退出登录成功\n👤 用户：{uin}\n💡 输入 '自动提交 登录' 可重新登录")
                }
            else:
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 退出登录失败，请稍后重试")
                }

        except Exception as e:
            log_error(bot_id, f"处理退出登录命令失败: {e}", "AUTOSUBMIT_LOGOUT_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 退出登录失败，请稍后重试")
            }

    def _handle_status(self, bot_id: str, user_id: str) -> dict:
        """处理状态查询"""
        try:
            print(f"[AutoSubmit] 处理状态查询 (用户: {user_id})")

            if not self.auth_manager:
                print(f"[AutoSubmit] 认证系统不可用")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 认证系统不可用")
                }

            print(f"[AutoSubmit] 检查用户认证状态")
            if not self.auth_manager.is_authenticated(user_id):
                print(f"[AutoSubmit] 用户未登录")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 您尚未登录\n💡 输入 '自动提交 登录' 开始登录")
                }

            print(f"[AutoSubmit] 获取用户会话信息")
            # 获取会话信息
            session_info = self.auth_manager.get_session_info(user_id)
            if session_info:
                print(f"[AutoSubmit] 会话信息获取成功")
                uin = session_info.get('uin', '未知')
                uid = session_info.get('uid', '')
                ticket = session_info.get('ticket', '')
                login_time = session_info.get('login_time', '未知时间')
                expires_at = session_info.get('expires_at', '未知时间')

                # 获取应用列表并生成状态图片
                try:
                    print(f"[AutoSubmit] 获取应用列表用于状态显示")
                    from .api.client import AutoSubmitAPIClient
                    api_client = AutoSubmitAPIClient(session_info)
                    app_result = api_client.get_app_list()

                    # 获取应用列表数据
                    apps = []
                    if app_result.get('success') and app_result.get('data'):
                        api_data = app_result['data']
                        if isinstance(api_data, dict) and 'apps' in api_data:
                            apps = api_data.get('apps', [])

                    print(f"[AutoSubmit] 状态查询找到 {len(apps)} 个应用")

                    # 使用渲染系统生成状态图片
                    if self.render_system:
                        print(f"[AutoSubmit] 使用渲染系统生成状态图片")
                        status_message = self.render_system.render_login_success(uin, apps, login_time)

                        if status_message:
                            print(f"[AutoSubmit] 状态图片生成成功")
                            return {
                                'handled': True,
                                'response': status_message
                            }
                        else:
                            print(f"[AutoSubmit] 状态图片生成失败")
                            return {
                                'handled': True,
                                'response': MessageBuilder.text("❌ 状态图片生成失败")
                            }
                    else:
                        print(f"[AutoSubmit] 渲染系统未初始化")
                        return {
                            'handled': True,
                            'response': MessageBuilder.text("❌ 渲染系统未初始化")
                        }

                except Exception as e:
                    print(f"[AutoSubmit] 获取应用列表失败: {e}")
                    return {
                        'handled': True,
                        'response': MessageBuilder.text(f"❌ 获取应用列表失败: {e}")
                    }
            else:
                print(f"[AutoSubmit] 获取会话信息失败")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取登录状态失败")
                }

        except Exception as e:
            print(f"[AutoSubmit] 状态查询异常: {e}")
            log_error(bot_id, f"处理状态查询失败: {e}", "AUTOSUBMIT_STATUS_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 状态查询失败，请稍后重试")
            }

    # 自动提交功能方法
    def _handle_config_submit(self, bot_id: str, user_id: str, args: list) -> dict:
        """处理配置自动提交"""
        print(f"[AutoSubmit] 开始处理配置提交 (用户: {user_id}, 参数: {args})")

        auth_check = self._check_auth_required(user_id)
        if auth_check:
            print(f"[AutoSubmit] 用户认证检查失败")
            return auth_check

        try:
            print(f"[AutoSubmit] 获取用户会话信息")
            # 获取会话信息
            session_info = self.auth_manager.get_session_info(user_id)
            if not session_info:
                print(f"[AutoSubmit] 获取会话信息失败")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 获取会话信息失败")
                }

            print(f"[AutoSubmit] 创建API客户端")
            # 创建API客户端
            from .api.client import AutoSubmitAPIClient
            api_client = AutoSubmitAPIClient(session_info)

            print(f"[AutoSubmit] 获取应用列表")
            # 获取应用列表
            apps_result = api_client.get_app_list()
            if not apps_result.get('success'):
                print(f"[AutoSubmit] 获取应用列表失败: {apps_result.get('message')}")
                return {
                    'handled': True,
                    'response': MessageBuilder.text(f"❌ 获取应用列表失败：{apps_result.get('message')}")
                }

            print(f"[AutoSubmit] 解析应用数据")
            # 解析应用数据
            apps_data = apps_result.get('data', {})
            apps = apps_data.get('apps', []) if isinstance(apps_data, dict) else []
            print(f"[AutoSubmit] 找到 {len(apps)} 个应用")

            if not apps:
                print(f"[AutoSubmit] 没有找到可用的应用")
                return {
                    'handled': True,
                    'response': MessageBuilder.text("❌ 没有找到可用的应用")
                }

            # 如果指定了应用序号
            if args and args[0].isdigit():
                app_index = int(args[0]) - 1
                print(f"[AutoSubmit] 指定应用序号: {args[0]} (索引: {app_index})")

                if 0 <= app_index < len(apps):
                    app = apps[app_index]
                    app_id = app.get('appId')
                    app_name = app.get('appName', '未知应用')
                    print(f"[AutoSubmit] 选择应用: {app_name} (ID: {app_id})")

                    # 示例配置数据（实际使用时应该从配置文件或用户输入获取）
                    config_data = {
                        "name": app_name,
                        "description": "自动提交的机器人配置",
                        "webhook_url": f"https://your-domain.com/webhook/qq",
                        "intents": ["GUILD_MESSAGES", "DIRECT_MESSAGE"]
                    }
                    print(f"[AutoSubmit] 准备提交配置数据: {config_data}")

                    # 提交配置
                    print(f"[AutoSubmit] 开始提交配置到应用: {app_id}")
                    result = api_client.submit_bot_config(app_id, config_data)
                    print(f"[AutoSubmit] 配置提交结果: {result}")

                    if result.get('success'):
                        print(f"[AutoSubmit] 配置提交成功")
                        return {
                            'handled': True,
                            'response': MessageBuilder.text(f"✅ 配置提交成功\n🤖 应用：{app_name}\n📝 {result.get('message')}")
                        }
                    else:
                        print(f"[AutoSubmit] 配置提交失败: {result.get('message')}")
                        return {
                            'handled': True,
                            'response': MessageBuilder.text(f"❌ 配置提交失败\n🤖 应用：{app_name}\n📝 {result.get('message')}")
                        }
                else:
                    print(f"[AutoSubmit] 应用序号无效: {args[0]}, 有效范围: 1-{len(apps)}")
                    return {
                        'handled': True,
                        'response': MessageBuilder.text(f"❌ 应用序号无效，请输入1-{len(apps)}之间的数字")
                    }

            # 显示应用列表
            print(f"[AutoSubmit] 显示应用列表")
            app_list = "📱 可用应用列表：\n\n"
            for i, app in enumerate(apps[:10], 1):  # 最多显示10个
                app_name = app.get('appName', '未知应用')
                app_id = app.get('appId', '未知ID')
                app_list += f"{i}. {app_name} (ID: {app_id})\n"

            app_list += f"\n💡 输入 '自动提交 配置 [序号]' 提交指定应用的配置"

            return {
                'handled': True,
                'response': MessageBuilder.text(app_list)
            }

        except Exception as e:
            print(f"[AutoSubmit] 处理配置提交异常: {e}")
            log_error(bot_id, f"处理配置提交失败: {e}", "AUTOSUBMIT_CONFIG_HANDLE_ERROR")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 配置提交失败，请稍后重试")
            }

    def _handle_whitelist_submit(self, bot_id: str, user_id: str, args: list) -> dict:
        """处理白名单自动提交"""
        auth_check = self._check_auth_required(user_id)
        if auth_check:
            return auth_check

        return {
            'handled': True,
            'response': MessageBuilder.text("🔄 白名单自动提交功能开发中...")
        }

    def _handle_events_submit(self, bot_id: str, user_id: str, args: list) -> dict:
        """处理事件订阅自动提交"""
        auth_check = self._check_auth_required(user_id)
        if auth_check:
            return auth_check

        return {
            'handled': True,
            'response': MessageBuilder.text("🔄 事件订阅自动提交功能开发中...")
        }

    def _handle_submit_all(self, bot_id: str, user_id: str, args: list) -> dict:
        """处理全部自动提交"""
        auth_check = self._check_auth_required(user_id)
        if auth_check:
            return auth_check

        return {
            'handled': True,
            'response': MessageBuilder.text("🔄 一键提交功能开发中...")
        }

    def _start_login_detection(self, user_id: str):
        """启动登录检测任务"""
        try:
            print(f"[AutoSubmit] 启动登录检测任务 (用户: {user_id})")
            import threading
            import time

            def check_login():
                """检测登录状态"""
                print(f"[AutoSubmit] 开始登录检测循环 (用户: {user_id})")
                max_attempts = 60  # 最多检测60次（1分钟）
                attempt = 0

                while attempt < max_attempts:
                    try:
                        print(f"[AutoSubmit] 登录检测第 {attempt + 1} 次尝试")

                        # 检查是否还有待处理的登录
                        if not hasattr(self, 'pending_logins') or user_id not in self.pending_logins:
                            print(f"[AutoSubmit] 没有待处理的登录，退出检测")
                            break

                        login_info = self.pending_logins[user_id]
                        qr_code = login_info.get('qr_code')
                        print(f"[AutoSubmit] 获取二维码: {qr_code[:20]}..." if qr_code else "[AutoSubmit] 没有二维码")

                        if qr_code:
                            # 检查二维码登录状态
                            print(f"[AutoSubmit] 检查二维码登录状态")
                            status_result = self.auth_manager.check_qr_login_status(qr_code)
                            print(f"[AutoSubmit] 登录状态检查结果: {status_result}")

                            if status_result['status'] == 'success':
                                print(f"[AutoSubmit] 登录成功！")
                                # 登录成功，保存认证信息
                                uin = status_result.get('uin')
                                uid = status_result.get('uid')
                                ticket = status_result.get('ticket')
                                print(f"[AutoSubmit] 获取认证信息: uin={uin}, uid={uid}")

                                if self.auth_manager.verify_auth(user_id, uin, uid, ticket):
                                    print(f"[AutoSubmit] 认证信息验证成功")

                                    # 发送登录成功消息
                                    self._send_login_success_message(user_id, login_info, uin, uid, ticket)

                                    # 清理待处理登录信息
                                    if user_id in self.pending_logins:
                                        del self.pending_logins[user_id]

                                    log_info(0, f"用户 {user_id} 自动登录成功", "AUTOSUBMIT_AUTO_LOGIN_SUCCESS")
                                    break
                                else:
                                    print(f"[AutoSubmit] 认证信息验证失败")
                            elif status_result['status'] == 'expired':
                                print(f"[AutoSubmit] 二维码已过期")
                                # 二维码过期
                                if user_id in self.pending_logins:
                                    del self.pending_logins[user_id]
                                break
                            else:
                                print(f"[AutoSubmit] 等待用户扫码...")

                        time.sleep(1)  # 等待1秒后再次检测
                        attempt += 1

                    except Exception as e:
                        print(f"[AutoSubmit] 登录检测异常: {e}")
                        log_error(0, f"登录检测异常: {e}", "AUTOSUBMIT_LOGIN_DETECTION_ERROR")
                        break

                print(f"[AutoSubmit] 登录检测结束")
                # 清理超时的登录信息
                if hasattr(self, 'pending_logins') and user_id in self.pending_logins:
                    del self.pending_logins[user_id]

            # 启动后台线程
            print(f"[AutoSubmit] 启动登录检测后台线程")
            detection_thread = threading.Thread(target=check_login, daemon=True)
            detection_thread.start()

        except Exception as e:
            print(f"[AutoSubmit] 启动登录检测失败: {e}")
            log_error(0, f"启动登录检测失败: {e}", "AUTOSUBMIT_START_DETECTION_ERROR")

    def _is_private_message(self, message_data: dict) -> bool:
        """
        检查是否为私聊消息

        Args:
            message_data: 消息数据

        Returns:
            True if 私聊消息, False otherwise
        """
        try:
            # 检查消息类型
            message_type = message_data.get('type', '')

            # QQ官方机器人的私聊消息类型
            if message_type in ['c2c_message', 'direct_message']:
                return True

            # 检查是否有群组相关字段，如果没有则可能是私聊
            has_group_id = bool(message_data.get('group_id') or message_data.get('group_openid'))
            has_guild_id = bool(message_data.get('guild_id'))
            has_channel_id = bool(message_data.get('channel_id'))

            # 如果没有群组、频道相关ID，则认为是私聊
            if not (has_group_id or has_guild_id or has_channel_id):
                return True

            # 检查是否明确标记为私聊
            is_direct = message_data.get('direct_message', False)
            if is_direct:
                return True

            return False

        except Exception as e:
            log_error(0, f"检查私聊消息类型失败: {e}", "AUTOSUBMIT_CHECK_PRIVATE_ERROR")
            # 出错时默认允许，避免误拦截
            return True

    def _send_login_success_message(self, user_id: str, login_info: dict, uin: str, uid: str, ticket: str):
        """发送登录成功消息"""
        try:
            print(f"[AutoSubmit] 发送登录成功消息 (用户: {user_id})")

            bot_id = login_info.get('bot_id')
            msg_id = login_info.get('msg_id')
            openid = login_info.get('openid')
            group_openid = login_info.get('group_openid')
            message_type = login_info.get('message_type')

            # 获取应用列表
            print(f"[AutoSubmit] 获取应用列表")
            session_data = {
                'uin': uin,
                'uid': uid,
                'ticket': ticket,
                'cookie': f"quin={uin}; quid={uid}; qticket={ticket}"
            }

            from .api.client import AutoSubmitAPIClient
            api_client = AutoSubmitAPIClient(session_data)
            app_result = api_client.get_app_list()

            # 获取应用列表数据
            apps = []
            if app_result.get('success') and app_result.get('data'):
                api_data = app_result['data']
                print(f"[AutoSubmit] API数据: {api_data}")

                # 检查是否有apps字段
                if isinstance(api_data, dict) and 'apps' in api_data:
                    apps = api_data.get('apps', [])
                elif isinstance(api_data, dict) and 'data' in api_data:
                    inner_data = api_data['data']
                    if isinstance(inner_data, dict) and 'apps' in inner_data:
                        apps = inner_data.get('apps', [])

            print(f"[AutoSubmit] 找到 {len(apps)} 个应用")

            # 构建登录成功消息
            login_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # 使用渲染系统生成登录成功图片
            if self.render_system:
                print(f"[AutoSubmit] 使用渲染系统生成登录成功图片")
                success_message = self.render_system.render_login_success(uin, apps, login_time)

                if success_message:
                    print(f"[AutoSubmit] 登录成功图片生成成功")
                    # 直接发送图片消息
                    print(f"[AutoSubmit] 直接发送登录成功图片")
                    self._send_message_directly(bot_id, openid, group_openid, message_type, msg_id, success_message)
                else:
                    print(f"[AutoSubmit] 图片生成失败")
                    # 发送失败消息
                    failure_message = MessageBuilder.text("❌ 登录成功图片生成失败")
                    print(f"[AutoSubmit] 发送图片生成失败消息")
                    self._send_message_directly(bot_id, openid, group_openid, message_type, msg_id, failure_message)
            else:
                print(f"[AutoSubmit] 渲染系统未初始化")
                # 发送失败消息
                failure_message = MessageBuilder.text("❌ 渲染系统未初始化")
                print(f"[AutoSubmit] 发送渲染系统未初始化消息")
                self._send_message_directly(bot_id, openid, group_openid, message_type, msg_id, failure_message)

        except Exception as e:
            print(f"[AutoSubmit] 发送登录成功消息失败: {e}")
            log_error(0, f"发送登录成功消息失败: {e}", "AUTOSUBMIT_LOGIN_SUCCESS_MSG_ERROR")

    def _send_message_directly(self, bot_id: str, openid: str, group_openid: str, message_type: str, msg_id: str, message):
        """直接发送消息"""
        try:
            print(f"[AutoSubmit] 直接发送消息: bot_id={bot_id}, message_type={message_type}")
            print(f"[AutoSubmit] openid={openid}, group_openid={group_openid}")

            # 确定目标
            if message_type == 'group_at' and group_openid:
                target = f"group:{group_openid}"
                print(f"[AutoSubmit] 群聊消息目标: {target}")
            elif message_type in ['c2c', 'c2c_message', 'direct_message'] and openid:
                target = f"user:{openid}"
                print(f"[AutoSubmit] 私聊消息目标: {target}")
            elif openid:
                # 如果有openid但消息类型不明确，默认为私聊
                target = f"user:{openid}"
                print(f"[AutoSubmit] 默认私聊消息目标: {target}")
            else:
                print(f"[AutoSubmit] 无法确定消息目标，openid={openid}, group_openid={group_openid}")
                return

            # 在Flask应用上下文中发送消息
            from flask import current_app
            try:
                app = current_app._get_current_object()
                print(f"[AutoSubmit] 获取当前应用上下文成功")
            except RuntimeError:
                # 如果无法获取当前应用，导入应用实例
                from app import app
                print(f"[AutoSubmit] 导入应用实例")

            with app.app_context():
                from Adapters import get_adapter_manager
                adapter_manager = get_adapter_manager()
                print(f"[AutoSubmit] 获取适配器管理器: {adapter_manager}")

                if not adapter_manager:
                    print(f"[AutoSubmit] 适配器管理器为None!")
                    return

                # 转换bot_id为整数
                try:
                    bot_id_int = int(bot_id)
                    print(f"[AutoSubmit] 转换bot_id为整数: {bot_id_int}")
                except ValueError:
                    print(f"[AutoSubmit] bot_id无法转换为整数: {bot_id}")
                    return

                # 发送消息 - QQ官方机器人需要回复ID
                if message_type == 'group_at':
                    print(f"[AutoSubmit] 发送群聊回复消息")
                    success = adapter_manager.send_message(
                        bot_id_int,
                        target,
                        message,
                        reply_to_msg_id=msg_id,
                        original_msg_id=msg_id
                    )
                else:
                    print(f"[AutoSubmit] 发送私聊回复消息")
                    # 私聊消息也需要回复ID
                    success = adapter_manager.send_message(
                        bot_id_int,
                        target,
                        message,
                        reply_to_msg_id=msg_id,
                        original_msg_id=msg_id
                    )

                print(f"[AutoSubmit] 消息发送结果: {success}")

        except Exception as e:
            print(f"[AutoSubmit] 直接发送消息异常: {e}")
            import traceback
            print(f"[AutoSubmit] 异常堆栈: {traceback.format_exc()}")
            log_error(0, f"直接发送消息失败: {e}", "AUTOSUBMIT_DIRECT_SEND_MESSAGE_ERROR")



    def _handle_help_command(self, bot_id: str, user_id: str) -> dict:
        """处理帮助命令"""
        try:
            print(f"[AutoSubmit] 生成帮助信息")

            # 使用默认帮助文本
            help_text = """🤖 自动提交工具指令列表

• 登录 - 登录QQ开放平台账号
• 退出 - 退出当前登录账号
• 状态 - 查看登录状态和应用列表
• 配置 [序号] - 自动提交机器人配置
• 白名单 - 自动提交白名单配置
• 事件 - 自动提交事件订阅配置
• 全部 - 一键提交所有配置
• 帮助 - 显示此帮助信息

💡 输入具体指令查看详细用法"""

            return {
                'handled': True,
                'response': MessageBuilder.text(help_text)
            }

        except Exception as e:
            print(f"[AutoSubmit] 帮助命令异常: {e}")
            return {
                'handled': True,
                'response': MessageBuilder.text("❌ 帮助信息生成失败，请稍后重试")
            }








