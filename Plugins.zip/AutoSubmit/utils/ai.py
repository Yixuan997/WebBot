#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
自动提交工具AI助手
使用BigModel API生成指令简介
"""

import requests
import json
from typing import Optional, Dict, Any
from Core.logging.file_logger import log_error, log_info


class AutoSubmitAIHelper:
    """自动提交工具AI助手"""

    def __init__(self, api_keys: list = None):
        """
        初始化AI助手

        Args:
            api_keys: BigModel API密钥列表
        """
        self.api_keys = api_keys or self._get_default_api_keys()
        self.current_key_index = 0
        self.base_url = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
        self.model = "glm-4-flash"  # 使用免费的GLM-4-Flash模型

    def _get_default_api_keys(self) -> list:
        """获取默认API密钥列表"""
        # 支持多个API密钥，提高可用性
        return [
            "a97c8258929e45a4a0d8bc492339a018.Et0G3iqW1fEoDrkC",
            # 可以在这里添加更多备用密钥
            # "your_backup_key_1",
            # "your_backup_key_2",
        ]
    
    def generate_command_description(self, command_name: str, command_params: Dict[str, Any]) -> Optional[str]:
        """
        生成指令简介
        
        Args:
            command_name: 指令名称
            command_params: 指令参数信息
            
        Returns:
            生成的指令简介，失败返回None
        """
        try:
            print(f"[AutoSubmitAI] 开始生成指令简介: {command_name}")
            
            if not self.api_keys or not any(self.api_keys):
                print(f"[AutoSubmitAI] API密钥未配置")
                return None
            
            # 构建提示词
            prompt = self._build_prompt(command_name, command_params)
            
            # 调用BigModel API
            response = self._call_bigmodel_api(prompt)
            
            if response:
                print(f"[AutoSubmitAI] 指令简介生成成功")
                return response
            else:
                print(f"[AutoSubmitAI] 指令简介生成失败")
                return None
                
        except Exception as e:
            print(f"[AutoSubmitAI] 生成指令简介异常: {e}")
            log_error(0, f"生成指令简介失败: {e}", "AUTOSUBMIT_AI_ERROR")
            return None
    
    def _build_prompt(self, command_name: str, command_params: Dict[str, Any]) -> str:
        """构建AI提示词"""
        prompt = f"""请为以下QQ机器人指令生成一个简洁的功能描述：

指令名称：{command_name}
指令参数：{json.dumps(command_params, ensure_ascii=False, indent=2)}

要求：
1. 描述要简洁明了，不超过50字
2. 突出指令的核心功能
3. 使用用户友好的语言
4. 不要包含技术细节
5. 直接返回描述文字，不要其他内容

示例格式：
"快速提交机器人配置到QQ开放平台，支持批量操作"
"""
        return prompt
    
    def _get_current_api_key(self) -> str:
        """获取当前使用的API密钥"""
        if not self.api_keys:
            return ""
        return self.api_keys[self.current_key_index % len(self.api_keys)]

    def _switch_to_next_key(self):
        """切换到下一个API密钥"""
        if len(self.api_keys) > 1:
            self.current_key_index = (self.current_key_index + 1) % len(self.api_keys)
            print(f"[AutoSubmitAI] 切换到备用API密钥 (索引: {self.current_key_index})")

    def _call_bigmodel_api(self, prompt: str) -> Optional[str]:
        """调用BigModel API，支持多密钥重试"""
        max_retries = len(self.api_keys) if self.api_keys else 1

        for attempt in range(max_retries):
            try:
                current_key = self._get_current_api_key()
                if not current_key:
                    print(f"[AutoSubmitAI] 没有可用的API密钥")
                    return None

                headers = {
                    "Authorization": f"Bearer {current_key}",
                    "Content-Type": "application/json"
                }

                data = {
                    "model": self.model,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    "temperature": 0.7,
                    "max_tokens": 100
                }

                print(f"[AutoSubmitAI] 调用BigModel API (尝试 {attempt + 1}/{max_retries})")
                response = requests.post(
                    self.base_url,
                    headers=headers,
                    json=data,
                    timeout=30
                )

                print(f"[AutoSubmitAI] API响应状态码: {response.status_code}")

                if response.status_code == 200:
                    result = response.json()
                    print(f"[AutoSubmitAI] API响应: {result}")

                    if "choices" in result and len(result["choices"]) > 0:
                        content = result["choices"][0]["message"]["content"].strip()
                        return content
                    else:
                        print(f"[AutoSubmitAI] API响应格式异常")
                        # 尝试下一个密钥
                        self._switch_to_next_key()
                        continue
                elif response.status_code == 401:
                    print(f"[AutoSubmitAI] API密钥无效，尝试下一个密钥")
                    self._switch_to_next_key()
                    continue
                elif response.status_code == 429:
                    print(f"[AutoSubmitAI] API调用频率限制，尝试下一个密钥")
                    self._switch_to_next_key()
                    continue
                else:
                    print(f"[AutoSubmitAI] API调用失败: {response.status_code}")
                    print(f"[AutoSubmitAI] 错误响应: {response.text}")
                    # 尝试下一个密钥
                    self._switch_to_next_key()
                    continue

            except Exception as e:
                print(f"[AutoSubmitAI] API调用异常: {e}")
                if attempt < max_retries - 1:
                    self._switch_to_next_key()
                    continue

        print(f"[AutoSubmitAI] 所有API密钥都尝试失败")
        return None
    

    
    def add_api_key(self, api_key: str):
        """添加API密钥"""
        if api_key not in self.api_keys:
            self.api_keys.append(api_key)
            print(f"[AutoSubmitAI] 新增API密钥，当前共有 {len(self.api_keys)} 个密钥")
        else:
            print(f"[AutoSubmitAI] API密钥已存在")

    def set_api_keys(self, api_keys: list):
        """设置API密钥列表"""
        self.api_keys = api_keys
        self.current_key_index = 0
        print(f"[AutoSubmitAI] API密钥列表已更新，共 {len(api_keys)} 个密钥")

    def get_api_keys_status(self) -> dict:
        """获取API密钥状态"""
        return {
            "total_keys": len(self.api_keys),
            "current_index": self.current_key_index,
            "has_keys": bool(self.api_keys and any(self.api_keys))
        }

    def test_connection(self) -> bool:
        """测试API连接"""
        try:
            print(f"[AutoSubmitAI] 测试API连接")

            if not self.api_keys or not any(self.api_keys):
                print(f"[AutoSubmitAI] API密钥未配置")
                return False

            test_prompt = "请回复：连接测试成功"
            response = self._call_bigmodel_api(test_prompt)

            if response and "成功" in response:
                print(f"[AutoSubmitAI] API连接测试成功")
                return True
            else:
                print(f"[AutoSubmitAI] API连接测试失败")
                return False

        except Exception as e:
            print(f"[AutoSubmitAI] API连接测试异常: {e}")
            return False


# 全局AI助手实例
_ai_helper = None

def get_ai_helper(api_keys: list = None) -> AutoSubmitAIHelper:
    """获取AI助手实例"""
    global _ai_helper
    if _ai_helper is None:
        _ai_helper = AutoSubmitAIHelper(api_keys)
    elif api_keys:
        _ai_helper.set_api_keys(api_keys)
    return _ai_helper
