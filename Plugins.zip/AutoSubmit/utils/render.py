#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
自动提交工具渲染系统
"""

from typing import Optional, Dict, Any
from Core.message.builder import MessageBuilder
from Core.tools.browser import browser
from Core.logging.file_logger import log_error


class AutoSubmitRenderSystem:
    """自动提交工具渲染系统"""

    def __init__(self):
        """初始化渲染系统"""
        pass  # 不需要任何初始化

    def render_to_message(self, template_name: str, data: Dict[str, Any],
                         caption: str = "", width: int = 600) -> Optional[Dict]:
        """
        渲染模板为消息对象

        Args:
            template_name: 模板文件名
            data: 模板数据
            caption: 图片说明
            width: 图片宽度

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        try:
            # 构建模板路径：AutoSubmit/templates/xxx.html
            template_path = f'AutoSubmit/templates/{template_name}'

            print(f"[AutoSubmitRender] 渲染模板: {template_path}")
            print(f"[AutoSubmitRender] 模板数据: {data}")

            # 使用系统级浏览器管理器渲染
            image_base64 = browser.render(template_path, data, width)

            if image_base64:
                print(f"[AutoSubmitRender] 图片渲染成功")
                # 返回MessageBuilder图片消息
                return MessageBuilder.image(caption=caption, base64_data=image_base64)
            else:
                print(f"[AutoSubmitRender] 图片渲染失败")
                return None

        except Exception as e:
            print(f"[AutoSubmitRender] 渲染异常: {e}")
            log_error(0, f"渲染模板失败: {e}", "AUTOSUBMIT_RENDER_ERROR")
            return None

    def render_login_success(self, uin: str, apps: list, login_time: str) -> Optional[Dict]:
        """
        渲染登录成功图片

        Args:
            uin: QQ号
            apps: 应用列表
            login_time: 登录时间

        Returns:
            MessageBuilder图片消息对象，失败返回None
        """
        # 准备模板数据
        template_data = {
            'uin': uin,
            'login_time': login_time,
            'apps': apps[:5],  # 最多显示5个应用
            'total_apps': len(apps),
            'has_more': len(apps) > 5
        }

        return self.render_to_message(
            'login_success.html',
            template_data,
            caption="登录成功！请选择要提交的机器人\n发送：确认 1 或 确认 2（不带数字默认选择第1个）",
            width=600
        )
