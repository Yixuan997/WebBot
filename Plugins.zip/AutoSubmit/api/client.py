#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
自动提交API客户端
"""

import requests
from typing import Dict, Optional
from Core.logging.file_logger import log_info, log_error


class AutoSubmitAPIClient:
    """自动提交API客户端"""

    def __init__(self, session_info: Dict):
        """
        初始化API客户端
        
        Args:
            session_info: 用户会话信息
        """
        self.session_info = session_info
        self.base_url = "https://q.qq.com"
        self.headers = {
            "Content-Type": "application/json",
            "Cookie": session_info.get('cookie', ''),
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

    def submit_bot_config(self, app_id: str, config_data: Dict) -> Dict:
        """
        自动提交机器人配置

        Args:
            app_id: 应用ID
            config_data: 配置数据

        Returns:
            提交结果
        """
        try:
            url = f"{self.base_url}/api/bot/config/submit"
            data = {
                "appId": app_id,
                "config": config_data
            }

            print(f"[AutoSubmitAPI] 提交配置请求")
            print(f"[AutoSubmitAPI] URL: {url}")
            print(f"[AutoSubmitAPI] 数据: {data}")
            print(f"[AutoSubmitAPI] 请求头: {self.headers}")

            response = requests.post(url, json=data, headers=self.headers, timeout=10)
            print(f"[AutoSubmitAPI] 响应状态码: {response.status_code}")

            if response.status_code == 200:
                result = response.json()
                print(f"[AutoSubmitAPI] 响应数据: {result}")

                if result.get('code') == 0:
                    print(f"[AutoSubmitAPI] 配置提交成功")
                    return {
                        'success': True,
                        'message': '配置提交成功',
                        'data': result.get('data')
                    }
                else:
                    print(f"[AutoSubmitAPI] 配置提交失败: {result.get('message')}")
                    return {
                        'success': False,
                        'message': result.get('message', '配置提交失败')
                    }
            else:
                print(f"[AutoSubmitAPI] HTTP请求失败: {response.status_code}")
                print(f"[AutoSubmitAPI] 响应内容: {response.text}")
                return {
                    'success': False,
                    'message': f'HTTP请求失败: {response.status_code}'
                }
                
        except Exception as e:
            print(f"[AutoSubmitAPI] 提交配置异常: {e}")
            log_error(0, f"提交机器人配置失败: {e}", "AUTOSUBMIT_CONFIG_ERROR")
            return {
                'success': False,
                'message': f'提交失败: {str(e)}'
            }

    def submit_whitelist(self, app_id: str, ip_list: list) -> Dict:
        """
        自动提交IP白名单
        
        Args:
            app_id: 应用ID
            ip_list: IP地址列表
            
        Returns:
            提交结果
        """
        try:
            url = f"{self.base_url}/api/bot/whitelist/submit"
            data = {
                "appId": app_id,
                "ipList": ip_list
            }
            
            response = requests.post(url, json=data, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('code') == 0:
                    return {
                        'success': True,
                        'message': 'IP白名单提交成功',
                        'data': result.get('data')
                    }
                else:
                    return {
                        'success': False,
                        'message': result.get('message', 'IP白名单提交失败')
                    }
            else:
                return {
                    'success': False,
                    'message': f'HTTP请求失败: {response.status_code}'
                }
                
        except Exception as e:
            log_error(0, f"提交IP白名单失败: {e}", "AUTOSUBMIT_WHITELIST_ERROR")
            return {
                'success': False,
                'message': f'提交失败: {str(e)}'
            }

    def submit_events(self, app_id: str, events: list) -> Dict:
        """
        自动提交事件订阅
        
        Args:
            app_id: 应用ID
            events: 事件列表
            
        Returns:
            提交结果
        """
        try:
            url = f"{self.base_url}/api/bot/events/submit"
            data = {
                "appId": app_id,
                "events": events
            }
            
            response = requests.post(url, json=data, headers=self.headers, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('code') == 0:
                    return {
                        'success': True,
                        'message': '事件订阅提交成功',
                        'data': result.get('data')
                    }
                else:
                    return {
                        'success': False,
                        'message': result.get('message', '事件订阅提交失败')
                    }
            else:
                return {
                    'success': False,
                    'message': f'HTTP请求失败: {response.status_code}'
                }
                
        except Exception as e:
            log_error(0, f"提交事件订阅失败: {e}", "AUTOSUBMIT_EVENTS_ERROR")
            return {
                'success': False,
                'message': f'提交失败: {str(e)}'
            }

    def get_app_list(self) -> Dict:
        """
        获取应用列表

        Returns:
            应用列表
        """
        try:
            url = "https://q.qq.com/homepagepb/GetAppListForLogin"
            data = {
                "uin": self.session_info.get('uin'),
                "developer_id": self.session_info.get('uid'),
                "ticket": self.session_info.get('ticket'),
                "app_type": [2]  # 2表示QQ机器人
            }

            print(f"[AutoSubmitAPI] 获取应用列表")
            print(f"[AutoSubmitAPI] URL: {url}")
            print(f"[AutoSubmitAPI] 数据: {data}")
            print(f"[AutoSubmitAPI] 请求头: {self.headers}")

            response = requests.post(url, json=data, headers=self.headers, timeout=10)
            print(f"[AutoSubmitAPI] 响应状态码: {response.status_code}")

            if response.status_code == 200:
                result = response.json()
                print(f"[AutoSubmitAPI] 响应数据: {result}")

                if result.get('code') == 0:
                    print(f"[AutoSubmitAPI] 获取应用列表成功")

                    # 详细打印返回的数据结构
                    data = result.get('data', {})
                    print(f"[AutoSubmitAPI] 返回的data字段: {data}")

                    if isinstance(data, dict) and 'apps' in data:
                        apps = data.get('apps', [])
                        print(f"[AutoSubmitAPI] 找到 {len(apps)} 个应用")

                        # 详细打印每个应用的信息
                        for i, app in enumerate(apps, 1):
                            print(f"[AutoSubmitAPI] 应用 {i}:")
                            print(f"[AutoSubmitAPI]   - app_name: {app.get('app_name', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - app_id: {app.get('app_id', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - app_desc: {app.get('app_desc', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - app_type: {app.get('app_type', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - release_state: {app.get('release_state', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - bot_status: {app.get('bot_status', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - bot_token: {app.get('bot_token', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - icon_url: {app.get('icon_url', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - web_ide_info: {app.get('web_ide_info', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - bot_third_party_tag: {app.get('bot_third_party_tag', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - wx_app_id: {app.get('wx_app_id', 'N/A')}")
                            print(f"[AutoSubmitAPI]   - 完整应用数据: {app}")
                    else:
                        print(f"[AutoSubmitAPI] data字段中没有apps或格式不正确")

                    return {
                        'success': True,
                        'data': result.get('data', {})
                    }
                else:
                    print(f"[AutoSubmitAPI] 获取应用列表失败: {result.get('message')}")
                    return {
                        'success': False,
                        'message': result.get('message', '获取应用列表失败')
                    }
            else:
                print(f"[AutoSubmitAPI] HTTP请求失败: {response.status_code}")
                print(f"[AutoSubmitAPI] 响应内容: {response.text}")
                return {
                    'success': False,
                    'message': f'HTTP请求失败: {response.status_code}'
                }

        except Exception as e:
            print(f"[AutoSubmitAPI] 获取应用列表异常: {e}")
            log_error(0, f"获取应用列表失败: {e}", "AUTOSUBMIT_APPS_ERROR")
            return {
                'success': False,
                'message': f'获取失败: {str(e)}'
            }

    def submit_all_configs(self, app_id: str, config_data: Dict, ip_list: list, events: list) -> Dict:
        """
        一键提交所有配置
        
        Args:
            app_id: 应用ID
            config_data: 配置数据
            ip_list: IP地址列表
            events: 事件列表
            
        Returns:
            提交结果
        """
        results = {
            'config': None,
            'whitelist': None,
            'events': None,
            'success_count': 0,
            'total_count': 3
        }
        
        # 提交配置
        if config_data:
            config_result = self.submit_bot_config(app_id, config_data)
            results['config'] = config_result
            if config_result.get('success'):
                results['success_count'] += 1
        
        # 提交白名单
        if ip_list:
            whitelist_result = self.submit_whitelist(app_id, ip_list)
            results['whitelist'] = whitelist_result
            if whitelist_result.get('success'):
                results['success_count'] += 1
        
        # 提交事件订阅
        if events:
            events_result = self.submit_events(app_id, events)
            results['events'] = events_result
            if events_result.get('success'):
                results['success_count'] += 1
        
        return results
