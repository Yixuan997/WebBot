"""
XArrPay插件 - 授权查询系统
使用QQBind插件进行QQ绑定
"""

from Core.logging.file_logger import log_error
from Core.message.builder import MessageBuilder
from Core.plugin.base import BasePlugin
from Core.plugin.manager import PluginManager

from .client import XArrPayAPIClient
from .config import PRODUCT_CONFIG


class Plugin(BasePlugin):
    """XArrPay插件"""

    def __init__(self):
        super().__init__()

        # 插件信息
        self.name = "XArrPay"
        self.version = "1.0.0"
        self.description = "XArrPay授权查询系统"
        self.author = "Yixuan"
        self.priority = 7  # 中等优先级

        # 注册命令信息
        self.register_command_info('我的授权')

        # 命令处理器
        self.command_handlers = {
            '我的授权': self.handle_auth_query
        }

        # 注册Hook事件处理器
        self.hooks = {
            'message_received': [self.handle_message_hook]
        }

        # 初始化组件
        self.api_client = None
        self.qqbind_plugin = None
        self._current_message_data = None
        self._current_bot_id = None

    def on_enable(self):
        """插件启用时调用"""
        super().on_enable()
        try:

            # 获取QQBind插件实例（确保已加载）
            plugin_manager = PluginManager()

            # 检查QQBind插件是否已加载
            existing_qqbind = plugin_manager.get_plugin('QQBind')

            # 确保QQBind插件被加载
            if not existing_qqbind:
                success = plugin_manager.load_plugin('QQBind')
                if not success:
                    log_error(0, "无法加载QQBind插件", "XARRPAY_QQBIND_LOAD_ERROR")
                    raise Exception("QQBind插件加载失败")
            else:
                pass

            self.qqbind_plugin = plugin_manager.get_plugin('QQBind')
            if not self.qqbind_plugin:
                raise Exception("无法获取QQBind插件实例")

            # 确保QQBind插件已启用
            if not getattr(self.qqbind_plugin, 'enabled', False) or not self.qqbind_plugin.bind_system:
                self.qqbind_plugin.on_enable()
            # 初始化API客户端
            self.api_client = XArrPayAPIClient()

        except Exception as e:
            log_error(0, f"XArrPay插件启用失败: {e}", "XARRPAY_PLUGIN_ENABLE_ERROR")

    def get_user_group_from_message(self, message_data):
        """从消息数据中提取用户ID和群组ID"""
        try:
            author = message_data.get('author', {})
            user_id = author.get('union_openid') or author.get('id')
            group_id = message_data.get('group_openid') or message_data.get('guild_id')
            return user_id, group_id
        except Exception:
            return None, None

    # ==================== Hook事件处理 ====================

    def handle_message_hook(self, message_data, user_id=None, bot_id=None):
        """处理消息Hook"""
        try:
            self._current_message_data = message_data
            self._current_bot_id = bot_id

            content = message_data.get('content', '').strip()

            if content in self.command_handlers:
                handler = self.command_handlers[content]
                response = handler([])
                return {'response': response, 'handled': True}

            return {'handled': False}

        except Exception as e:
            log_error(bot_id or 0, f"XArrPay插件处理消息异常: {e}", "XARRPAY_MESSAGE_HOOK_ERROR")
            return {'handled': False}

    # ==================== 命令处理器 ====================

    def handle_auth_query(self, args):
        """处理授权查询命令"""
        try:

            if not self.qqbind_plugin:
                try:
                    plugin_manager = PluginManager()

                    # 检查QQBind插件是否已加载
                    existing_qqbind = plugin_manager.get_plugin('QQBind')

                    # 确保QQBind插件被加载
                    if not existing_qqbind:
                        success = plugin_manager.load_plugin('QQBind')
                        if not success:
                            log_error(0, "无法加载QQBind插件", "XARRPAY_QQBIND_LOAD_ERROR")
                            return MessageBuilder.text("❌ QQ绑定服务不可用")
                    else:
                        pass

                    self.qqbind_plugin = plugin_manager.get_plugin('QQBind')
                    if not self.qqbind_plugin:
                        return MessageBuilder.text("❌ QQ绑定服务不可用")

                    # 确保QQBind插件已启用
                    if not getattr(self.qqbind_plugin, 'enabled', False) or not self.qqbind_plugin.bind_system:
                        self.qqbind_plugin.on_enable()

                except Exception as e:
                    log_error(0, f"QQBind插件获取失败: {e}", "XARRPAY_QQBIND_GET_ERROR")
                    return MessageBuilder.text("❌ QQ绑定服务不可用")
            else:

                # 确保QQBind插件已启用
                if not getattr(self.qqbind_plugin, 'enabled', False) or not self.qqbind_plugin.bind_system:
                    self.qqbind_plugin.on_enable()

            if not self.api_client:
                self.api_client = XArrPayAPIClient()

            user_id, group_id = self.get_user_group_from_message(self._current_message_data)
            if not user_id or not group_id:
                return MessageBuilder.text("❌ 无法获取用户或群组信息")

            # 检查是否绑定
            try:
                bind_check = self.qqbind_plugin.require_qq_bind_for_plugin(user_id)
                if bind_check:
                    # 未绑定，启动绑定流程
                    custom_hint = "发送 '我的授权' 可以查询授权"
                    original_msg_id = self._current_message_data.get('id')
                    reply_msg_id = self._current_message_data.get('msg_id')
                    bot_id = self._current_bot_id

                    return self.qqbind_plugin.start_bind_with_hint_for_plugin(
                        user_id, group_id, custom_hint,
                        original_msg_id, reply_msg_id, bot_id
                    )
                else:
                    pass
            except Exception as bind_e:
                log_error(0, f"绑定检查失败: {bind_e}", "XARRPAY_BIND_CHECK_ERROR")
                return MessageBuilder.text("❌ 绑定检查失败")

            # 获取绑定的QQ号
            try:
                bound_qq = self.qqbind_plugin.get_bound_qq_for_plugin(user_id)
                if not bound_qq:
                    return MessageBuilder.text("❌ 未找到绑定的QQ号，请先绑定")
            except Exception as qq_e:
                log_error(0, f"获取绑定QQ号失败: {qq_e}", "XARRPAY_GET_QQ_ERROR")
                return MessageBuilder.text("❌ 获取绑定QQ号失败")
            try:
                auth_results = self.api_client.check_dual_auth(bound_qq)
            except Exception as auth_e:
                log_error(0, f"授权查询失败: {auth_e}", "XARRPAY_AUTH_QUERY_ERROR")
                return MessageBuilder.text("❌ 授权查询失败")

            # 构建响应消息
            try:
                result = self._format_dual_auth_card(bound_qq, auth_results)
                return result
            except Exception as card_e:
                log_error(0, f"消息构建失败: {card_e}", "XARRPAY_CARD_BUILD_ERROR")
                return MessageBuilder.text("❌ 消息构建失败")

        except Exception as e:
            log_error(0, f"授权查询失败: {e}", "XARRPAY_QUERY_ERROR")
            return MessageBuilder.text("❌ 查询失败，请稍后重试")

    def _format_dual_auth_card(self, qq_number: str, auth_results: dict):
        """格式化双重授权查询结果为卡片消息"""
        try:
            personal = auth_results.get('personal', {})
            merchant = auth_results.get('merchant', {})
            summary = auth_results.get('summary', {})

            # 检查授权状态
            has_personal = personal.get('success', False) and personal.get('authorized', False)
            has_merchant = merchant.get('success', False) and merchant.get('authorized', False)

            # 如果商户版授权成功，优先显示商户版
            if has_merchant:
                return MessageBuilder.text_card(
                    text="XArrPay 商户版\n运营级别平台，可提供商户进行使用\n✅ 授权可用",
                    description="XArrPay 商户版",
                    prompt="商户版授权已激活"
                )

            # 如果个人版授权成功
            elif has_personal:
                return MessageBuilder.text_card(
                    text="XArrPay 个人版\n一般适用于个人站长使用\n✅ 授权可用",
                    description="XArrPay 个人版",
                    prompt="个人版授权已激活"
                )

            # 如果都没有授权
            else:
                # 检查是否查询失败
                personal_failed = not personal.get('success', False)
                merchant_failed = not merchant.get('success', False)

                if personal_failed or merchant_failed:
                    return MessageBuilder.text_card(
                        text="📱 绑定QQ: " + qq_number + "\n⚠️ 查询失败，请稍后重试",
                        description="XArrPay 授权查询",
                        prompt="网络异常或服务暂不可用"
                    )
                else:
                    return MessageBuilder.text_card(
                        text="📱 绑定QQ: " + qq_number + "\n❌ 暂无任何授权\n💡 请联系管理员获取授权",
                        description="XArrPay 授权查询",
                        prompt="未检测到有效授权"
                    )

        except Exception as e:
            log_error(0, f"格式化授权卡片失败: {e}", "XARRPAY_FORMAT_CARD_ERROR")
            return MessageBuilder.text_card(
                text="📱 绑定QQ: " + qq_number + "\n❌ 查询异常，请稍后重试",
                description="XArrPay 授权查询",
                prompt="系统异常"
            )
