"""
XArrPay API客户端
用于查询授权状态
"""

from typing import Dict, Union
import requests
from Core.logging.file_logger import log_error
from .config import PRODUCT_CONFIG


class XArrPayAPIClient:
    """XArrPay授权查询API客户端"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'XArrPay-Bot/1.0.0',
            'Content-Type': 'application/x-www-form-urlencoded'
        })

        # 设置SSL证书路径
        import os
        cert_path = '/www/server/pyporject_evn/Bot/lib/python3.10/site-packages/certifi/cacert.pem'
        if os.path.exists(cert_path):
            self.session.verify = cert_path
        else:
            pass

        # API配置
        self.base_url = "https://auth.xarr.cn"
        self.check_auth_endpoint = "/api/auth/check-auth"
        self.timeout = 10

        # 产品ID配置
        self.default_product_id = PRODUCT_CONFIG['default_product_id']

    def check_auth(self, qq_number: str, product_id: int = None) -> Dict[str, Union[bool, str, Dict]]:
        """
        查询单个产品的授权状态
        
        Args:
            qq_number: QQ号
            product_id: 产品ID，默认为1
            
        Returns:
            Dict: 查询结果
        """
        try:
            if product_id is None:
                product_id = self.default_product_id

            url = f"{self.base_url}{self.check_auth_endpoint}"
            request_data = {
                'qq': qq_number,
                'product_id': product_id
            }

            response = self.session.post(url, data=request_data, timeout=self.timeout)
            response_data = response.json()

            code = response_data.get('code', 0)
            message = response_data.get('message', '未知响应')
            data = response_data.get('data', {})

            if code == 200:
                # 查询成功，有授权
                return {
                    'success': True,
                    'authorized': True,
                    'message': message,
                    'code': code,
                    'data': data,
                    'product_id': product_id
                }
            elif code == 502:
                # 查询成功，无授权
                return {
                    'success': True,
                    'authorized': False,
                    'message': message,
                    'code': code,
                    'data': data,
                    'product_id': product_id
                }
            else:
                # 其他错误
                return {
                    'success': False,
                    'authorized': False,
                    'message': f'查询失败: {message}',
                    'code': code,
                    'data': data,
                    'product_id': product_id
                }

        except Exception as e:
            log_error(0, f"授权查询异常: {e}", "XARRPAY_CHECK_AUTH_ERROR")
            return {
                'success': False,
                'authorized': False,
                'message': f'查询异常: {str(e)}',
                'code': 0,
                'data': {},
                'product_id': product_id or self.default_product_id
            }

    def check_dual_auth(self, qq_number: str) -> Dict[str, Dict]:
        """
        查询双重授权状态（个人版和商户版）
        
        Args:
            qq_number: QQ号
            
        Returns:
            Dict: 查询结果
            {
                'personal': dict,  # 个人版授权结果 (product_id=1)
                'merchant': dict,  # 商户版授权结果 (product_id=2)
                'summary': {
                    'has_personal': bool,  # 是否有个人版授权
                    'has_merchant': bool,  # 是否有商户版授权
                    'has_any': bool,      # 是否有任意授权
                    'has_both': bool      # 是否两个都有授权
                }
            }
        """
        try:
            # 查询个人版授权 (product_id=1)
            personal_result = self.check_auth(qq_number, 1)
            
            # 查询商户版授权 (product_id=2)
            merchant_result = self.check_auth(qq_number, 2)
            
            # 生成汇总信息
            has_personal = personal_result.get('success', False) and personal_result.get('authorized', False)
            has_merchant = merchant_result.get('success', False) and merchant_result.get('authorized', False)
            
            summary = {
                'has_personal': has_personal,
                'has_merchant': has_merchant,
                'has_any': has_personal or has_merchant,
                'has_both': has_personal and has_merchant
            }
            
            return {
                'personal': personal_result,
                'merchant': merchant_result,
                'summary': summary
            }
            
        except Exception as e:
            log_error(0, f"双重授权查询异常: {e}", "XARRPAY_DUAL_CHECK_ERROR")
            
            error_result = {
                'success': False,
                'authorized': False,
                'message': f'查询异常: {str(e)}',
                'code': 0,
                'data': {}
            }
            
            return {
                'personal': {**error_result, 'product_id': 1},
                'merchant': {**error_result, 'product_id': 2},
                'summary': {
                    'has_personal': False,
                    'has_merchant': False,
                    'has_any': False,
                    'has_both': False
                }
            }
