"""
XArrPay插件配置文件
"""

# 产品配置
PRODUCT_CONFIG = {
    'default_product_id': 1,
    'product_names': {
        1: '个人版',
        2: '商户版'
    }
}
